####################################################
# Robert Huang
# Immigration Policy Data Prep 
# February 3, 2021

# Citation: 
# Peters, Margaret, 2015, "Low_skill_immigration_policy_dataset.csv", Low-Skill Immigration Policy Dataset, 
# https://doi.org/10.7910/DVN/XTSNW0/6PDQZC, Harvard Dataverse, V1
####################################################

# clear everything
rm(list= ls())

# load libraries
library(tidyverse)
library(foreign)

# set filepaths 
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2021/rawdata/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2021/prepped/"
prepscripts <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2021/scripts/"

# load in the PIP data
PIP <- read.csv(paste(rawdata, "RAWDATA_PIP_2010.csv", sep=""))

# make sure there are year and country variables
names(PIP)
# we get countrynm instead of country, so we rename it
PIP <- rename(PIP,country=countrynm)

# make sure year is numeric
str(PIP$year)

# check for duplicates
n_occur <- data.frame(table(PIP$country, PIP$year))
print(n_occur[n_occur$Freq > 1,])

# There are a lot of missing country names
# Because the country code is given, we append country names to them manually.
unique(PIP$ccode[PIP$country==""])

nrow(PIP[is.na(PIP$ccode)&PIP$country=="",])
# There are 6630 rows without country code and country name
# 
# # I looked up the official Gleditsch-Ward website to get the correspnding country names.
# # http://ksgleditsch.com/data/iisystem.dat
# PIP$country[PIP$ccode==101] <- "Venezuela"
# PIP$country[PIP$ccode==155] <- "Chile"
# PIP$country[PIP$ccode==165] <- "Uruguay"
# PIP$country[PIP$ccode==205] <- "Ireland"
# PIP$country[PIP$ccode==211] <- "Belgium"
# PIP$country[PIP$ccode==212] <- "Luxembourg"
# PIP$country[PIP$ccode==230] <- "Spain"
# PIP$country[PIP$ccode==235] <- "Portugal"
# PIP$country[PIP$ccode==260] <- "German Federal Republic"
# PIP$country[PIP$ccode==290] <- "Poland"
# PIP$country[PIP$ccode==305] <- "Austria"
# PIP$country[PIP$ccode==310] <- "Hungary"
# PIP$country[PIP$ccode==316] <- "Czech Republic"
# PIP$country[PIP$ccode==317] <- "Slovakia"
# PIP$country[PIP$ccode==325] <- "Italy/Sardinia"
# PIP$country[PIP$ccode==338] <- "Malta"
# PIP$country[PIP$ccode==344] <- "Croatia"
# PIP$country[PIP$ccode==349] <- "Slovenia"
# PIP$country[PIP$ccode==350] <- "Greece"
# PIP$country[PIP$ccode==352] <- "Cyprus"
# PIP$country[PIP$ccode==355] <- "Bulgaria"
# PIP$country[PIP$ccode==360] <- "Rumania"
# PIP$country[PIP$ccode==366] <- "Estonia"
# PIP$country[PIP$ccode==367] <- "Latvia"
# PIP$country[PIP$ccode==368] <- "Lithuania"
# PIP$country[PIP$ccode==375] <- "Finland"
# PIP$country[PIP$ccode==380] <- "Sweden"
# PIP$country[PIP$ccode==385] <- "Norway"
# PIP$country[PIP$ccode==390] <- "Denmark"
# PIP$country[PIP$ccode==395] <- "Iceland"
# PIP$country[PIP$ccode==640] <- "Turkey (Ottoman Empire)"
# PIP$country[PIP$ccode==692] <- "Bahrain"
# PIP$country[PIP$ccode==694] <- "Qatar"
# PIP$country[PIP$ccode==696] <- "United Arab Emirates"
# PIP$country[PIP$ccode==698] <- "Oman"
# # There is no country corresponding to code 999 and NA

# append IDs
# load the functions from the prepscripts path
source(paste(prepscripts,"append_ids.R",sep=""))

PIP2 <- append_ids(PIP,breaks = F)
# NAs were not given gwno codes. The rest all got the code.

# check for duplicates
n_occur <- data.frame(table(PIP2$country, PIP2$year))
print(n_occur[n_occur$Freq > 1,])
# # There are duplicates of German Federal Republic from 1946 to 2010
# 
# PIP2[PIP2$country=="German Federal Republic"&PIP2$year==1946,]
# # There are two raw country names: German Federal Republic and Germany.
# # German Federal Republic existed for longer time (according to gwno website)
# # We only keep the German Federal Republic observation and remove Germany.
# 
# PIP2 <- PIP2 %>%
#   filter(!(countryname_raw=="Germany" & year %in% seq(1946,2010)))
# 
# n_occur <- data.frame(table(PIP2$country, PIP2$year))
# print(n_occur[n_occur$Freq > 1,])
# # no more duplicate

# append suffix
# PIP stands for Peters Immigration Policy data
PIP2 <- append_suffix(PIP2,"PIP")

# label variables
library(Hmisc)
label(PIP2$ccode_raw_PIP) <- "Correlates of War code"
label(PIP2$natcode_PIP) <- "Universality by nationality code"
label(PIP2$skillcode_PIP) <- "Skill level restrictions"
label(PIP2$citcode_PIP) <- "Citizenship criteria"
label(PIP2$rightscode_PIP) <- "Rights given to immigrants"
label(PIP2$refcode_PIP) <- "Refugee policy"
label(PIP2$refexist_PIP) <- "Whether a refugee policy exists"
label(PIP2$asylcode_PIP) <- "Asylum policy"
label(PIP2$asylexist_PIP) <- "Whether an asylum policy exists"
label(PIP2$reccode_PIP) <- "Immigrant recruitment policy"
label(PIP2$labcode_PIP) <- "Restrictions on labor market participation"
label(PIP2$decode_PIP) <- "Deportation policy"
label(PIP2$encode_PIP) <- "Enforcement policy"
label(PIP2$famcode_PIP) <- "Family reunification policy"
label(PIP2$famexist_PIP) <- "Whether a family reunification policy exists"
label(PIP2$qcode_PIP) <- "Quota"
label(PIP2$immipol_PIP) <- "Overall immigration policy"

# save prepped data
save(PIP2,file=paste(preppeddata,"prepped_PIP_RH_02042021.RDATA",sep=""))