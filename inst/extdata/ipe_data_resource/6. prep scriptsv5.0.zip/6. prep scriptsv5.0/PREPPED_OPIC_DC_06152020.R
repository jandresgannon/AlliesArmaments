#-------------------------------------------------------------------------------------------------------------
#  Deven Clark 06/12/2020
# Prepping/Cleaning OPIC Claims Data for IPE Data Resource
#Political Risk Insurance and Finance Dataset

# Updated: Gaea Morales, 06/27/22
#-------------------------------------------------------------------------------------------------------------
# rawdata <- "C:/Users/deven/OneDrive/Documents/R/rawdata/"
# preppeddata <- "C:/Users/deven/OneDrive/Documents/R/preppeddata/"
# prepscripts <- "C:/Users/deven/OneDrive/Documents/R/prepscripts/"
#Loading in file paths

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SUMMER 2020/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/preppeddatav5.0/"

library(ggplot2)
library(foreign)
library(dplyr)
library(tidyverse)
library(magrittr)
library(readxl)
library(Hmisc)
library(purrr)
library(countrycode)
#Loading in possible packages

#setwd("C:/Users/deven/OneDrive/Documents/R/")

#Setting working directory
claims = read.csv(paste(rawdata,"RAWDATA_OPIC_CLAIMS_DC_06152020.csv",sep="")) # Had country and fiscal year
deflator = read.csv(paste(rawdata,"RAWDATA_OPIC_DC_DEFLATOR_06152020.csv",sep=""))# Year only and variable, merge
panels = read.csv(paste(rawdata,"RAWDATA_OPIC_DC_PANEL_06152020.csv",sep=""))#Has country code and year
project = read.csv(paste(rawdata,"RAWDATA_OPIC_PROJECTS_DC_06152020.csv",sep=""))#Has country and year

claims$year_fiscal = as.numeric(claims$year_fiscal)
deflator$year = as.numeric(deflator$year)
panels$year = as.numeric(panels$year)
project$year = as.numeric(project$year)
#Make years variable numeric for all datasets

deflatorpanel = full_join(panels,deflator, by = "year")
#Deflator is just a dataset featuring a variable and year values. Easy merge.

deflatorpanel <- mutate(deflatorpanel, country = countrycode(iso3c, # variable containing country codes
                                       "iso3c", # coding scheme of origin (COW numeric)
                                       "country.name")) # coding scheme of destination (full names)
#Convert from iso3c to country names.

#KSV AND YUG NOT MATCHED
#KSV is supposed to be Kosovo. YUG is Yugoslavia. Ivory Coast had a naming problem.
#Swaziland and Eswatini naming problem.
deflatorpanel$country[deflatorpanel$iso3c == "KSV"] <- "Kosovo"
deflatorpanel$country[deflatorpanel$iso3c == "YUG"] <- "Yugoslavia"
deflatorpanel$country[deflatorpanel$country == "C?te d'Ivoire"] <- "Ivory Coast"
deflatorpanel$country[deflatorpanel$country == "Eswatini"] <- "Swaziland"

deflatorpanel = deflatorpanel %>%
  select(country,year,everything()) # Just get country and year first

claims$year = claims$year_fiscal # I treat Years as the fiscal year

claims = claims %>%
  select(country,year_fiscal,year,everything()) # Just get country and year first

project = project %>%
  select(country,year,everything()) # Just get country and year first


#Now all datasets have country and year.

n_occur <- data.frame(table(deflatorpanel$country, deflatorpanel$year))
print(n_occur[n_occur$Freq > 1,])
#Different countries will have different amount of investors in a given year so this is ok
#Same with claims dataset
#same with project

# source(paste(prepscripts,"append_ids.R",sep=""))

ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste0(ids_path, "append_ids.R"))

#functions to append IDs of gwno

deflatorpanel = append_ids(deflatorpanel, breaks = F)
#Anguilla,Aruba,Cura?ao,French Guiana,French Polynesia,Guadeloupe,Martinique
# Palestinian Territories,Sint Maarten, and Turks & Caicos Islands not given codes

claims = append_ids(claims, breaks = F)
#S. Rhodesia, St. Kitts not given codes

project <- mutate(project, country = countrycode(iso3c, # variable containing country codes
                                                             "iso3c", # coding scheme of origin (COW numeric)
                                                             "country.name")) # coding scheme of destination (full names)
#Convert this dataset from iso3c to country name.

project$country[project$iso3c == "KSV"] <- "Kosovo"
project$country[project$iso3c == "YUG"] <- "Yugoslavia"
project$country[project$country == "C?te d'Ivoire"] <- "Ivory Coast"
project$country[project$country == "Eswatini"] <- "Swaziland"


project = append_ids(project, breaks = F)
#Anguilla,Aruba,Cura?ao,French Guiana,French Polynesia,Guadeloupe,Guadeloupe
# Palestinian Territories,Sint Maarten,Turks & Caicos Islands not given codes


opic = full_join(deflatorpanel,claims,by = c("year","gwno"))
opic = full_join(opic,project, by = c("year","gwno"))

str(opic)

opic <- append_suffix(opic,"OPIC")
name(opic)

#Did I merge this correctly? Should I delete any of the variables. x and y for many variables is present.
#Should I add labels to all of them?
names(opic)
opic$country_OPIC <- opic$country.x_OPIC
opic$ccode_OPIC <- opic$ccode.x_OPIC 
opic$ccode_OPIC <- opic$iso3c.x_OPIC
opic$ifscode_OPIC <- opic$ifscode.x_OPIC
opic$gwabbrev_OPIC <- opic$gwabbrev.x_OPIC 
opic$ifs_OPIC <- opic$ifs.x_OPIC 
opic$project_OPIC <- opic$project.x_OPIC
opic$deflator_OPIC <- opic$deflator.x_OPIC
opic$countryname_raw <- opic$countryname_raw.x_OPIC


names(opic)
# name(opic)

opic = opic %>%
  select(-contains(c(".y", ".x"))) 

names(opic)

n_occur <- data.frame(table(opic$gwno, opic$year))
print(n_occur[n_occur$Freq > 1,])

#Get rid of some duplicates



save(opic, file=paste(preppeddata,"PREPPED_OPIC_DC_06162020.RDATA",sep=""))

#SAVE RDS DATAFILE
