# /*************************
#   IMF Agreement Data
# 
# Source: Bauer, Molly E., Cesi Cruz, and Benjamin A. T. Graham. 2012. “Democracies only: When do
# IMF agreements serve as a seal of approval?” The Review of International Organizations 7(1): 33–58.
# 
# Vreeland, J.R. 2003. The IMF and Economic Development. New York: Cambridge University
# Press.
# 
# URL: https://link.springer.com/article/10.1007/s11558-011-9122-9
# 
# Updated On: 2018.02.18
# By: Emily
# 
# Variables:
# - Whether a country was under an IMF agreement 
# - Type of IMF agreement country is under [BCG]
# *************************/
library(foreign)
library(Hmisc)

bcg = read.dta(paste(rawdata,"RAWDATA_BCG_2011.dta",sep=""))

#Keep only the variables we need
bcg = bcg[, c("ctryname", "year", "under", "undertype")]

#Rename ctryname to country
names(bcg)[names(bcg)=="ctryname"] = "country"

#Append country ids
bcg = append_ids(bcg, breaks = F)

#Add variable labels
label(bcg$under) <- "Whether a country was under an IMF agreement [BCG]"
label(bcg$undertype) <- "Type of IMF agreement a country is under [BCG]"

bcg = append_suffix(bcg,"BCG")

#check number of countries
length(unique(bcg$gwno)) #188

#check number of years
range(bcg$year) #1970 - 2008

save(bcg,file=paste(preppeddata,"PREPPED_BCG_EH_02182018.RDATA",sep=""))
