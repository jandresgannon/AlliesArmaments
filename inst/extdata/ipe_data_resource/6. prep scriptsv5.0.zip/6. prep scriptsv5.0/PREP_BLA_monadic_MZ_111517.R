###############################
# Bilateral Labor Agreements
# Accessed: November 2017
# Year Range: 1945-2015
# Prepped By: Madeline Zheng
# Edited MB 5/2020
# Suffix: BLA
#
# Data Source: https://www.law.uchicago.edu/bilateral-labor-agreements-dataset
# Codebook: https://dataverse.harvard.edu/file.xhtml?fileId=3050008&version=RELEASED&version=.0
#   
# Citation: Adam Chilton and Eric Posner. Why Countries Sign Bilateral Labor Agreements. Journal of Legal Studies (forthcoming).
#
# Variables:
# treatytotalN: "Total number of new treaties signed by the country in the period 1945-2015. This variable is constant for any particular country across all years [BLA]"
# treatyruntotalN: "Total number of new treaties signed by the country up to, and including, the given year. This variable is a simply a running total of new treaties signed by the country [BLA]"
#
###############################

# --- hmisc will be needed for all packages as we use it for the append_ids function
library(Hmisc)
library(readstata13)
library(tidyr)
library(dplyr)
library(countrycode)

# --- importing dataset
bla_raw <- read.dta13(paste(rawdata,"RAWDATA_BLA_Chilton.dta",sep = ""))
#cow <- read.csv(paste(rawdata,"BLA_COW_codes.csv",sep = ""))

#Delete some columns
bla_raw <- bla_raw[,c("code_host","code_source","year", "treatytotalN", "treatyruntotalN")]

#Rename some variables
names(bla_raw)[names(bla_raw)=="code_host"] = "ccode1"
names(bla_raw)[names(bla_raw)=="code_source"] = "ccode2"

#Transform to monadic data, then rename variables and clean up
bla_monadic <- data.frame(stack(bla_raw[1:2]), bla_raw[3:5])
names(bla_monadic)[names(bla_monadic)=="values"] = "ccode"
bla_monadic <- bla_monadic[,c("ccode","year", "treatytotalN", "treatyruntotalN")]

#Aggregate by country, year
bla_monadic <- bla_monadic %>% 
  group_by(ccode, year) %>% 
  summarise(treatytotalN = sum(treatytotalN), 
            treatyruntotalN = sum(treatyruntotalN))

# treatytotalN_adjust <- aggregate(bla_monadic$treatytotalN, by=list(ccode = bla_monadic$ccode), FUN=max)
# bla_monadic <- merge(bla_monadic, treatytotalN_adjust, by="ccode", all.x=TRUE)
# bla_monadic <- bla_monadic[,c("ccode","year", "x", "treatyruntotalN")]
# names(bla_monadic)[names(bla_monadic)=="x"] = "treatytotalN"

#Append country names based on COW codes
bla_monadic$country <- countrycode(bla_monadic$ccode, "cown", "country.name")
bla_monadic$country[bla_monadic$ccode == 260] <- "German Federal Republic"
bla_monadic$country[bla_monadic$ccode == 711] <- "Tibet"
##################################################

# removing ccode as it will be added by the append ids 
bla_monadic = bla_monadic[,c("country", "year", "treatytotalN", "treatyruntotalN")]

# check for duplicates
n_occur <- data.frame(table(bla_monadic$country, bla_monadic$year))
n_occur[n_occur$Freq>1,]

str(bla_monadic)

#Append country IDs
bla_monadic <- append_ids(bla_monadic, breaks = FALSE) 
#Append suffixes
bla_monadic <- append_suffix(bla_monadic,"BLA")

# check for duplicates
n_occur <- data.frame(table(bla_monadic$gwno, bla_monadic$year))
n_occur[n_occur$Freq>1,]

# --- Fixing duplicates
# Germany/West Germany - drop the 1990 West Germany observation
bla_monadic <- bla_monadic[!(bla_monadic$countryname_raw_BLA == "German Federal Republic" & bla_monadic$year == 1990),]

# Yemen/North Yemen - drop the 1990 North Yemen observation
bla_monadic <- bla_monadic[!(bla_monadic$countryname_raw_BLA == "Yemen Arab Republic" & bla_monadic$year == 1990),]

# Czechoslovakia/Czech Republic - drop the 1992 Czech Republic observation
bla_monadic <- bla_monadic[!(bla_monadic$countryname_raw_BLA == "Czechia" & bla_monadic$year == 1992),]

# check for duplicates
n_occur <- data.frame(table(bla_monadic$gwno, bla_monadic$year))
n_occur[n_occur$Freq>1,]

# How many countries and what time period?
length(unique(bla_monadic$gwno)) # 203
range(bla_monadic$year) # 1945-2015

#Add variable labels
label(bla_monadic$treatytotalN_BLA) = "Total number of new treaties signed by the country in the period 1945-2015. This variable is constant for any particular country across all years [BLA]"
label(bla_monadic$treatyruntotalN_BLA) = "Total number of new treaties signed by the country up to, and including, the given year. This variable is a running total of new treaties signed by the country [BLA]"

#Save
save(bla_monadic, file = paste(preppeddata,"PREPPED_BLA_MZ_SM_20180507.RDATA",sep=""))

#write.csv(bla_monadic, file = paste(preppeddata,"PREPPED_BLA_MZ_SM_20180507.csv",sep=""))

