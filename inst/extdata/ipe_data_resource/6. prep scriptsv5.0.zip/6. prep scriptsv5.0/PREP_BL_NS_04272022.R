#/**************************
#  Dataset: Barro and Lee Educational Attainment
#  Data source url: http://www.barrolee.com/
#  Codebook url: 
#  Citation:
#  Time: 1950-2015
#  Updated: 2022.04.27
#  By: Natalie Song
#  Suffix: BL
#
#/****************************

rm(list = ls())

# paths
rawdata <- "G:/.shortcut-targets-by-id/0B2iwvlsRgy8tQXlVNll5WWhLcGs/Master IPE Data/SPRING 2022/rawdata/"
ids_path <- "G:/.shortcut-targets-by-id/1JpiIrqOeS1K9UlbREPhw_iziB-QxPH91/append_ids/"
preppeddata <- "G:/.shortcut-targets-by-id/0B2iwvlsRgy8tQXlVNll5WWhLcGs/Master IPE Data/SPRING 2022/prepped/"
prepscripts <- "G:/.shortcut-targets-by-id/0B2iwvlsRgy8tQXlVNll5WWhLcGs/Master IPE Data/SPRING 2022/scripts/"
source(paste(ids_path,"append_ids.R",sep=""))

# import
bl_mf <- read.csv(paste(rawdata, "RAWDATA_BL_2022_MF.csv", sep=""))
bl_f <- read.csv(paste(rawdata, "RAWDATA_BL_2022_F.csv", sep=""))
bl_m <- read.csv(paste(rawdata, "RAWDATA_BL_2022_M.csv", sep=""))

library(haven)
bl_prepped <- read_dta(paste("G:/.shortcut-targets-by-id/0B2iwvlsRgy8tQXlVNll5WWhLcGs/Master IPE Data/ARCHIVES/IPE Dataset_v.3.0 (formerly v.2.1)/7. prepped data v3.0/", "PREPPED_BL.dta", sep=""))

### FEMALE PREP ###

bl_f <- bl_f %>%
  select(-c(BLcode, region_code, WBcode))

bl_f$sex <- as.character(bl_f$sex) # change from bool to char
bl_f$sex <- "F" # change FALSE to F

# convert ageto and agefrom into one string value
bl_f <- bl_f %>%
  mutate(ages = paste(agefrom, ageto, sep="")) %>%
  select(-c(agefrom, ageto))

# append suffix "F"
bl_f <- append_suffix(bl_f, "F")

# pivot wider
bl_f <- pivot_wider(bl_f,
                    names_from = ages_F,
                    values_from = c(lu_F, lp_F, lpc_F, ls_F, lsc_F, lh_F, lhc_F, yr_sch_F, yr_sch_pri_F, yr_sch_sec_F, yr_sch_ter_F, pop_F))

# Save
saveRDS(bl_f, file = paste(rawdata,"RAWDATA_BL_2022_F_1.RDS", sep=""))

### MALE PREP ###

bl_m <- bl_m %>%
  select(-c(BLcode, region_code, WBcode))

# convert ageto and agefrom into one string value
bl_m <- bl_m %>%
  mutate(ages = paste(agefrom, ageto, sep="")) %>%
  select(-c(agefrom, ageto))

# append suffix "F"
bl_m <- append_suffix(bl_m, "M")

# pivot wider
bl_m <- pivot_wider(bl_m,
                    names_from = ages_M,
                    values_from = c(lu_M, lp_M, lpc_M, ls_M, lsc_M, lh_M, lhc_M, yr_sch_M, yr_sch_pri_M, yr_sch_sec_M, yr_sch_ter_M, pop_M))

# Save
saveRDS(bl_m, file = paste(rawdata,"RAWDATA_BL_2022_M_1.RDS", sep=""))

### MALE/FEMALE PREP ###

bl_mf <- bl_mf %>%
  select(-c(BLcode, region_code, WBcode))

# convert ageto and agefrom into one string value
bl_mf <- bl_mf %>%
  mutate(ages = paste(agefrom, ageto, sep="")) %>%
  select(-c(agefrom, ageto))

# pivot wider
bl_mf <- pivot_wider(bl_mf,
                    names_from = ages,
                    values_from = c(lu, lp, lpc, ls, lsc, lh, lhc, yr_sch, yr_sch_pri, yr_sch_sec, yr_sch_ter, pop))

# Save
saveRDS(bl_mf, file = paste(rawdata,"RAWDATA_BL_2022_MF_1.rds", sep=""))

# import new prepped files
bl_mf_prepped <- readRDS(paste(rawdata, "RAWDATA_BL_2022_MF_1.RDS", sep=""))
bl_f_prepped <- readRDS(paste(rawdata, "RAWDATA_BL_2022_F_1.RDS", sep=""))
bl_m_prepped <- readRDS(paste(rawdata, "RAWDATA_BL_2022_M_1.RDS", sep=""))

# join male, female, and total
bl <- full_join(bl_mf_prepped, bl_f_prepped)
bl <- full_join(bl, bl_m_prepped)

# remove sex column
bl <- select(bl, -sex)

# checks
names(bl)

str(bl$year)
bl$year <- as.numeric(bl$year) # change from int to num

n_occur <- data.frame(table(bl$country, bl$year))
n_occur[n_occur$Freq>1,] # no repeats

# append ids
bl <- append_ids(bl, breaks = F)

# check for duplicates
n_occur <- data.frame(table(bl$country, bl$year))
print(n_occur[n_occur$Freq > 1,])

# how many countries? what time period?
length(unique(bl$gwno)) #148
range(bl$year) #1950-2015

# labels
library(Hmisc)
label(bl$lu_1524) <- "Percentage of no schooling, population aged 15-24"
label(bl$lu_F_1524) <- "Percentage of no schooling, female population aged 15-24"
label(bl$lu_M_1524) <- "Percentage of no schooling, male population aged 15-24"
label(bl$lu_2534) <- "Percentage of no schooling, population aged 25-34"
label(bl$lu_F_2534) <- "Percentage of no schooling, female population aged 25-34"
label(bl$lu_M_2534) <- "Percentage of no schooling, male population aged 25-34"
label(bl$lu_3544) <- "Percentage of no schooling, population aged 35-44"
label(bl$lu_F_3544) <- "Percentage of no schooling, female population aged 35-44"
label(bl$lu_M_3544) <- "Percentage of no schooling, male population aged 35-44"
label(bl$lu_4554) <- "Percentage of no schooling, population aged 45-54"
label(bl$lu_F_4554) <- "Percentage of no schooling, female population aged 45-54"
label(bl$lu_M_4554) <- "Percentage of no schooling, male population aged 45-54"
label(bl$lu_5564) <- "Percentage of no schooling, population aged 55-64"
label(bl$lu_F_5564) <- "Percentage of no schooling, female population aged 55-64"
label(bl$lu_M_5564) <- "Percentage of no schooling, male population aged 55-64"

label(bl$lp_1524) <- "Percentage of primary schooling, population aged 15-24"
label(bl$lp_F_1524) <- "Percentage of primary schooling, female population aged 15-24"
label(bl$lp_M_1524) <- "Percentage of primary schooling, male population aged 15-24"
label(bl$lp_2534) <- "Percentage of primary schooling, population aged 25-34"
label(bl$lp_F_2534) <- "Percentage of primary schooling, female population aged 25-34"
label(bl$lp_M_2534) <- "Percentage of primary schooling, male population aged 25-34"
label(bl$lp_3544) <- "Percentage of primary schooling, population aged 35-44"
label(bl$lp_F_3544) <- "Percentage of primary schooling, female population aged 35-44"
label(bl$lp_M_3544) <- "Percentage of primary schooling, male population aged 35-44"
label(bl$lp_4554) <- "Percentage of primary schooling, population aged 45-54"
label(bl$lp_F_4554) <- "Percentage of primary schooling, female population aged 45-54"
label(bl$lp_M_4554) <- "Percentage of primary schooling, male population aged 45-54"
label(bl$lp_5564) <- "Percentage of primary schooling, population aged 55-64"
label(bl$lp_F_5564) <- "Percentage of primary schooling, female population aged 55-64"
label(bl$lp_M_5564) <- "Percentage of primary schooling, male population aged 55-64"

label(bl$ls_1524) <- "Percentage of secondary schooling, population aged 15-24"
label(bl$ls_F_1524) <- "Percentage of secondary schooling, female population aged 15-24"
label(bl$ls_M_1524) <- "Percentage of secondary schooling, male population aged 15-24"
label(bl$ls_2534) <- "Percentage of secondary schooling, population aged 25-34"
label(bl$ls_F_2534) <- "Percentage of secondary schooling, female population aged 25-34"
label(bl$ls_M_2534) <- "Percentage of secondary schooling, male population aged 25-34"
label(bl$ls_3544) <- "Percentage of secondary schooling, population aged 35-44"
label(bl$ls_F_3544) <- "Percentage of secondary schooling, female population aged 35-44"
label(bl$ls_M_3544) <- "Percentage of secondary schooling, male population aged 35-44"
label(bl$ls_4554) <- "Percentage of secondary schooling, population aged 45-54"
label(bl$ls_F_4554) <- "Percentage of secondary schooling, female population aged 45-54"
label(bl$ls_M_4554) <- "Percentage of secondary schooling, male population aged 45-54"
label(bl$ls_5564) <- "Percentage of secondary schooling, population aged 55-64"
label(bl$ls_F_5564) <- "Percentage of secondary schooling, female population aged 55-64"
label(bl$ls_M_5564) <- "Percentage of secondary schooling, male population aged 55-64"

label(bl$lh_1524) <- "Percentage of tertiary schooling, population aged 15-24"
label(bl$lh_F_1524) <- "Percentage of tertiary schooling, female population aged 15-24"
label(bl$lh_M_1524) <- "Percentage of tertiary schooling, male population aged 15-24"
label(bl$lh_2534) <- "Percentage of tertiary schooling, population aged 25-34"
label(bl$lh_F_2534) <- "Percentage of tertiary schooling, female population aged 25-34"
label(bl$lh_M_2534) <- "Percentage of tertiary schooling, male population aged 25-34"
label(bl$lh_3544) <- "Percentage of tertiary schooling, population aged 35-44"
label(bl$lh_F_3544) <- "Percentage of tertiary schooling, female population aged 35-44"
label(bl$lh_M_3544) <- "Percentage of tertiary schooling, male population aged 35-44"
label(bl$lh_4554) <- "Percentage of tertiary schooling, population aged 45-54"
label(bl$lh_F_4554) <- "Percentage of tertiary schooling, female population aged 45-54"
label(bl$lh_M_4554) <- "Percentage of tertiary schooling, male population aged 45-54"
label(bl$lh_5564) <- "Percentage of tertiary schooling, population aged 55-64"
label(bl$lh_F_5564) <- "Percentage of tertiary schooling, female population aged 55-64"
label(bl$lh_M_5564) <- "Percentage of tertiary schooling, male population aged 55-64"

label(bl$lpc_1524) <- "Percentage of complete primary schooling, population aged 15-24"
label(bl$lpc_F_1524) <- "Percentage of complete primary schooling, female population aged 15-24"
label(bl$lpc_M_1524) <- "Percentage of complete primary schooling, male population aged 15-24"
label(bl$lpc_2534) <- "Percentage of complete primary schooling, population aged 25-34"
label(bl$lpc_F_2534) <- "Percentage of complete primary schooling, female population aged 25-34"
label(bl$lpc_M_2534) <- "Percentage of complete primary schooling, male population aged 25-34"
label(bl$lpc_3544) <- "Percentage of complete primary schooling, population aged 35-44"
label(bl$lpc_F_3544) <- "Percentage of complete primary schooling, female population aged 35-44"
label(bl$lpc_M_3544) <- "Percentage of complete primary schooling, male population aged 35-44"
label(bl$lpc_4554) <- "Percentage of complete primary schooling, population aged 45-54"
label(bl$lpc_F_4554) <- "Percentage of complete primary schooling, female population aged 45-54"
label(bl$lpc_M_4554) <- "Percentage of complete primary schooling, male population aged 45-54"
label(bl$lpc_5564) <- "Percentage of complete primary schooling, population aged 55-64"
label(bl$lpc_F_5564) <- "Percentage of complete primary schooling, female population aged 55-64"
label(bl$lpc_M_5564) <- "Percentage of complete primary schooling, male population aged 55-64"

label(bl$lsc_1524) <- "Percentage of complete secondary schooling, population aged 15-24"
label(bl$lsc_F_1524) <- "Percentage of complete secondary schooling, female population aged 15-24"
label(bl$lsc_M_1524) <- "Percentage of complete secondary schooling, male population aged 15-24"
label(bl$lsc_2534) <- "Percentage of complete secondary schooling, population aged 25-34"
label(bl$lsc_F_2534) <- "Percentage of complete secondary schooling, female population aged 25-34"
label(bl$lsc_M_2534) <- "Percentage of complete secondary schooling, male population aged 25-34"
label(bl$lsc_3544) <- "Percentage of complete secondary schooling, population aged 35-44"
label(bl$lsc_F_3544) <- "Percentage of complete secondary schooling, female population aged 35-44"
label(bl$lsc_M_3544) <- "Percentage of complete secondary schooling, male population aged 35-44"
label(bl$lsc_4554) <- "Percentage of complete secondary schooling, population aged 45-54"
label(bl$lsc_F_4554) <- "Percentage of complete secondary schooling, female population aged 45-54"
label(bl$lsc_M_4554) <- "Percentage of complete secondary schooling, male population aged 45-54"
label(bl$lsc_5564) <- "Percentage of complete secondary schooling, population aged 55-64"
label(bl$lsc_F_5564) <- "Percentage of complete secondary schooling, female population aged 55-64"
label(bl$lsc_M_5564) <- "Percentage of complete secondary schooling, male population aged 55-64"

label(bl$lhc_1524) <- "Percentage of complete tertiary schooling, population aged 15-24"
label(bl$lhc_F_1524) <- "Percentage of complete tertiary schooling, female population aged 15-24"
label(bl$lhc_M_1524) <- "Percentage of complete tertiary schooling, male population aged 15-24"
label(bl$lhc_2534) <- "Percentage of complete tertiary schooling, population aged 25-34"
label(bl$lhc_F_2534) <- "Percentage of complete tertiary schooling, female population aged 25-34"
label(bl$lhc_M_2534) <- "Percentage of complete tertiary schooling, male population aged 25-34"
label(bl$lhc_3544) <- "Percentage of complete tertiary schooling, population aged 35-44"
label(bl$lhc_F_3544) <- "Percentage of complete tertiary schooling, female population aged 35-44"
label(bl$lhc_M_3544) <- "Percentage of complete tertiary schooling, male population aged 35-44"
label(bl$lhc_4554) <- "Percentage of complete tertiary schooling, population aged 45-54"
label(bl$lhc_F_4554) <- "Percentage of complete tertiary schooling, female population aged 45-54"
label(bl$lhc_M_4554) <- "Percentage of complete tertiary schooling, male population aged 45-54"
label(bl$lhc_5564) <- "Percentage of complete tertiary schooling, population aged 55-64"
label(bl$lhc_F_5564) <- "Percentage of complete tertiary schooling, female population aged 55-64"
label(bl$lhc_M_5564) <- "Percentage of complete tertiary schooling, male population aged 55-64"

label(bl$yr_sch_1524) <- "Average years of schooling attained, population aged 15-24"
label(bl$yr_sch_F_1524) <- "Average years of schooling attained, female population aged 15-24"
label(bl$yr_sch_M_1524) <- "Average years of schooling attained, male population aged 15-24"
label(bl$yr_sch_2534) <- "Average years of schooling attained, population aged 25-34"
label(bl$yr_sch_F_2534) <- "Average years of schooling attained, female population aged 25-34"
label(bl$yr_sch_M_2534) <- "Average years of schooling attained, male population aged 25-34"
label(bl$yr_sch_3544) <- "Average years of schooling attained, population aged 35-44"
label(bl$yr_sch_F_3544) <- "Average years of schooling attained, female population aged 35-44"
label(bl$yr_sch_M_3544) <- "Average years of schooling attained, male population aged 35-44"
label(bl$yr_sch_4554) <- "Average years of schooling attained, population aged 45-54"
label(bl$yr_sch_F_4554) <- "Average years of schooling attained, female population aged 45-54"
label(bl$yr_sch_M_4554) <- "Average years of schooling attained, male population aged 45-54"
label(bl$yr_sch_5564) <- "Average years of schooling attained, population aged 55-64"
label(bl$yr_sch_F_5564) <- "Average years of schooling attained, female population aged 55-64"
label(bl$yr_sch_M_5564) <- "Average years of schooling attained, male population aged 55-64"

label(bl$yr_sch_pri_1524) <- "Average years of primary schooling attained, population aged 15-24"
label(bl$yr_sch_pri_F_1524) <- "Average years of primary schooling attained, female population aged 15-24"
label(bl$yr_sch_pri_M_1524) <- "Average years of primary schooling attained, male population aged 15-24"
label(bl$yr_sch_pri_2534) <- "Average years of primary schooling attained, population aged 25-34"
label(bl$yr_sch_pri_F_2534) <- "Average years of primary schooling attained, female population aged 25-34"
label(bl$yr_sch_pri_M_2534) <- "Average years of primary schooling attained, male population aged 25-34"
label(bl$yr_sch_pri_3544) <- "Average years of primary schooling attained, population aged 35-44"
label(bl$yr_sch_pri_F_3544) <- "Average years of primary schooling attained, female population aged 35-44"
label(bl$yr_sch_pri_M_3544) <- "Average years of primary schooling attained, male population aged 35-44"
label(bl$yr_sch_pri_4554) <- "Average years of primary schooling attained, population aged 45-54"
label(bl$yr_sch_pri_F_4554) <- "Average years of primary schooling attained, female population aged 45-54"
label(bl$yr_sch_pri_M_4554) <- "Average years of primary schooling attained, male population aged 45-54"
label(bl$yr_sch_pri_5564) <- "Average years of primary schooling attained, population aged 55-64"
label(bl$yr_sch_pri_F_5564) <- "Average years of primary schooling attained, female population aged 55-64"
label(bl$yr_sch_pri_M_5564) <- "Average years of primary schooling attained, male population aged 55-64"

label(bl$yr_sch_sec_1524) <- "Average years of secondary schooling attained, population aged 15-24"
label(bl$yr_sch_sec_F_1524) <- "Average years of secondary schooling attained, female population aged 15-24"
label(bl$yr_sch_sec_M_1524) <- "Average years of secondary schooling attained, male population aged 15-24"
label(bl$yr_sch_sec_2534) <- "Average years of secondary schooling attained, population aged 25-34"
label(bl$yr_sch_sec_F_2534) <- "Average years of secondary schooling attained, female population aged 25-34"
label(bl$yr_sch_sec_M_2534) <- "Average years of secondary schooling attained, male population aged 25-34"
label(bl$yr_sch_sec_3544) <- "Average years of secondary schooling attained, population aged 35-44"
label(bl$yr_sch_sec_F_3544) <- "Average years of secondary schooling attained, female population aged 35-44"
label(bl$yr_sch_sec_M_3544) <- "Average years of secondary schooling attained, male population aged 35-44"
label(bl$yr_sch_sec_4554) <- "Average years of secondary schooling attained, population aged 45-54"
label(bl$yr_sch_sec_F_4554) <- "Average years of secondary schooling attained, female population aged 45-54"
label(bl$yr_sch_sec_M_4554) <- "Average years of secondary schooling attained, male population aged 45-54"
label(bl$yr_sch_sec_5564) <- "Average years of secondary schooling attained, population aged 55-64"
label(bl$yr_sch_sec_F_5564) <- "Average years of secondary schooling attained, female population aged 55-64"
label(bl$yr_sch_sec_M_5564) <- "Average years of secondary schooling attained, male population aged 55-64"

label(bl$yr_sch_ter_1524) <- "Average years of tertiary schooling attained, population aged 15-24"
label(bl$yr_sch_ter_F_1524) <- "Average years of tertiary schooling attained, female population aged 15-24"
label(bl$yr_sch_ter_M_1524) <- "Average years of tertiary schooling attained, male population aged 15-24"
label(bl$yr_sch_ter_2534) <- "Average years of tertiary schooling attained, population aged 25-34"
label(bl$yr_sch_ter_F_2534) <- "Average years of tertiary schooling attained, female population aged 25-34"
label(bl$yr_sch_ter_M_2534) <- "Average years of tertiary schooling attained, male population aged 25-34"
label(bl$yr_sch_ter_3544) <- "Average years of tertiary schooling attained, population aged 35-44"
label(bl$yr_sch_ter_F_3544) <- "Average years of tertiary schooling attained, female population aged 35-44"
label(bl$yr_sch_ter_M_3544) <- "Average years of tertiary schooling attained, male population aged 35-44"
label(bl$yr_sch_ter_4554) <- "Average years of tertiary schooling attained, population aged 45-54"
label(bl$yr_sch_ter_F_4554) <- "Average years of tertiary schooling attained, female population aged 45-54"
label(bl$yr_sch_ter_M_4554) <- "Average years of tertiary schooling attained, male population aged 45-54"
label(bl$yr_sch_ter_5564) <- "Average years of tertiary schooling attained, population aged 55-64"
label(bl$yr_sch_ter_F_5564) <- "Average years of tertiary schooling attained, female population aged 55-64"
label(bl$yr_sch_ter_M_5564) <- "Average years of tertiary schooling attained, male population aged 55-64"

label(bl$pop_1524) <- "Population aged 15-24 (1000s)"
label(bl$pop_F_1524) <- "Female population aged 15-24 (1000s)"
label(bl$pop_M_1524) <- "Male population aged 15-24 (1000s)"
label(bl$pop_2534) <- "Population aged 25-34 (1000s)"
label(bl$pop_F_2534) <- "Female population aged 25-34 (1000s)"
label(bl$pop_M_2534) <- "Male population aged 25-34 (1000s)"
label(bl$pop_3544) <- "Population aged 35-44 (1000s)"
label(bl$pop_F_3544) <- "Female population aged 35-44 (1000s)"
label(bl$pop_M_3544) <- "Male population aged 35-44 (1000s)"
label(bl$pop_4554) <- "Population aged 45-54 (1000s)"
label(bl$pop_F_4554) <- "Female population aged 45-54 (1000s)"
label(bl$pop_M_4554) <- "Male population aged 45-54 (1000s)"
label(bl$pop_5564) <- "Population aged 55-64 (1000s)"
label(bl$pop_F_5564) <- "Female population aged 55-64 (1000s)"
label(bl$pop_M_5564) <- "Male population aged 55-64 (1000s)"

# suffix
bl <- append_suffix(bl, "BL")

# Save
saveRDS(bl, file = paste(preppeddata,"Prepped_BL_2022.RDS", sep=""))
