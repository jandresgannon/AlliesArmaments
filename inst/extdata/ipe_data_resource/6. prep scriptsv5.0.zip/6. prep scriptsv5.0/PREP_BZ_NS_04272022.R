# /***************************
# World Bank Doing Business Indicators
# 
# URL: https://databank.worldbank.org/source/doing-business#
# 
# Countries: 
# Time Period: 2004-2020
#
# Natalie Song
# ****************************/

rm(list = ls())

# paths
rawdata <- "G:/.shortcut-targets-by-id/0B2iwvlsRgy8tQXlVNll5WWhLcGs/Master IPE Data/SPRING 2022/rawdata/"
ids_path <- "G:/.shortcut-targets-by-id/1JpiIrqOeS1K9UlbREPhw_iziB-QxPH91/append_ids/"
preppeddata <- "G:/.shortcut-targets-by-id/0B2iwvlsRgy8tQXlVNll5WWhLcGs/Master IPE Data/SPRING 2022/prepped/"
prepscripts <- "G:/.shortcut-targets-by-id/0B2iwvlsRgy8tQXlVNll5WWhLcGs/Master IPE Data/SPRING 2022/scripts/"
source(paste(ids_path,"append_ids.R",sep=""))

# import
bz <- read.csv(paste(rawdata, "RAWDATA_BZ_2022.csv", sep=""))

# pivot longer and rename some variables
library(dplyr)
library(tidyverse)
bz <- bz %>%
  rename("variable" = Series.Name) %>%
  pivot_longer(names_to = "year",
               values_to = "value",
               c("X2004..YR2004.", "X2005..YR2005.", "X2006..YR2006.", "X2007..YR2007.", "X2008..YR2008.", "X2009..YR2009.", "X2010..YR2010.", "X2011..YR2011.", "X2012..YR2012.", "X2013..YR2013.", "X2014..YR2014.", "X2015..YR2015.", "X2016..YR2016.", "X2017..YR2017.", "X2018..YR2018.", "X2019..YR2019.", "X2020..YR2020.")) %>%
  select(-Series.Code, -Country.Code) %>%
  rename("country" = �..Country.Name)

# fix year variable
bz$year <- substr(bz$year, 2, 5)
bz$year <- as.numeric(bz$year)

# pivot wider
bz <- bz %>%
  pivot_wider(names_from = variable,
              values_from = value,
              names_repair = "minimal",
              values_fn = list)

# duplicate check
n_occur <- data.frame(table(bz$country, bz$year)) # are there any duplicate country-years?
print(n_occur[n_occur$Freq > 1,])

# append IDs!!
bz <- append_ids(bz, breaks = F)

# check for duplicates
n_occur <- data.frame(table(bz$country, bz$year))
print(n_occur[n_occur$Freq > 1,])

# add suffixes
bz <- append_suffix(bz,"BZ")

