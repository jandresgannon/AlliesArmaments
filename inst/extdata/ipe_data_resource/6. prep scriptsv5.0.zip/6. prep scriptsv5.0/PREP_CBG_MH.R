###############################
# Data on Central Bank Governors
# Accessed: September 20, 2017
# Year Range: 1970-2014
# Prepped By: Molly He
# Revised by: Suzie Mulesky (5/7/2018)
# Revised by: Miriam Barnum (5/14/2020)
# Suffix: CBG
#
# Data Source: https://www.kof.ethz.ch/services/daten/data-on-central-bank-governors.html
# Codebook: Look under the "notes" spreadsheet from downloaded data
#
# Citations: 
# Dreher, Axel, Jan-Egbert Sturm and Jakob de Haan (2010), 
# When is a Central Bank Governor Replaced? Evidence Based on a New Data Set, 
# Journal of Macroeconomics, 32, 766-781.
# 
# Dreher, Axel, Jan-Egbert Sturm and Jakob de Haan (2008), Does high inflation 
# cause central bankers to lose their job? Evidence based on a new data set, 
# European Journal of Political Economy, 24:4, 778-787.
# 
# Sturm, Jan-Egbert and Jakob de Haan (2001), Inflation in developing countries: 
# does central bank independence matter?, Ifo Studien, 47:4, 389-403.
# 
# Variables:
# - bankscount_CBG: Count of central banks
# - timetoturn_CBG: Time to regular turnover
# - numturnover_CBG: Number of actual turnovers
# - regturndummy_CBG: Regular turnover dummy
# - irregturndummy_CBG: Irregular turnover dummy
# - timeinoffice_CBG: Time in office 
# - legalduration_CBG: Legal duration
# 
###############################

# --- hmisc will be needed for all packages as we use it for the append_ids function
library(Hmisc)
library(readxl)

# --- importing dataset
cbg <- read_excel(paste(rawdata,"RAWDATA_CBG_2018.xlsx", sep=""), 
                  sheet = "data v2018", col_names = TRUE)

#Rename variables
names(cbg)[names(cbg)=="country"] = "countryname"
names(cbg)[names(cbg)=="count central banks"] = "bankscount"
names(cbg)[names(cbg)=="time to regular turnover"] = "timetoturn"
names(cbg)[names(cbg)=="number of actual turnovers"] = "numturnover"
names(cbg)[names(cbg)=="regular turnover dummy"] = "regturndummy"
names(cbg)[names(cbg)=="irregular turnover dummy"] = "irregturndummy"
names(cbg)[names(cbg)=="time in office"] = "timeinoffice"
names(cbg)[names(cbg)=="legal duration"] = "legalduration"

#Keep only variables needed
keepCols = c("countryname", "year", "bankscount", "timetoturn", 
             "numturnover", "regturndummy", "irregturndummy", 
             "timeinoffice", "legalduration")
cbg = cbg[keepCols]

#Change data types
str(cbg)
table(cbg$timetoturn)
cbg$timetoturn = as.numeric(cbg$timetoturn)
cbg$numturnover = as.numeric(cbg$numturnover)
cbg$regturndummy = as.numeric(cbg$regturndummy)
cbg$irregturndummy = as.numeric(cbg$irregturndummy)
cbg$timeinoffice = as.numeric(cbg$timeinoffice)
cbg$legalduration = as.numeric(cbg$legalduration)

# check for duplicates
n_occur <- data.frame(table(cbg$countryname, cbg$year))
n_occur[n_occur$Freq>1,]

#Append country IDs
cbg = append_ids(cbg)
cbg = append_suffix(cbg,"CBG")

# check for duplicates
n_occur <- data.frame(table(cbg$gwno, cbg$year))
n_occur[n_occur$Freq>1,]

str(cbg)

#Add variable labels
label(cbg$bankscount_CBG) = "Count of central banks [CBG]"
label(cbg$timetoturn_CBG) = "Time to regular turnover [CBG]"
label(cbg$numturnover_CBG) = "Number of actual turnovers [CBG]"
label(cbg$regturndummy_CBG) = "Regular turnover dummy [CBG]"
label(cbg$irregturndummy_CBG) = "Irregular turnover dummy [CBG]"
label(cbg$timeinoffice_CBG) = "Time in office [CBG]"
label(cbg$legalduration_CBG) = "Legal duration [CBG]"

##########
#saving prepped data
save(cbg,file=paste(preppeddata,"PREPPED_CBG_MH_MB_20514020.RDATA",sep=""))

#write.csv(cbg,file=paste(preppeddata,"PREPPED_CBG_MH_SM_20180507.csv",sep=""))

