###############################
# Central Bank Intelligence data, Garriga
# Accessed 05/07/2019
# Year Range: 1970-2012
# Suffix: cbi
# Dataset last update: 2019
#
# Data: https://sites.google.com/site/carogarriga/cbi-data-1
# "cbi Dataset Garriga"
#
# Citation: (retrieved from https://sites.google.com/site/carogarriga/cbi-data-1)
# Garriga, Ana Carolina.  2016.  Central Bank Independence in the World: A New Dataset. International Interactions 42 (5):849-868  
# doi: 10.1080/03050629.2016.1188813
#
# Variables: creation, reform, direction, increase, decrease, regional, lvau_garriga: cbi Index (Unweighted), lvaw_garriga: cbi Index (Weighted)
#
# Prepped by Stephen Campbell, 04/2018
# Updated by Gaea Morales, 05/2022
################################

library(readxl)
library(Hmisc)

library(dplyr)
library(tidyr)
library(stringr)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"
ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"

source(paste0(ids_path, "append_ids.R"))

# Load in data 
cbi <- read_excel(paste0(rawdata, "RAWDATA_cbi_2019_GM.xlsx"))

#remove unused variables
cbi <- cbi[,c("cname","year","creation", "reform", "direction", "increase", "decrease", "regional", "lvau_garriga", "lvaw_garriga")]

#rename variables
names(cbi)[names(cbi)=="cname"] = "Country"
names(cbi)[names(cbi)=="year"] = "Year"

#convert data to numerics, from atomic vector to num
cbi$Year = as.numeric(cbi$Year)
cbi$creation = as.numeric(cbi$creation)
cbi$reform = as.numeric(cbi$reform)
cbi$direction = as.numeric(cbi$direction)
cbi$increase = as.numeric(cbi$increase)
cbi$decrease = as.numeric(cbi$decrease)
cbi$regional = as.numeric(cbi$regional)
cbi$lvau_garriga = as.numeric(cbi$lvau_garriga)
cbi$lvaw_garriga = as.numeric(cbi$lvaw_garriga)

#change labels
label(cbi$lvau_garriga) <- "cbi Index (Unweighted) [cbi]"
label(cbi$lvaw_garriga) <- "cbi Index (Weighted) [cbi]"

#appending gwnos
cbi = append_ids(cbi, breaks = F)
cbi = append_suffix(cbi, "CBI")

range(cbi$year) # 1970 2012
length(unique(cbi$gwno)) # 184

n_occur <- data.frame(table(cbi$gwno, cbi$year))
print(n_occur[n_occur$Freq > 1,])

#save data, finished 
saveRDS(cbi, paste(preppeddata,"PREPPED_CBI_GM_05172022.RDS"))

