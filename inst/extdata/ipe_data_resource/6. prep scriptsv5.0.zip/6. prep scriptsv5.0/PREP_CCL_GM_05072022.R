###############################
# Comparative Competition Law [CCL]
# Gaea Morales
# Spring 2022
# Updated: 05/17/2022
# Accessed: http://comparativecompetitionlaw.org//data-for-download/

library(tidyverse)
library(Hmisc)
library(haven)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"
ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"

source(paste0(ids_path, "append_ids.R"))

# Load data 
ccl <- read_dta(paste0(rawdata, "RAWDATA_CCL_2010_GM.dta"))

ccl2 <- ccl %>% 
  select(-c(code_cown, code_cowc, territory, regional_group)) %>% 
  group_by(country, year) %>% 
  distinct() %>% # check for duplicates
  append_ids(breaks=F) %>% 
  filter(!c(country == "Canada" & competition_law_in_place == 0)) %>% 
  filter(!c(country == "Canada" & year >= 2005 & goals_protect_smallmid == 0)) %>% 
  filter(!c(country == "Yemen (Arab Republic of Yemen)" & countryname_raw == "Yemen")) %>% 
  filter(!c(country == "Czechoslovakia" & observation_added == 1)) %>% 
  filter(!c(country == "German Federal Republic" & competition_law_coded == 0)) %>% 
  append_suffix("CCL")

#Check for Duplicates
n_occur <- data.frame(table(ccl2$country, ccl2$year))
print(n_occur[n_occur$Freq > 1,])

saveRDS(ccl2, paste(preppeddata, "PREPPED_CCL_GM_061722.RDS"))


