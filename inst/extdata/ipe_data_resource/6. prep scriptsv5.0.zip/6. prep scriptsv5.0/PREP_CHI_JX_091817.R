# /**************************
# Data:  Change in Source of Leader Support (CHISOLS)
# Data source url: http://www.chisols.org/data-sets.html
# User's Manual: http://www.chisols.org/uploads/1/1/2/6/11264284/chisolsusermanualv4.0.pdf
# Time: 1919-2008
# Updated: September 18, 2017
# By: Jessica Xu 
# Revised by: Suzie Mulesky (5/7/2018)
# Suffix: CHI
# Citation: Mattes, Michaela, Brett Ashley Leeds, and Naoko Matsumura. Forthcoming. Measuring Change in Source of Leader Support: The CHISOLS Dataset. Journal of Peace Research.
# 
# Variables:
# leader_CHI = "The name of the country's leader in a given year. If there were multiple leaders, their names are separated by commas [CHI]"
# leaderpos_CHI = "The official title of the leader in the given year [CHI]"
# totalldrtrans_CHI = "A count of the leader transitions in the given year [CHI]"
# leadertrans_CHI = "Coded 1 if there is at least one leadership transition in a given year and 0 otherwise [CHI]"
# solschange_CHI = "This variable is equal to the count of SOLS changes during the country-year in which the new SOLS was in power for more than 30 days in a row. Coded 0 if there are no SOLS changes in the year that last more than 30 days total. This count variable does not include minor SOLS changes nor SOLS changes that last less than 30 days [CHI]"
# solschdum_CHI = "Coded 1 if there is at least one SOLS change that lasts longer than 30 days in the year, and 0 otherwise. This variable does not take into account minor SOLS changes, nor SOLS changes that last less than 30 days [CHI]"
# solschange30_CHI = "This variable is equal to the count of SOLS changes during the country-year in which the new SOLS was in power for less than 30 days total. Coded 0 if there are no SOLS changes in the year that lasted less than 30 days [CHI]"
# solsch30dum_CHI = "This variable is coded 1 if there is at least one SOLS change that lasts less than 30 days and 0 otherwise [CHI]"
# solsminchange_CHI = "This variable is equal to the count of minor SOLS changes during the country-year. Coded 0 if there are no minor SOLS changes in the country-year [CHI]"
# solsminchdum_CHI = "This variable is coded 1 if there is at least one minor SOLS change during the country-year and 0 otherwise [CHI]"
# #****************************/

library(Hmisc)
library(readxl)
library(dplyr)
library(tidyr)

#read the csv file
CHI <- read.csv(paste(rawdata, "RAWDATA_CHI_JX.csv", sep=""))

#remove unnecessary variables
CHI <- CHI[-c(2,6, 15:113)]

#renaming variables
names(CHI)[names(CHI)=="statename"]="Country"

str(CHI)

# Check duplicates
n_occur <- data.frame(table(CHI$Country, CHI$year))
n_occur [n_occur$Freq > 1,]

#appending gwnos
CHI= append_ids(CHI, breaks = FALSE)

#append suffix
CHI = append_suffix(CHI, "CHI")

# --- Drop duplicates
# Check duplicates
n_occur <- data.frame(table(CHI$gwno, CHI$year))
n_occur [n_occur$Freq > 1,]
# Germany/West Germany - drop the 1990 West Germany observation
CHI <- CHI[!(CHI$countryname_raw_CHI == "German Federal Republic" & CHI$year == 1990),]
# Yemen/North Yemen - drop the 1990 North Yemen observation
CHI <- CHI[!(CHI$countryname_raw_CHI == "Yemen Arab Republic" & CHI$year == 1990),]
# Check duplicates
n_occur <- data.frame(table(CHI$gwno, CHI$year))
n_occur [n_occur$Freq > 1,]

#check the range and year range
length(unique(CHI$gwno)) # 169
range(CHI$year) # 1919-2008

str(CHI)

# Add variable labels
label(CHI$leader_CHI) = "The name of the country's leader in a given year. If there were multiple leaders, their names are separated by commas [CHI]"
label(CHI$leaderpos_CHI) = "The official title of the leader in the given year [CHI]"
label(CHI$totalldrtrans_CHI) = "A count of the leader transitions in the given year [CHI]"
label(CHI$leadertrans_CHI) = "Coded 1 if there is at least one leadership transition in a given year and 0 otherwise [CHI]"
label(CHI$solschange_CHI) = "This variable is equal to the count of SOLS changes during the country-year in which the new SOLS was in power for more than 30 days in a row. Coded 0 if there are no SOLS changes in the year that last more than 30 days total. This count variable does not include minor SOLS changes nor SOLS changes that last less than 30 days [CHI]"
label(CHI$solschdum_CHI) = "Coded 1 if there is at least one SOLS change that lasts longer than 30 days in the year, and 0 otherwise. This variable does not take into account minor SOLS changes, nor SOLS changes that last less than 30 days [CHI]"
label(CHI$solschange30_CHI) = "This variable is equal to the count of SOLS changes during the country-year in which the new SOLS was in power for less than 30 days total. Coded 0 if there are no SOLS changes in the year that lasted less than 30 days [CHI]"
label(CHI$solsch30dum_CHI) = "This variable is coded 1 if there is at least one SOLS change that lasts less than 30 days and 0 otherwise [CHI]"
label(CHI$solsminchange_CHI) = "This variable is equal to the count of minor SOLS changes during the country-year. Coded 0 if there are no minor SOLS changes in the country-year [CHI]"
label(CHI$solsminchdum_CHI) = "This variable is coded 1 if there is at least one minor SOLS change during the country-year and 0 otherwise [CHI]"


#save the file 
save(CHI,file=paste(preppeddata,"PREPPED_CHI_JX_SM_20180507.RDATA",sep=""))

#write.csv(CHI,file=paste(preppeddata,"PREPPED_CHI_JX_SM_20180507.csv",sep=""))