#######################
# Contract Intensity of National Economies [CINE]
# Gaea Morales 
# Spring 2022  
# Updated: 05/17/22
# Accessed: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/8RPC9E


library(tidyverse)
library(Hmisc)
library(haven)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"
ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"

source(paste0(ids_path, "append_ids.R"))


# Read in .dta file 
cine <- read_dta(paste0(rawdata, "RAWDATA_CINE_2021_GM.dta"))

cine2 <- cine %>% 
  select(-micro) %>% 
  group_by(ccode, year) %>% 
  distinct() %>% # double check duplicates 
  rename("countryname" = cname) %>% 
  select(-c(version)) %>% 
  append_ids(breaks = F) %>% # append_ids
  filter(!(gwno == 678 & year == 1990 & ccode_raw == 678)) %>%  # filter out duplicate Yemen 
  append_suffix("CINE") 

#add labels
label(cine2$CIE_CINE) <- "Contract intensive economy (continuous)"
label(cine2$CIEb_CINE) <- "Contract intensive economy (binary)"
label(cine2$SEI_CINE) <- "Sustained economic immigration (binary)"
label(cine2$LID_CINE) <- "Life insurance revenue per capita"


saveRDS(cine2, file = paste(preppeddata, "PREPPED_CINE_GM_05172022.rds"))
