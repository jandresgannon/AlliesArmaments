# /********************/
# Data: Cingranelli-Richards (CIRI) Human Rights Dataset 
# Version: 2021.01.21
# Datasoure URL: https://www.dropbox.com/sh/t8utmzsvde8m63q/AAAs1_WIJTqXurAE5nvEKWE5a?dl=0
# Codebook URL: https://www.dropbox.com/sh/t8utmzsvde8m63q/AAAs1_WIJTqXurAE5nvEKWE5a?dl=0
# Time: 1981 - 2017
# Original Script by: Emily on 03.30.2018
# Updated by: BT 07/20/2021
# Suffix: CR
# Citations: 
# Cingranelli, David, Mikhail Filippov, and Skip Mark. 2021. The CIRIGHTS Dataset.
#   Version 2021.01.21. The Binghamton University Human Right Institute, www.binghamton.edu/institutes/hri/
# Cingranelli, David, David L. Richards, and K. Chad Clay. 2014. The CIRI Human 
#   Rights Dataset. Version 2014.04.14.
# /*******************/

library(dplyr)
library(Hmisc)

# File paths for Mac users.
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SUMMER 2021/rawdata/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SUMMER 2021/prepped/"
prepscripts <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SUMMER 2021/country-year scripts/" 
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/"

# File paths for PC users.
#setwd("G:/My Drive/")
#rawdata <- "Master IPE Data/SUMMER 2021/rawdata/"
#preppeddata <- "Master IPE Data/SUMMER 2021/prepped/"
#prepscripts <- "Master IPE Data/SUMMER 2021/country-year scripts/" 
#ids_path <- "append_ids/"

# Load the data
#cr <- read.csv(paste(rawdata, "RAWDATA_CIRIGHTS_2021.csv", sep = ""))
cr <- read.csv("/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SUMMER 2021/rawdata/RAWDATA_CIRIGHTS_2021.csv")


# Keep the variables we want
cr <- cr %>% 
  select( -c(ciri, ccode, unctry, unreg, unsubreg, version, X))

#label variables
label(cr$physint) <- "Physical Integrity Rights Index [CIRI]"
label(cr$disap) <- "Disappearance [CIRI]"
label(cr$kill) <- "Extrajudicial Killing [CIRI]"
label(cr$polpris) <- "Political Imprisonment [CIRI]"
label(cr$tort) <- "Torture [CIRI]"
label(cr$emp_index) <- "Empowerment Rights Index [CIRI]"
label(cr$assn) <- "Freedom of Assembly and Association [CIRI]"
label(cr$formov) <- "Freedom of Foreign Movement [CIRI]"
label(cr$dommov) <- "Freedom of Domestic Movement [CIRI]"
label(cr$speech) <- "Freedom of Speech [CIRI]"
label(cr$elecsd) <- "Electoral Self-Determination [CIRI]"
label(cr$rel_free) <- "Freedom of Religion [CIRI]"
label(cr$worker) <- "Worker's Rights [CIRI]"
label(cr$wecon) <- "Women's Economic Rights [CIRI]"
label(cr$wopol) <- "Women's Political Rights [CIRI]"
label(cr$wosoc) <- "Women's Social Rights (discontinued as of 2005/2007)[CIRI]"
label(cr$injud) <- "Independence of the Judiciary [CIRI]"

# append ids
source(paste(ids_path,"append_ids.R",sep=""))
cr <-  append_ids(cr, dyad = F, breaks = F)
cr <-  append_suffix(cr,"CR", dyad = F)

# Remove duplicates introduced by appending ids
cr <-  cr[!duplicated(cr), ]

#number of unique countries
length(unique(cr$gwno)) #198

#range of years in this data set
range(cr$year) #1981 - 2017

#Check for Duplicates
n_occur <- data.frame(table(cr$country, cr$year))
print(n_occur[n_occur$Freq > 1,])

cr <- cr %>% 
  filter(!(country == "Yemen (Arab Republic of Yemen)" & countryname_raw_CR == "Yemen")) %>% 
  filter(!(country == "Czech Republic" & countryname_raw_CR == "Czech Republic"))

# # filter out duplicate country-years which have no data (countries that didn't exist) - MB
# cr <- cr %>% filter_at(9:25, any_vars(!is.na(.)))

saveRDS(cr,file=paste(preppeddata, "PREPPED_CR_BT_GM_05202022.RDS"))
# #saving also as RDS file 
# save(cr, file = paste(preppeddata, "PREPPED_CR_BT_071912.rds"))

