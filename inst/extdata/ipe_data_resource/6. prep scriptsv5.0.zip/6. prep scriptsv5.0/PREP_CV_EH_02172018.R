# /*************************
#   Claessens and van Horen Bank Ownership Data
# 
# Source: Claessens and Van Horen, 2015, 
# "The impact of the global financial crisis on banking globalization", 
# IMF Economic Review, forthcoming.
# 
# URL: http://www.dnb.nl/en/onderzoek-2/databases/bank.jsp
# Updated: 2018.05.05
# By: MC on 2017.02.21
# Edited By: Emily on 2018.05.05
# Edited By: MB on 2020.05.05
# 
# Variable:
# - Count of foreign banks open in a given country in a given year [CV]
# *************************/
library(readxl)
library(tidyr)
library(Hmisc)

cv = read_excel(paste(rawdata,"RAWDATA_CV_2013.xlsx", sep=""), 2)

#Keep only the variables we need
cv = cv[, c("country", "own1995", "own1996", "own1997", "own1998", "own1999",
            "own2000", "own2001", "own2002", "own2003", "own2004", "own2005", 
            "own2006", "own2007", "own2008", "own2009", "own2010", "own2011", 
            "own2012", "own2013")]

cv = pivot_longer(cv, cols= c(-country))

cv$value = as.numeric(cv$value)
cv = aggregate(value~country+name,data=cv,FUN=sum,na.rm=T)

#get rid of "own" in year variable
cv$name <- gsub("own", "", cv$name)
cv$name <- as.numeric(cv$name)
names(cv)[names(cv) == 'name'] <- 'Year'

#Append country IDs
cv = append_ids(cv,breaks=F)

#Add Variable Names

label(cv$value) <- "Count of Foreign Banks Open [CV]"
names(cv)[names(cv) == 'value'] <- 'foreignbkct'

#Append Suffix
cv = append_suffix(cv,"CV") 

# Number of unique countries
length(unique(cv$gwno)) #139

# Range of years
range(cv$year) #1995-2013

save(cv,file=paste(preppeddata,"PREPPED_CV_EH_05052018.RDATA",sep=""))
