# /*************************
# Cheibub et al (DD) Democracy and Dictatorship [DD]
#
# Source: Cheibub, Jos? Antonio, Jennifer Gandhi, and James Raymond Vreeland. 2010. "Democracy and Dictatorship Revisited." Public Choice 143(2-1): 67-101.
#
# Data source URL: https://sites.google.com/site/joseantoniocheibub/datasets/democracy-and-dictatorship-revisited  
#
# Codebook URL: https://sites.google.com/site/joseantoniocheibub/datasets/democracy-and-dictatorship-revisited 
#
# Time: 1946-2008
#
# Suffix: DD
#
# Variables:
# exselec
# legselec
# closed
# dejure
# defacto
# defacto2
# democracy
# regime
# ttd
# tta
# /*************************

library(Hmisc)
library(dplyr)
library(foreign)

# --- Import dataset
dd = read.dta(paste(rawdata,"RAWDATA_DD_2008_Cheibub.dta", sep=""))

# --- Keep only the variables we want
dd = dd[, c("ctryname", 
            "year", 
            "exselec",
            "legselec",
            "closed",
            "dejure",
            "defacto",
            "defacto2",
            "democracy",
            "regime",
            "ttd",
            "tta")]

# --- Rename the country variable so the append_ids function can work
names(dd)[names(dd)=="ctryname"] = "country"

# --- Order rows by country-year
dd = dd[order(dd$country, dd$year),]

# --- Append country IDs
dd = append_ids(dd)
dd = append_suffix(dd,"DD")

# --- Drop the raw country name variable
dd = dd[-c(8)]

# --- Checking for duplicates - there are none
n_occur <- data.frame(table(dd$gwno, dd$year))
n_occur[n_occur$Freq > 1,]

# --- Number of countries in the dataset = 196
n_countries = dd %>%
  group_by(country) %>%
  summarise(n_years = n() ) %>%
  arrange(desc(n_years))
View(n_countries)

# --- Add variable labels
label(dd$exselec_DD) = "Mode of executive election [DD]"
label(dd$legselec_DD) = "Mode of legislative election [DD]"
label(dd$closed_DD) = "Status of legislature [DD]"
label(dd$dejure_DD) = "Legal status of parties [DD]"
label(dd$defacto_DD) = "De facto existence of parties [DD]"
label(dd$defacto2_DD) = "Existence of parties outside regime front [DD]" 
label(dd$democracy_DD) = "Dummy variable for democracy [DD]"
label(dd$regime_DD) = "Regime classification (parliamentary, mil dictatorship, etc.) [DD]"
label(dd$ttd_DD) = "Dummy for transition to democracy [DD]"
label(dd$tta_DD) = "Dummy for transition to dictatorship [DD]"

# --- Saving
save(dd,file=paste(preppeddata,"PREPPED_DD_SCM_270317.RDATA",sep=""))