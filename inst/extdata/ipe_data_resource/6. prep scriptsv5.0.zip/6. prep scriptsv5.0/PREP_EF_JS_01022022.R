################################################################################
# Economic Freedom of the World from the Fraser Institute [EF]
# Accessed: 01/19/2022
# Year Range: 1970-2019
# Prepared by: Affan Rahman
# Last edited by: Jiaming Shi
# Suffix: EF
#
# Data Source: https://www.fraserinstitute.org/economic-freedom/dataset.
#
# Citation: Gwartney, James, Robert A. Lawson, Joshua C. Hall, and Fred McMahon. 
# "Economic Freedom of the World." Fraser Institute. https://www.fraserinstitute.org/economic-freedom/dataset.
#
# Variables: 
# What we keep: countryname, top_margintax, top_margin_payrolltax, state_owned_assets, impartcourts, propright, policerely
# What we drop: other variables since they are not that important
# 
# Labels: 
# Top marginal income tax rate [EF], Top marginal income and payroll tax rate [EF], 
# Protection of property rights [EF], Impartial Courts [EF], 
# Business cost of crime [EF], Reliability of police [EF]
#
################################################################################

#setwd("/Volumes/GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/")

# paths
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/preppeddatav5.0/"
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/" 
  
source(paste(ids_path,"append_ids.R",sep=""))

#hmisc will be needed for all packages as we use it for the append_ids function
library(readxl)
library(Hmisc)

#Loading data.
ef <- read_xlsx(paste(rawdata,"RAWDATA_EF_2021.xlsx", sep=""), 
                col_names = FALSE)

#Deleting rows above the actual data filled with NAs or random values. 
ef <- ef[-c(1, 2, 3), ]

#Adding column headers (original column labels are part of the spreadsheet data)
colnames(ef) <- ef[1,]

#Removing first column which originally contained the variable names.
ef = ef[-c(1),]

#Keeping relevant variables.
ef = ef[, c("Year", 
            "Countries", 
            "1Di Top marginal income tax rate", 
            "1Dii Top marginal income and payroll tax rate",
            "IE State Ownership of Assets",
            "2B  Impartial courts",
            "2C  Protection of property rights",
            "2H Reliability of police")]

#Renaming variables.
names(ef)[names(ef)=="Countries"] = "countryname"
names(ef)[names(ef)=="1Di Top marginal income tax rate"] = "top_margintax"
names(ef)[names(ef)=="1Dii Top marginal income and payroll tax rate"] = "top_margin_payrolltax"
names(ef)[names(ef)=="IE State Ownership of Assets"] = "state_owned_assets"
names(ef)[names(ef)=="2B  Impartial courts"] = "impartcourts"
names(ef)[names(ef)=="2C  Protection of property rights"] = "propright"
names(ef)[names(ef)=="2H Reliability of police"] = "policerely"


#Applying append_ids function. 
ef <- append_ids(ef, breaks = F)

#Checking for duplicates.
n_occur <- data.frame(table(ef$country, ef$year))
print(n_occur[n_occur$Freq > 1,])

#Adding variable labels.
label(ef$top_margintax) = "Top marginal income tax rate [EF]"
label(ef$top_margin_payrolltax) = "Top marginal income and payroll tax rate [EF]"
label(ef$propright) = "Protection of property rights [EF]"
label(ef$impartcourts) = "Impartial courts [EF]"
label(ef$policerely) = "Reliability of police [EF]"
label(ef$state_owned_assets) = "State ownership of assets [EF]"

#Appending suffix RPC to variables. 
ef = append_suffix(ef, "EF")

#Number of countries and years of observations after cleaning.
length(unique(ef$country)) #167
range(ef$year) #1970-2019

saveRDS(ef, file = paste0(preppeddata,"PREPPED_EF_JS_01192022.RDS"))

