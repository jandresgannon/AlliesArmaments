# /************************* 
# Source:  GROWup - Geographical Research On War, Unified Platform 
# Accessed: April 7, 2022
# URL: https://growup.ethz.ch/pfe/
# Query specifications: all countries, all years, variables: egip_groups_count_EP, excl_groups_count_EP, regaut_groups_count_EP, regaut_excl_groups_count_EP, regaut_egip_groups_count_EP, rlvt_groups_count_EP, actv_groups_count_EP, lpop_EP, egippop_EP, legippop_EP, exclpop_EP, lexclpop_EP, discrimpop_EP, ldiscrimpop_EP, maxexclpop_EP, lmaxexclpop_EP, regautpop_EP, regautexclpop_Ep, regautegippop_EP, cntr_relevance_EP
# Time: 1946-2020
# By: Jiaming Shi
# Suffix: EP
# Variables: 
# egip_groups_count_EP: Number of EGIP groups [EP]
# excl_groups_count_EP: Number of MEG groups [EP]
# regaut_groups_count_EP: Number of groups with regional autonomy [EP]
# regaut_excl_groups_count_EP: Number of MEG groups with regional autonomy [EP] 
# regaut_egip_groups_count_EP: Number of EGIP groups with regional autonomy [EP]
# rlvt_groups_count_EP: Number of relevant groups [EP]
# actv_groups_count_EP: Number of active groups [EP]
# lpop_EP: Sum of ethnically relevant population as fraction of total population [EP]
# egippop_EP: Sum of the population of all EGIP groups as fraction of total population [EP]
# legippop_EP: EGIP population as a fraction of ethnically relevant population [EP]
# exclpop_EP: Sum of the population of all MEG groups as fraction of total population [EP]
# lexclpop_EP: MEG population as a fraction of ethnically relevant population [EP]
# discrimpop_EP: Sum of discriminated population as fraction of total population [EP]
# ldiscrimpop_EP: Sum discriminated population as fraction of ethnically relevant population [EP]  
# maxexclpop_EP:  Size of largest MEG group as fraction of total population [EP]
# lmaxexclpop_EP: Size of largest MEG group as fraction of ethnically relevant population [EP]
# regautpop_EP: Sum of population with regional autonomy as fraction of total population [EP]
# regautexclpop_Ep: Sum pop. with regional autonomy and excluded MEG as fraction of total pop. [EP]  
# regautegippop_EP: Sum pop. with regional autonomy and included EGIP as fraction of total pop. [EP]
# cntr_relevance_EP: Is ethnicity relevant at least once in sample period (0=No, 1=Yes) [EP]
# 
# updated by GM 07/14/22
# *************************/

library(Hmisc)
library(readxl)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/"

#make sure it matches codebook

EP <- read_csv(paste(rawdata,"RAWDATA_EP_2021.csv", sep = ""))
source(paste0(ids_path, "append_ids.R"))

names(EP)
#renaming variables
names(EP)[names(EP)=="countryname"]="Country"

#Keep only the variables we need
EP <- EP %>% 
  select("Country","year",
            "egip_groups_count",
            "excl_groups_count",
            "regaut_groups_count", 
            "regaut_excl_groups_count", 
            "regaut_egip_groups_count", 
            "rlvt_groups_count", 
            "actv_groups_count", 
            "lpop", "egippop", 
            "legippop", "exclpop", 
            "lexclpop", "discrimpop", 
            "ldiscrimpop", "maxexclpop", 
            "lmaxexclpop", "regautpop", 
            "regautexclpop", "regautegippop", "cntr_relevance") %>% 
  mutate(cntr_relevance = ifelse(cntr_relevance == "R", 1, 0)) 


#label
label(EP$egip_groups_count) <- "Number of EGIP groups [EP]"
label(EP$excl_groups_count) <- "Number of MEG groups [EP]"
label(EP$regaut_groups_count)<- "Number of groups with regional autonomy [EP]"
label(EP$regaut_excl_groups_count)<- "Number of MEG groups with regional autonomy [EP]" 
label (EP$regaut_egip_groups_count)<- "Number of EGIP groups with regional autonomy [EP]"
label (EP$rlvt_groups_count)<- "Number of relevant groups [EP]"
label (EP$actv_groups_count)<- "Number of active groups [EP]"
label (EP$lpop)<- "Sum of ethnically relevant population as fraction of total population [EP]"
label (EP$egippop)<- "Sum of the population of all EGIP groups as fraction of total population [EP]"
label (EP$legippop)<- "EGIP population as a fraction of ethnically relevant population [EP]"
label (EP$exclpop)<- "Sum of the population of all MEG groups as fraction of total population [EP]"
label (EP$lexclpop)<- "MEG population as a fraction of ethnically relevant population [EP]"
label (EP$discrimpop)<- "Sum of discriminated population as fraction of total population [EP]"
label (EP$ldiscrimpop)<- "Sum discriminated population as fraction of ethnically relevant population [EP]"  
label (EP$maxexclpop)<-  "Size of largest MEG group as fraction of total population [EP]"
label (EP$lmaxexclpop)<-"Size of largest MEG group as fraction of ethnically relevant population [EP]"
label (EP$regautpop)<- "Sum of population with regional autonomy as fraction of total population [EP]"
label (EP$regautexclpop)<- "Sum pop. with regional autonomy and excluded MEG as fraction of total pop. [EP]"  
label (EP$regautegippop)<- "Sum pop. with regional autonomy and included EGIP as fraction of total pop. [EP]"
label(EP$cntr_relevance)<- "Is ethnicity relevant at least once in sample period (0=No, 1=Yes) [EP]"

#appending gwnos
EP = append_ids(EP, breaks = F)

# change Yugoslavia 2006 to Serbia 2006 (gwno and country) to avoid duplidate
EP <- EP %>% 
  mutate(country = ifelse(country == "Yugoslavia" & year == "2006" & countryname_raw == "Serbia", "Serbia", country),
         gwno = ifelse(country == "Serbia" & year == "2006" & countryname_raw == "Serbia", 340, gwno))

# check for duplicates 

n_occur <- data.frame(table(EP$gwno, EP$year))
print(n_occur[n_occur$Freq > 1,])


# Manually add gwno code for some countries
EP$country[EP$ccode == 343] <- "Macedonia"
EP$country[EP$ccode == 572] <- "Swaziland"

#append suffix
EP = append_suffix(EP, "EP") %>% 
  arrange(gwno, year)

# Save prepped data
save(EP,file=paste(preppeddata,"PREPPED_EP_04072022_JS.RDATA",sep=""))
