# /************************* 
# Data: Reporters Without Borders: Freedom of the Press [FP]
# Data source url: https://rsf.org/en/ranking_table?sort=asc&order=Country
# Codebook url: https://rsf.org/en/detailed-methodology

# Time:2012-2022	
# By: Sherry
# Updated: GM 05/20/2022
# Suffix: FP
# 
# Citation:
# Reporters Without Borders. 2017. "World Press Freedom Index". 
# https://rsf.org/en/ranking_table Accessed on May 22, 2017


# *************************/

library(tidyverse)
library(Hmisc)
library(haven)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"
ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"

source(paste0(ids_path, "append_ids.R"))


# Read the excel file that contains year 2012- 2014
FP1 <- read_excel(paste0(rawdata,"RAWDATA_FP_RWB_2014.xlsx",sep="")) %>% 
  select(country = name, Rank.2014 = an2014, Score.2014 = sco2014, Rank.2013 = an2013, Score.2013 = sco2013, Rank.2012 = an2012) %>%
  mutate_all(as.character)

# Read the csv file that contains year 2015 - 2016
FP2 <- read.csv(paste(rawdata,"RAWDATA_FP_RWB_2016.csv",sep=""),header=TRUE, stringsAsFactors=FALSE) %>% 
  select(country = EN_country, Rank.2016 = Rank, Score.2015, Rank.2015, Score.2016 = Overall.Score.2016) %>%
  mutate_all(as.character)

# Read the csv file that contains year 2019 - 2020
FP3 <- read.csv(paste(rawdata,"RAWDATA_FP_2020.csv",sep=""),header=TRUE, stringsAsFactors=FALSE) %>% 
  select(country = EN_country, Rank.2020 = Rank2020, Score.2020, Rank.2019, Score.2019) %>%
  mutate_all(as.character)

# Read the csv file that contains year 

# Merge 
FP <- full_join(FP1, FP2) %>% full_join(FP3) %>%
  pivot_longer(-country) %>%
  mutate(value = gsub(",", ".", value)) %>%
  separate(name, c("var", "year"), "\\.") %>%
  pivot_wider(names_from = "var", values_from = "value") %>%
  mutate_at(vars(-country), as.numeric) %>%
  filter(!(is.na(Rank) & is.na(Score)))

row.names(FP) <- NULL

FP = append_ids(FP, breaks = F)

#Check for Duplicates
n_occur <- data.frame(table(FP$country, FP$year))
print(n_occur[n_occur$Freq > 1,])

# Add variable labels
label(FP$Rank) <- "Reporters without Borders Press Freedom Annual Ranking [FP]"
label(FP$Score) <- "Reporters with Borders Press Freedom Score [FP]"

# Append suffix FP to vairables
FP = append_suffix(FP,"FP")

load(paste0(rawdata,"PREPPED_FP_SW_05152020.RDATA"))

#### 2022 Update 

# Dataset was missing 2017 and 2018 + new data from 2021-2022 

# Read the csv file that contains year 2017
FP4 <- read.csv(paste0(rawdata,"RAWDATA_FP_2017_GM.csv",sep=""),header=T,stringsAsFactors = T) %>% 
  select("year" = `Year..N.`,
         "country" = `EN_country`,
         "Rank_FP" = `Rank.N`,
         "Score_FP" = `Score.N`) %>% 
  sapply(gsub, pattern = ",", replacement= ".") %>% 
  as.data.frame() %>% 
  mutate(year = as.numeric(year),
         Rank_FP = as.numeric(Rank_FP),
         Score_FP = as.numeric(Score_FP)) %>% 
  append_ids(breaks = F)
  

# Read the csv file that contains year 2018 
FP5 <- read.csv(paste0(rawdata,"RAWDATA_FP_2018_GM.csv",sep=""),header=T,stringsAsFactors = T) %>% 
  select("year" = `Year..N.`,
         "country" = `EN_country`,
         "Rank_FP" = `Rank.N`,
         "Score_FP" = `Score.N`) %>% 
  sapply(gsub, pattern = ",", replacement= ".") %>% 
  as.data.frame() %>% 
  mutate(year = as.numeric(year),
         Rank_FP = as.numeric(Rank_FP),
         Score_FP = as.numeric(Score_FP)) %>% 
  append_ids(breaks = F)

# Read the csv file that contains year 2021
FP6 <- read.csv(paste0(rawdata,"RAWDATA_FP_2021_GM.csv",sep=""),header=T,stringsAsFactors = T) %>% 
  select("year" = `Year..N.`,
         "country" = `EN_country`,
         "Rank_FP" = `Rank.N`,
         "Score_FP" = `Score.N`) %>% 
  sapply(gsub, pattern = ",", replacement= ".") %>% 
  as.data.frame() %>% 
  mutate(year = as.numeric(year),
         Rank_FP = as.numeric(Rank_FP),
         Score_FP = as.numeric(Score_FP)) %>% 
  append_ids(breaks = F)

# Read the csv file that contains year 2022
FP7 <- read.csv(paste0(rawdata,"RAWDATA_FP_2022_GM.csv",sep=""),header=T,stringsAsFactors = T) %>% 
  mutate(year = 2022) %>% 
  select("country" = `Country_EN`,
         "year",
         "Rank_FP" = `Rank`,
         "Score_FP" = `Score`) %>% 
  sapply(gsub, pattern = ",", replacement= ".") %>% 
  as.data.frame() %>% 
  mutate(year = as.numeric(year),
         Rank_FP = as.numeric(Rank_FP),
         Score_FP = as.numeric(Score_FP)) %>% 
  append_ids(breaks = F)

# Merge all updated 

FPnew <- full_join(FP4, FP5) %>% 
  full_join(FP6) %>% 
  full_join(FP7)

label(FPnew$Rank_FP) <- "Reporters without Borders Press Freedom Annual Ranking [FP]"
label(FPnew$Score_FP) <- "Reporters with Borders Press Freedom Score [FP]"

# Merge previous version with updated data

FPupdate <- full_join(FP, FPnew) %>% 
  arrange(gwno, year) %>% 
  group_by(gwno, year) %>% 
  distinct() %>% 
  select(-countryname_raw)

#Check for Duplicates
n_occur <- data.frame(table(FPupdate$country, FPupdate$year))
print(n_occur[n_occur$Freq > 1,])

preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/preppeddatav5.0/"
saveRDS(FPupdate,file=paste(preppeddata,"PREPPED_FP_GM_05202022.RDS"))

check <- readRDS(paste(preppeddata,"PREPPED_FP_GM_05202022.RDS"))
