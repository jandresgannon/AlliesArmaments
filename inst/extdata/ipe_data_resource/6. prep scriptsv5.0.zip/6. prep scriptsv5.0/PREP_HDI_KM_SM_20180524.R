###############################
# Howard and Carey (2004) De Facto Judicial Independence
# Accessed by e-mail from authors:
# Year range: 1992-1999
# Number of countries: 177
# Prepped By: Kartik Mathur
# Revised by: Suzie Mulesky (May 1, 2018)
# Suffix: HDI
#
# Data source: Data received via e-mail.
# Codebook: N/A
# Citation: Howard, Robert M. and Henry F. Carey (2004) "Is an Independent Judiciary Necessary for Democracy?" Judicature 87(6): 284-290. 

# Variables:
# injud_HDI: No judicial independence [HDI]
# midjud_HDI: Partial judicial independence [HDI]
# fulljud_HDI: Full judicial independence [HDI]
###############################

#importing library to read excel file
library(readxl)
library(Hmisc)
library(foreign)
library(stringr)

#import
hdi <- read_excel(paste(rawdata, "RAWDATA_HDI_KM.xls", sep=""))

#Keeping the variables
variables <- c("country","year","indjud", "midjud", "fulidjud")
hdi <- hdi[variables]
hdi$country <- str_to_title(hdi$country)

# Checking for duplicates
n_occur <- data.frame(table(hdi$country, hdi$year))
n_occur[n_occur$Freq > 1,]

str(hdi)

# Appending IDs
hdi <- append_ids(hdi, breaks = FALSE)

#Append Suffix
hdi <- append_suffix(hdi, "HDI")

# Checking for duplicates
n_occur <- data.frame(table(hdi$gwno, hdi$year))
n_occur[n_occur$Freq > 1,]

sum(is.na(hdi$gwno))
str(hdi)
range(hdi$year) # 1992-1999
length(unique(hdi$gwno)) # 177 countries

table(hdi$indjud_HDI)
table(hdi$midjud_HDI)
table(hdi$fulidjud_HDI)

# Add variable labels
label(hdi$indjud_HDI) <- "De facto judicial independence [HDI]"
label(hdi$midjud_HDI) <- "Partial judicial independence [HDI]"
label(hdi$fulidjud_HDI) <- "Full judicial independence [HDI]"

#save prepped data
save(hdi,file=paste(preppeddata,"PREPPED_HDI_SM_20180520.RDATA",sep=""))

#write.csv(hdi,file=paste(preppeddata,"PREPPED_HDI_SM_20180520.csv",sep=""))
