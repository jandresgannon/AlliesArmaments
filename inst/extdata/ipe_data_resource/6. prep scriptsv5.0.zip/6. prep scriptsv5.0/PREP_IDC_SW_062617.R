# 
# Dataset: Inclusion, Dispersion and Constraints
# Data source url: NOT YET POSTED
# Codebook url: 
#   Citation:
#   Strøm, Kaare, Scott Gates, Benjamin A.T. Graham and Håvard Strand. Forthcoming. 
# “Inclusion, Dispersion, and Constraint: Powersharing in the World’s States, 1975-2010.”  
# British Journal of Political Science.
# Time: 1975-2010
# Updated: November 2, 2016
# By: Sherry
# Suffix: IDC
###############################
library(foreign)
library(Hmisc)
library(readstata13)
datapath ="/Users/user/Google Drive/Master IPE Data/prepped data/"
idc = read.dta13(paste(datapath, "IDC_prepped.dta", sep = ""),generate.factors=T )

colnamesIDC <- c("gwno", "country", "year", "ifs", "pr_IDC", "constsusp_IDC", 
              "treaty_IDC",       "gcman_IDC",    
              "gcimp_IDC",         "partynoethnic_IDC",      
              "mveto_IDC",         "resman_IDC",        "resimp_IDC",      
              "resseats_IDC",     "resseatsimp_IDC",    "relestablish_IDC",  
              "relrestrict_IDC",  "relconstd_IDC",       "relconstp_IDC",         
              "state_IDC",        "muni_IDC", 
              "stconst_IDC",        "subtax_IDC",             
              "subed_IDC",        "subpolice_IDC",    "milleg_IDC",            
              "miman_IDC",        "mfound_IDC",      "milparty_IDC",           
              "milparty2_IDC",    "jtenure_IDC",            
              "jcause_IDC",       "japptbr_IDC",      "jconst_IDC",             
              "jrevman_IDC",      
              "resseats2_IDC",    "gcseats1_IDC",     "gcseats2_IDC",           
              "gcseats3_IDC",     "unity_IDC",         "relestablish_binary_IDC",
              "auton_IDC",        "gcnew_IDC",         "violation_IDC",          
              "martiallaw_binary_IDC", "jtenure_dummy1_IDC",
              "jtenure_dummy2_IDC",  "state_dummy1_IDC",   "state_dummy2_IDC",
              "dispersive_imp_IDC",     "constraining_imp_IDC",    "inclusive_imp_IDC",      
              "dispersive_nm_IDC",       "constraining_nm_IDC",     "inclusive_nm_IDC",      
              "dispersive_IDC",          "constraining_IDC",        "inclusive_IDC"
              )

colnamesIDC

idc <- idc[colnamesIDC]

label(idc$inclusive_IDC) = "Inclusive powersharing [IDC]"
label(idc$dispersive_IDC) = "Dispersive Powersharing  [IDC]"
label(idc$constraining_IDC) = "Constraining Powersharing  [IDC]"
label(idc$dispersive_imp_IDC) = "dispersive with missing values imputed [IDC]"
label(idc$dispersive_nm_IDC) = " dispersive with missing values replaced as 0 [IDC]"
label(idc$inclusive_imp_IDC) = " inclusive with missing values imputed [IDC]"
label(idc$inclusive_nm_IDC) = "inclusive with missing values replaced as 0 [IDC]"
label(idc$constraining_imp_IDC) = "constraining with missing values imputed [IDC]"
label(idc$constraining_nm_IDC) = "constraining with missing values replaced as 0 [IDC]"
label(idc$constsusp_IDC) = "Constitution Suspended  [IDC]"
label(idc$treaty_IDC) = "Treaty serving in lieu of a constitution [IDC]"
label(idc$martiallaw_binary_IDC) = "Martial Law [IDC]"
label(idc$gcman_IDC) = "Grand Coalition (mandated) [IDC]"
label(idc$gcimp_IDC) = "Grand Coalition (implemented) [IDC]"
label(idc$unity_IDC) = "National Unity Government [IDC]"
label(idc$gcseats1_IDC) = "Grand Coalition by Seats (Two largest parties in government) [IDC]"
label(idc$gcseats2_IDC) = "Grand Coalition by Seats (Excess Party in Coalition) [IDC]"
label(idc$gcseats3_IDC) = "Grand Coalition by Seats (Either gscseats1 or gcseats2 = 1) [IDC]"
label(idc$gcnew_IDC) = "gcman or unity = 1 [IDC]"
label(idc$partynoethnic_IDC) = "Ethnic Party Ban [IDC]"
label(idc$mveto_IDC) = "Mutual Veto [IDC]"
label(idc$resman_IDC) = "Reserved Executive Positions (Mandated) [IDC]"
label(idc$resimp_IDC) = "Reserved Executive Positions (Implemented) [IDC]"
label(idc$resseats_IDC) = "Reserved Seats (Mandated) [IDC]"
label(idc$resseats2_IDC) = "Reserved Seats Binary (Mandated) [IDC]"
label(idc$resseatsimp_IDC) = "Reserved Seats (Implemented) [IDC]"
label(idc$relestablish_IDC) = "State Establishment of Religion [IDC]"
label(idc$relestablish_binary_IDC) = "State Establisment of Religion [IDC]"
label(idc$relrestrict_IDC) = "State Restriction of (minority) religions [IDC]"
label(idc$relconstp_IDC) = "Religion Protected (Practice) [IDC]"
label(idc$relconstd_IDC) = "Religion Protected (Discrimination) [IDC]"
label(idc$stconst_IDC) = "Regional Constituencies in the Upper House [IDC]"
label(idc$state_IDC) = "State/Provincial Governments Locally Elected [IDC]"
label(idc$state_dummy1_IDC) = "state_dummy1_IDC [IDC]"
label(idc$state_dummy2_IDC) = "state_dummy2_IDC [IDC]"
label(idc$muni_IDC) = "Municipal Governments Locally Elected [IDC]"
label(idc$subtax_IDC) = "Sub-National Tax Authority [IDC]"
label(idc$subed_IDC) = "Subnational Education Authority [IDC]"
label(idc$subpolice_IDC) = "Subnational Police Authority [IDC]"
label(idc$auton_IDC)= "Asymmetric Federalism [IDC]"
label(idc$milleg_IDC) = "Military Legislator Ban [IDC]"
label(idc$miman_IDC) = "Inclusive Military [IDC]"
label(idc$mfound_IDC) = "Foundational Military [IDC]"
label(idc$milparty_IDC) = "Constitutional Provision Against Military Party Membership [IDC]"
label(idc$milparty2_IDC) = "Mandatory Party Membership for Military [IDC]"
label(idc$jtenure_IDC) = "Judicial Tenure [IDC]"
label(idc$jtenure_dummy1_IDC) = "jtenure_dummy1_IDC [IDC]"
label(idc$jtenure_dummy2_IDC) = "jtenure_dummy2_IDC [IDC]"
label(idc$jcause_IDC) = "Judges can be removed without cause [IDC]"
label(idc$japptbr_IDC) = "Judicial Appointment Authority Divided [IDC]"
label(idc$jconst_IDC) = "Judicial Constitution [IDC]"
label(idc$jrevman_IDC) = "Judicial Review [IDC]"
label(idc$violation_IDC) = "Violation of Mandated Powersharing [IDC]"
label(idc$pr_IDC) = "Proportional Representation [IDC]"

length(unique(idc$gwno))  #180
range(idc$year) #1975-2010


############ Testing ################
labels <- label(idc)
colnames <- colnames(idc)
size <- length(colnames)

# All Colnames and Labels
AA <- data.frame(matrix(ncol = 0, nrow = size))
AA$colNames <- colnames
AA$labels <- labels

# Empty Labels
AB<-AA[(AA$labels == ""),]

save(idc,file=paste(preppeddata,"PREPPED_IDC_SW_260617.RDATA",sep=""))







