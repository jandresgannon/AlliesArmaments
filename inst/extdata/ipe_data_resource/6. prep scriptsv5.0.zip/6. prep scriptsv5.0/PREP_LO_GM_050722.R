#######################
# Productive Pacifists [LO] (Markowitz et al. 2020)
# Gaea Morales 
# Spring 2022  
# Updated: 05/17/22

library(tidyverse)
library(Hmisc)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"
ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"

source(paste0(ids_path, "append_ids.R"))

load(paste0(rawdata, "RAWDATA_LO_2022_GM.RDATA"))

# Variables of interest: land orientation 
# land_oriented_medium_binary: 
# land_oriented_low_binary: 
# land_oriented_high_binary: 
# land_oriented_medium_continuous: 


lo <- prop1 %>% 
  select(c(gwno,year,country, starts_with("land_oriented"))) %>% 
  select(-land_oriented_medium_continuous_trim) %>% 
  rename("landbin_med" = land_oriented_medium_binary,
         "landbin_low" = land_oriented_low_binary,
         "landbin_high" = land_oriented_high_binary,
         "landcon_med" = land_oriented_medium_continuous) %>% 
  group_by(gwno, year) %>% 
  distinct() %>% # double check for duplicates 
  append_suffix("LO") # append suffix 

# add labels
label(lo$landbin_med_LO) <- "Binary, land-oriented (medium) [LO]"
label(lo$landbin_low_LO) <- "Binary, land-oriented (low) [LO]"
label(lo$landbin_high_LO) <- "Binary, land-oriented (high) [LO]"
label(lo$landcon_med_LO) <- "Continuous, percent land-oriented (med) [LO]"
  
saveRDS(lo, file=paste(preppeddata, "PREPPED_LO_GM_051722.RDS"))





