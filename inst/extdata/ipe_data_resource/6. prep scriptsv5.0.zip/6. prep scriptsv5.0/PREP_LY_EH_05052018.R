# /**************************
# Data: Levy-Yeyati and Sturzenegger Exchange Rate Regimes
# Data source url:http://www.utdt.edu/Upload/_126797338585330000.pdf
# Codebook url:http://www.utdt.edu/Upload/_126797338585330000.pdf
# Time: 1974 - 2004
# Updated: 2018.02.17
# By: Emily on 05.10.2018
# Edited MB 5/5/2020
# Suffix: LY
# 
# Citation:
# Levy-Yeyati, Eduardo, and Federico Sturzenegger. 2005. “Classifying exchange rate regimes:
# Deeds vs. words.” European Economic Review 49(6): 1603–1635.
#
# #****************************/

library(Hmisc)
library(foreign)

LY = read.dta(paste(rawdata, "RAWDATA_LY.dta", sep = ""))

#label variables
label(LY$class_5way) = "5-way Classification [LY&S]"
label(LY$class_3way) = "3-way Classification [LY&S]"

LY$country[LY$wbcode == "KOR"] = "South Korea"

#appending ids
LY = append_ids(LY, breaks = F)

#append suffix
LY = append_suffix(LY, "LY")

# Number of unique countries
length(unique(LY$gwno)) #175

# Range of years
range(LY$year) #1974 - 2004

#save file
save(LY,file=paste(preppeddata,"PREP_LY_EH_05102018.RDATA",sep=""))
