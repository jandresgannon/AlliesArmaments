# /**************************
# Data: Composite Index of National Capability (CINC) index 
# Dataset: COW materials capabilities (CINC) data
# Data source url: http://www.correlatesofwar.org/data-sets/national-material-capabilities
# Codebook url: http://www.correlatesofwar.org/data-sets/national-material-capabilities/nmc-codebook-v5-1
# Time: 1816-2016
# Updated: 01/02/2022
# By: Sherry on 02/01/2017
# Edited By: Jiaming Shi on 01/19/2022
# Suffix: MC
# 
# Citation:
#   Singer, J. David, Stuart Bremer, and John Stuckey. (1972). "Capability Distribution, Uncertainty, 
#   and Major Power War, 1820-1965." in Bruce Russett (ed) Peace, War, and Numbers, Beverly Hills: Sage, 19-48.
# 
#   Singer, J. David. 1987. "Reconstructing the Correlates of War Dataset on Material Capabilities of States, 
#   1816-1985" International Interactions, 14: 115-32.
#
# Variables: CINC Score, Military Expenditures, Military Personnel, Iron and Steel Production, 
# Primary Energy Consumption, Total Population, Urban Population
#
# Code Review: Jan 6, 2022
# Reviewed by Huiyeon Eim
# ****************************/

library(Hmisc)
#library(countrycode)
library(magrittr) # needs to be run every time you start R and want to use %>%

setwd("/Volumes/GoogleDrive/내 드라이브/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0")

rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/preppeddatav5.0/"
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/" 

#mc = read.csv("/Volumes/GoogleDrive/내 드라이브/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/RAWDATA_MC_2021.csv")
mc <- read.csv(paste0(rawdata,"RAWDATA_MC_2021.csv"))

#Keep variables we are interestd
mc = mc[, c("stateabb", "ccode", "year", "irst", "tpop", "upop", "cinc", "milex", "milper", "pec")]

#Rename some variables
names(mc)[names(mc)=="stateabb"] = "country"

#Append country names based on COW codes
mc$country <- countrycode(mc$ccode, "cown", "country.name")
mc$country[mc$ccode == 730] <- "Korea"
mc$country[mc$ccode == 260] <- "German Federal Republic"

#change order of columns
mc <- mc[,c("ccode","country", "year","irst","tpop","upop","cinc","milex","milper","pec")]

#load("/Volumes/GoogleDrive/내 드라이브/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/prep scripts v5.0/Country_GWNO_Year_Simple.RDATA")
#source("/Users/SarahLim/Desktop/USC/EC/SPEC LAB/Talus/append_ids.R")
#Append country IDs 
#source(paste0(ids_path, "append_ids.R"))
mc <- append_ids(mc, breaks = F)

# Drop a couple of duplicates from Germany and Yemen

# Germany
# Germany 1945- 1949
# Drop duplicates when ccode_raw = 260 (German Federal Republic), 265 (German Democratic Republic) 
# and year = 1990
mc <- mc[!(mc$ccode_raw=="260" & mc$year==1990),]
mc <- mc[!(mc$ccode_raw=="265" & mc$year==1990),]

# Yemen
# Yemen Arab Republic YAR 1926 -1990 
# Yemen 1990 - 2012 ---------Changed to Arab Republic of Yemen
# Yemen People's Republic 1967 - 1990 
mc <- mc[!(mc$countryname_raw=="Yemen" & mc$year==1990),]

# Check duplicates
n_occur <- data.frame(table(mc$country, mc$year))
n_occur[n_occur$Freq > 1,]

#Add variable labels
label(mc$cinc) <- "CINC Score [MC]"
label(mc$milex) <- "Military Expenditures [MC]"
label(mc$milper) <- "Military Personnel  [MC]"
label(mc$irst) <- "Iron and Steel Production [MC]"
label(mc$pec) <- "Primary Energy Consumption [MC]"
label(mc$tpop) <- "Total Population [MC]"
label(mc$upop) <- "Urban Population [MC]"

# Number of unique countries
length(unique(mc$gwno)) # 216

# Range of years
range(mc$year) #1816-2016

# Append suffix MC to variables 
mc = append_suffix(mc,"MC")
mc$ccode_raw_MC = NULL

saveRDS(mc,file=paste(preppeddata,"PREPPED_MC_JS_01192022.RDS",sep=""))
