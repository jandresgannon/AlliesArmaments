# /************************* 
# Source: Organisation for Economic Co-operation and Development
# Accessed: March 13, 2017
# URL: http://stats.oecd.org/
# Query specifications: all countries, all years, variables: long term interest rate
# 
# Time: 1954-2016
# By: Grace Xu
# Edited by: Baiyu Zhu
# Time: 1954-2018
# Edited by: Affan Rahman (07/20/2020)
# Time: 1954-2019
# Edited by: Gaea Morales (06/10/22)
# Time: 1954-2022
# Suffix: OECD
# Variables: Long-term interest rate
# *************************/

library(Hmisc)
library(tidyverse)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"

ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste0(ids_path, "append_ids.R"))

#Importing data.
#oecd <- read.csv(paste(rawdata, "RAWDATA_OECD_AMR_07202020.csv", sep=""))
oecd <- read.csv(paste0(rawdata, "RAWDATA_OECD_GM_061022.csv"))

#Removing unnecessary variables.
oecd = oecd[,c("Country",
               "Time",
               "Value")]

#Renaming variables.
names(oecd)[names(oecd)=="Time"] = "year"
names(oecd)[names(oecd)=="Value"] = "ltint"
names(oecd)[names(oecd)=="Country"] = "country"

#Number of countries and years of observations.
length(unique(oecd$country)) # 40
range(oecd$year) #1954-2021

oecd <- append_ids(oecd, breaks = F)

#Checking for duplicates.
n_occur <- data.frame(table(oecd$country, oecd$year))
print(n_occur[n_occur$Freq > 1,])

#Number of countries and years of observations after append_ids.
length(unique(oecd$country)) #38
range(oecd$year) #1954-2019

oecd$country = as.character(oecd$country)

#Adding variable label.
label(oecd$ltint) <- "Long-term interest rate (percentage) [OECD]"

#Appending suffix.
oecd = append_suffix(oecd, "OECD")

#save
saveRDS(oecd,paste(preppeddata,"PREPPED_OECD_GM_061022.RDS"))
