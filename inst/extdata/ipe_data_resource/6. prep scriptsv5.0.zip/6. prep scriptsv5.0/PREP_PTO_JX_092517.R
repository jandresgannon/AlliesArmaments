# /************************* 
# Source: Ross-Mahdavi Oil and Gas Data (1932-2014)
# Last Updated: Sep 24, 2015
# Dataset URL: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/ZTPW0Y
# Codebook URL: https://dataverse.harvard.edu/file.xhtml?fileId=2711001&version=RELEASED&version=.0
# Note: some of the country units are a bit unusual, such as the inclusion of Algeria in France's total
# Time: 1932-2014
# By: Jessica Xu
# Revised by: Suzie Mulesky (5/8/2018)
# Suffix: PTO
#
# Variables:
# oil_value_2014_PTO = Total value of oil production (volume times world price for oil) [PTO]
# gas_value_2014_PTO = Total value of gas production (volume times world price for gas) [PTO]
# oil_gas_value_2014_PTO = Total value of oil and gas production [PTO]
# countryname_raw_PTO = Original country name from Ross et al. [PTO]
#
# *************************/

library(Hmisc)
library(dplyr)
library(tidyr)

#read the csv file
PTO <- read.csv(paste(rawdata, "RAWDATA_PTO_JX.csv", sep=""))

#keep specific variables
PTO <- subset(PTO, select=c("cty_name", "year", "oil_value_2014", "gas_value_2014", "oil_gas_value_2014"))

#renaming variables
names(PTO)[names(PTO) == "cty_name"] = "countryname"

# check for duplicates
n_occur <- data.frame(table(PTO$countryname, PTO$year))
n_occur [n_occur$Freq > 1,]

str(PTO)

#appending gwnos
PTO = append_ids(PTO, breaks = FALSE)

# Check duplicates
n_occur <- data.frame(table(PTO$gwno, PTO$year))
n_occur [n_occur$Freq > 1,]

# --- Fixing duplicates
# France including Algeria
PTO = PTO[!(PTO$countryname_raw == "France" & PTO$year < 1962), ]
PTO = PTO[!(PTO$countryname_raw == "France including Algeria" & PTO$year >= 1962), ]

# Czech Republic/Czechoslovakia
PTO = PTO[!(PTO$countryname_raw == "Czech Republic" & PTO$year < 1993), ]
PTO = PTO[!(PTO$countryname_raw == "Czechoslovakia" & PTO$year >= 1993), ]

# Serbia/Yugoslavia
PTO = PTO[!(PTO$countryname_raw == "Serbia" & PTO$year < 2006), ]
PTO = PTO[!(PTO$countryname_raw == "Serbia and Montenegro"), ]
PTO = PTO[!(PTO$countryname_raw == "Yugoslavia, Fed. Rep." & PTO$year == 2006), ]


# Russia/Soviet Union
PTO = PTO[!(PTO$countryname_raw == "Russian Federation" & PTO$year < 1990), ]
PTO = PTO[!(PTO$countryname_raw == "Soviet Union" & PTO$year >= 1990), ]

# Ethiopia/Eritrea
PTO = PTO[!(PTO$countryname_raw == "Ethiopia" & PTO$year < 1993), ]
PTO = PTO[!(PTO$countryname_raw == "Ethiopia including Eritrea" & PTO$year >= 1993), ]

# Yemen, North Yemen, South Yemen
PTO = PTO[!(PTO$countryname_raw == "Yemen, Rep." & PTO$year < 1991), ]
PTO = PTO[!(PTO$countryname_raw == "Yemen Arab Rep. (North Yemen)" & PTO$year >= 1991), ]
PTO = PTO[!(PTO$countryname_raw == "Yemen, Dem. Rep. (South Yemen)" & PTO$year >= 1991), ]
PTO$country = ifelse(PTO$countryname_raw == "Yemen, Dem. Rep. (South Yemen)", "Yemen, People's Republic of", PTO$country)
PTO$gwno = ifelse(PTO$countryname_raw == "Yemen, Dem. Rep. (South Yemen)", 680, PTO$gwno)
PTO$ccode = ifelse(PTO$countryname_raw == "Yemen, Dem. Rep. (South Yemen)", 680, PTO$ccode)
PTO$ifs = ifelse(PTO$countryname_raw == "Yemen, Dem. Rep. (South Yemen)", "YMD", PTO$ifs)
PTO$ifscode = ifelse(PTO$countryname_raw == "Yemen, Dem. Rep. (South Yemen)", NA, PTO$ifscode)
PTO$gwabbrev = ifelse(PTO$countryname_raw == "Yemen, Dem. Rep. (South Yemen)", "YPR", PTO$gwabbrev)

# Pakistan/Pakistan including East Pakistan
PTO = PTO[!(PTO$countryname_raw == "Pakistan" & PTO$year < 1971), ]
PTO = PTO[!(PTO$countryname_raw == "Pakistan including East Pakistan" & PTO$year >= 1971), ]

# Vietnam/North Vietnam/South Vietnam
PTO = PTO[!(PTO$countryname_raw == "North Vietnam" & PTO$year < 1954), ]
PTO = PTO[!(PTO$countryname_raw == "North Vietnam" & PTO$year >= 1977), ]
PTO = PTO[!(PTO$countryname_raw == "Vietnam" & PTO$year > 1953 & PTO$year <= 1976), ]

# Germany/West Germany/East Germany
PTO = PTO[!(PTO$countryname_raw == "Federal Republic of Germany (West Germany)" & PTO$year >= 1991), ]
PTO = PTO[!(PTO$countryname_raw == "German Democratic Republic (East Germany)" & PTO$year >= 1991), ]
PTO = PTO[!(PTO$countryname_raw == "Germany" & PTO$year < 1991 & PTO$year > 1945), ]
PTO$country = ifelse(PTO$countryname_raw == "German Democratic Republic (East Germany)", "German Democratic Republic", PTO$country)
PTO$gwno = ifelse(PTO$countryname_raw == "German Democratic Republic (East Germany)", 265, PTO$gwno)
PTO$ccode = ifelse(PTO$countryname_raw == "German Democratic Republic (East Germany)", 265, PTO$ccode)
PTO$ifs = ifelse(PTO$countryname_raw == "German Democratic Republic (East Germany)", "DDR", PTO$ifs)
PTO$ifscode = ifelse(PTO$countryname_raw == "German Democratic Republic (East Germany)", NA, PTO$ifscode)
PTO$gwabbrev = ifelse(PTO$countryname_raw == "German Democratic Republic (East Germany)", "GDR", PTO$gwabbrev)

# Sudan/South Sudan
PTO = PTO [!(PTO$countryname_raw == "Sudan including South Sudan" & PTO$year >= 2011), ]
PTO = PTO [!(PTO$countryname_raw == "Sudan" & PTO$year < 2011),]
  
# Check duplicates
n_occur <- data.frame(table(PTO$gwno, PTO$year))
n_occur [n_occur$Freq > 1,]

# append suffix
PTO = append_suffix(PTO, "PTO")

str(PTO)
range(PTO$year) # 1932-2014
length(unique(PTO$gwno)) # 180

# Add variable labels
label(PTO$oil_value_2014_PTO) ="Total value of oil production (volume times world price for oil) [PTO]"
label(PTO$gas_value_2014_PTO) ="Total value of gas production (volume times world price for gas) [PTO]"
label(PTO$oil_gas_value_2014_PTO) ="Total value of oil and gas production [PTO]"
label(PTO$countryname_raw_PTO) = "Original country name from Ross et al. [PTO]"

# save the file 
save(PTO, file = paste(preppeddata,"PREPPED_PTO_JX_SM_20180508.RDATA", sep = ""))

#write.csv(PTO, file = paste(preppeddata,"PREPPED_PTO_JX_SM_20180508.csv", sep = ""))