#/*******************************************
#Religious Characteristics of States Dataset
#Suffix: RCS

#Citation: 
#Brown, D., & James, P. (2019, February 10). Religious Characteristics of 
#States Dataset Project - Demographics v. 2.0 (RCS-Dem 2.0), COUNTRIES ONLY.

#Data: https://www.thearda.com/Archive/Files/Downloads/RCSDEM2_DL.asp

#Updated by Affan Rahman
#Date Updated: 4/22/2022


library(readxl)
library(Hmisc)
library(dplyr)
library(countrycode)


#keep columns: ccode year indep chrpop chrpct relmajid jewpop jewpct muspop 
#muspct hinpop hinpct budpop budpct eacomppp eacomppt indpop indpct 
#notrelpp notrelpt unkpop unkpct shipop shipct cnfpop cnfpct taopop taopct

#Import RCS rawdata from Excel 
RCSRAW <- read_excel(paste(rawdata, "RAWDATA_RCS_2022.XLSX", sep=""))

#Select ONLY the variable columns that we want (see above), and save it as a new dataframe RCS.
RCS <- RCSRAW %>%
  select(ISO3, YEAR, INDEP, MAJID, CHRPP, CHRPC, JEWPP, JEWPC, MUSPP, MUSPC, 
         HINPP, HINPC, BUDPP, BUDPC, EACPP, EACPC, INDPP, INDPC, NREPP, NREPC, 
         UNKPP, UNKPC, SHNPP, SHNPC, CNFPP, CNFPC, TAOPP, TAOPC)

#Add labels
label(RCS$ISO3) <- "Abbreviation of the country [RCS]"
label(RCS$INDEP) <- "Whether state is independent on December 31 of observed year [RCS]"
label(RCS$MAJID) <- "ID code of religion of majority of population (50% plus one) [RCS]"
label(RCS$CHRPP) <- "Population of Christians [RCS]"
label(RCS$CHRPC) <- "Percentage of Christians [RCS]"
label(RCS$JEWPP) <- "Population of Jews [RCS]"
label(RCS$JEWPC) <- "Percentage of Jews [RCS]"
label(RCS$MUSPP) <- "Population of Muslims [RCS]"
label(RCS$MUSPC) <- "Percentage of Muslims [RCS]"
label(RCS$HINPP) <- "Population of Hindus [RCS]"
label(RCS$HINPC) <- "Percentage of Hindus [RCS]"
label(RCS$BUDPP) <- "Population of Buddhists [RCS]"
label(RCS$BUDPC) <- "Percentage of Buddhists [RCS]"
label(RCS$EACPP) <- "Population of East Asian Religious Complex [RCS]"
label(RCS$EACPC) <- "Percentage of East Asian Religious Complex [RCS]"
label(RCS$INDPP) <- "Population of Indigenous Religionists (Ethnoreligionists) [RCS]"
label(RCS$INDPC) <- "Percentage of Indigenous Religionists (Ethnoreligionists) [RCS]"
label(RCS$NREPP) <- "Population of Not Religious [RCS]"
label(RCS$NREPC) <- "Percentage of Not Religious [RCS]"
label(RCS$UNKPP) <- "Population of Unknown [RCS]"
label(RCS$UNKPC) <- "Percentage of Unknown [RCS]"
label(RCS$SHNPP) <- "Population of Shintoists [RCS]"
label(RCS$SHNPC) <- "Percentage of Shintoists [RCS]"
label(RCS$CNFPP) <- "Population of Confucianists [RCS]"
label(RCS$CNFPC) <- "Percentage of Confucianists [RCS]"
label(RCS$TAOPP) <- "Population of Taoists [RCS]"
label(RCS$TAOPC) <- "Percentage of Taoists [RCS]"

#Change country code to country name
RCSRAW$ISO3 = as.character(RCSRAW$ISO3)

RCS$Country <- countrycode(sourcevar = RCSRAW$ISO3, "iso3c", "country.name")

#manually rename for ANT, CSK, YMD and DDR
RCS$Country[RCS$ISO3 == "ANT"] <- "Netherlands Antilles"
RCS$Country[RCS$ISO3 == "CSK"] <- "Czechoslovakia"
RCS$Country[RCS$ISO3 == "DDR"] <- "German Democratic Republic"
RCS$Country[RCS$ISO3 == "YMD"] <- "Yemen"

#remove rows with NA countries
RCS <- RCS[!is.na(RCS$Country), ]

#Remove Years before 1800.
RCS <- RCS[RCS$YEAR>1799,]

# lowercase variable names
names(RCS) <- tolower(names(RCS))

# remove ISO column
RCS$iso3 <- NULL

#Append IDs
RCS <- append_ids(RCS, breaks = F)

#Checking duplicates
n_occur <- data.frame(table(RCS$country, RCS$year))
print(n_occur[n_occur$Freq > 1,])

# keeping observations for czechoslovakia during the years it existed
RCS <- RCS[!(RCS$countryname_raw == "Czechia" & RCS$year < 1993 & RCS$year > 1917), ]
# not sure what to do before czechoslovakia's independence from the austro-hungarian empire, keeping
# czechia obs. because czechoslovakia obs only start in 1910 -MB
RCS <- RCS[!(RCS$countryname_raw == "Czechoslovakia" & RCS$year < 1918), ]

#Checking duplicates
n_occur <- data.frame(table(RCS$country, RCS$year))
print(n_occur[n_occur$Freq > 1,])

#Append Suffix
RCS <- append_suffix(RCS, "RCS")

save(RCS,file=paste(preppeddata,"PREPPED_RCS_AMR_04222022.RDATA",sep=""))
