###############################
# Relative Political Capacity
# Accessed 07/16/2020
# Year Range: 1960-2013
# Suffix: RPC
# Dataset last update: Nov 21, 2013
#
# Data: https://transresearchconsortium.com/data
# Codebook: https://static1.squarespace.com/static/576ef1a0be65941edd80fcf7/t/57d06473ff7c50fb0f35a6b9/1473274997414/Relative+Political+Capacity+Dataset+Documentation.pdf
#
# Citation: Kugler, Jacek and Ronald Tammen (2012). Performance of Nations. Lanham: Rowman and
#  Littlefield.
#
# Variables: rpe_agri, rpe_gdp, rpe_fed, rpr_work, rpr_eap, RPA1, RPA2
#
# Prepped by Stephen Campbell, 04/2018
# Updated by Affan Rahman, 07/16/2020
################################

library(readxl)
library(Hmisc)

library(dplyr)
library(tidyr)
library(stringr)

#Loading data.
RPC <- read_excel(paste(rawdata, "RAWDATA_RPC_AMR_07162020.xlsx",sep=""))

#Data is already nice and clean, applying append_ids function. 
source(paste(prepscripts,"append_ids.R",sep=""))

RPC <- append_ids(RPC, breaks = F)

#"The following countries were not given gwno codes: "
# "American Samoa"
# "Anguilla"
# "Aruba"
# "Bermuda"
# "Cayman Islands"
# "Faeore Islands"
# "French Polynesia"
# "Greenland"
# "Guam"
# "Marshall Islands, Rep"
# "Montserrat"
# "Netherlands Antilles"
# "New Caledonia"
# NA

#Checking for duplicates.
n_occur <- data.frame(table(RPC$country, RPC$year))
print(n_occur[n_occur$Freq > 1,])

#change labels, using codebook as reference. Link:https://www.researchgate.net/publication/271588514_Relative_Political_Capacity_Dataset_Documentation-
label(RPC$rpe_agri) <- "Relative Political Extraction (Model 1) [RPC]"
label(RPC$rpe_gdp) <- "Relative Political Extraction (Model 2) [RPC]"
label(RPC$rpe_fed) <- ""
label(RPC$rpr_work) <- "Relative Political Reach (Model 3) [RPC]"
label(RPC$rpr_eap) <- "Relative Political Reach (Model 4) [RPC]"
label(RPC$RPA1) <- "Relative Political Allocation (Model 5) [RPC]"
label(RPC$RPA2) <- "Relative Political Allocation with income partitions (Model 5) [RPC]"

#Appending suffix RPC to variables. 
RPC = append_suffix(RPC, "RPC")

#Number of countries and years of observations after cleaning.
length(unique(RPC$country)) #190
range(RPC$year) #1960-2013

#saving prepped data, finished on 
save(RPC,file=paste(preppeddata,"PREPPED_RPC_AMR_07162020.RDATA",sep=""))

                     