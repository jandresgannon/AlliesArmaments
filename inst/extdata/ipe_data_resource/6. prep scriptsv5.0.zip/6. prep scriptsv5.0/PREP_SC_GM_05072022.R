#######################
# World Bank Statistical Capacity Indicators [SC]
# Gaea Morales 
# Spring 2022  
# Updated: 05/17/22
# Accessed: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/8RPC9E


library(tidyverse)
library(Hmisc)
library(haven)
library(naniar)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"
ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"

source(paste0(ids_path, "append_ids.R"))

# Load in data 
sc <- read_csv(paste0(rawdata, "RAWDATA_SC_2021_GM.csv"))

sc2 <- sc %>% 
  select(-`Time Code`) %>% 
  naniar::replace_with_na_all(condition = ~.x == "..") %>% # replace ".." with NAs 
  rename("year" = Time,
         "ccode" = `Country Code`,
         "countryname" = `Country Name`,
         "statcapacity_ma" = `Methodology assessment of statistical capacity (scale 0 - 100) [IQ.SCI.MTHD]`,
         "statcapacity_mean" = `Overall Average [IQ.SCI.OVRL]`,
         "statcapacity_per" = `Periodicity and timeliness assessment of statistical capacity (scale 0 - 100) [IQ.SCI.PRDC]`,
         "data_diss_stand" = `Special Data Dissemination Standard [5.21.01.01.sdds]`,
         "statcapacity_sda" = `Source data assessment of statistical capacity (scale 0 - 100) [IQ.SCI.SRCE]`) %>% 
  relocate(year, ccode, countryname, statcapacity_mean, statcapacity_sda, statcapacity_ma, statcapacity_per, data_diss_stand) 

sc3 <- sc2 %>% 
  append_ids(breaks = F) %>% # regions dropped 
  append_suffix("SC")

# add labels 
label(sc3$statcapacity_ma_SC) <- "Methodology assessment of statistical capacity (scale 0 - 100) [SC]"
label(sc3$statcapacity_mean_SC) <- "Statistical Capacity score (Overall average) [SC]"
label(sc3$statcapacity_per_SC) <- "Periodicity and timeliness assessment of statistical capacity (scale 0 - 100) [SC]"
label(sc3$data_diss_stand_SC) <- "Special Data Dissemination Standard binary [SC]"
label(sc3$statcapacity_sda_SC) <- "Source data assessment of statistical capacity (scale 0 - 100) [SC]"

saveRDS(sc3, file = paste(preppeddata, "PREPPED_SC_GM_05172022.rds"))
