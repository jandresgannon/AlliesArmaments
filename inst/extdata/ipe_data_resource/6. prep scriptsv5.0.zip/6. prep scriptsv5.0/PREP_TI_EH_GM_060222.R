###############################
# Transparency International Corruption Perceptions Index [TI]
# Version: 2016
# Accessed: April 26, 2017
# Year Range: 1995-2016
# Prepped By: Rohit Madan
# Updated By: Emily Heuring
# Suffix: TI
# Last update: 04/14/2018
#
# Data: http://www.transparency.org/permissions/#datasets
# 
#
# Citation: Transparency International. 2016."Corruption Perceptions Index 2016." 
# http://www.transparency.org/permissions/#datasets. Accessed on April 26, 2016.
#
# Variables: ti_cpi_TI, Label: "Corruption perceptions index [TI]"
#
# Note: This code updates the data from 1995-2014 in the current version of the IPE to 1995-2016.
# Note: Methodology changes after 2012. Scores go from 0-10 to 0-100. 
# 
###############################

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"

ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste0(ids_path, "append_ids.R"))

library(readxl)
library(tidyverse)

#Read raw data 
ti = read_excel(path = (paste(rawdata, "RAWDATA_TI_2016.xlsx", sep="")), sheet = "CPI 1995-2015", skip = 4)

ti <- ti[-c(1), ]

varsToKeep <- c("Country/Territory...1", "2016 CPI Score", "2015 CPI Score", "2014 CPI Score",
                "2013 CPI Score", "2012 CPI Score", "2011 CPI Score", "2010 CPI Score", 
                "2009 CPI Score", "2008 CPI Score", "2007 CPI Score", "2006 CPI Score", "2005 CPI Score",
                "2004 CPI Score", "2003 CPI Score", "2002 CPI Score", "2001 CPI Score", "2000 CPI Score",
                "1999 CPI Score", "1998 CPI Score", "1997 CPI Score", "1996 CPI Score", "1995 CPI Score")
ti <- ti[varsToKeep]
#Change variable names to make reshape possible
names(ti)[names(ti)=="2016 CPI Score"] <- "2016"
names(ti)[names(ti)=="2015 CPI Score"] <- "2015"
names(ti)[names(ti)=="2014 CPI Score"] <- "2014"
names(ti)[names(ti)=="2013 CPI Score"] <- "2013"
names(ti)[names(ti)=="2012 CPI Score"] <- "2012"
names(ti)[names(ti)=="2011 CPI Score"] <- "2011"
names(ti)[names(ti)=="2010 CPI Score"] <- "2010"
names(ti)[names(ti)=="2009 CPI Score"] <- "2009"
names(ti)[names(ti)=="2008 CPI Score"] <- "2008"
names(ti)[names(ti)=="2007 CPI Score"] <- "2007"
names(ti)[names(ti)=="2006 CPI Score"] <- "2006"
names(ti)[names(ti)=="2005 CPI Score"] <- "2005"
names(ti)[names(ti)=="2004 CPI Score"] <- "2004"
names(ti)[names(ti)=="2003 CPI Score"] <- "2003"
names(ti)[names(ti)=="2002 CPI Score"] <- "2002"
names(ti)[names(ti)=="2001 CPI Score"] <- "2001"
names(ti)[names(ti)=="2000 CPI Score"] <- "2000"
names(ti)[names(ti)=="1999 CPI Score"] <- "1999"
names(ti)[names(ti)=="1998 CPI Score"] <- "1998"
names(ti)[names(ti)=="1997 CPI Score"] <- "1997"
names(ti)[names(ti)=="1996 CPI Score"] <- "1996"
names(ti)[names(ti)=="1995 CPI Score"] <- "1995"


library(reshape2)
#Reshape
# Specify id.vars: the variables to keep but not split apart on
ti <- melt(ti, id.vars=c("Country/Territory...1"))

#Change names
#Change name of variable
names(ti)[names(ti)=="Country/Territory...1"] <- "Country"
names(ti)[names(ti)=="variable"] <- "year"
names(ti)[names(ti)=="value"] <- "ti_cpi"

#cast to int
ti$year <- as.numeric(as.character(ti$year))
ti$ti_cpi <- as.numeric(as.character(ti$ti_cpi))

backup <- ti
ti <- backup

sum(is.na(ti$Country))
#Remove missing countries
#ti <- ti[-which(is.na(ti$Country)), ]


#### ADD IN THE NEW DATA UP TO 2021

years <- c(2017, 2018, 2019, 2020, 2021)

ti_update <- read_excel(paste0(rawdata, "RAWDATA_TI_GM_2021.xlsx"), sheet = 2, skip = 2) %>% 
  select(`Country / Territory`, contains("CPI Score")) %>% 
  pivot_longer(names_to = "year", values_to = "ti_cpi", c(2:11)) %>% 
  mutate("year" = parse_number(year))

# merge with older 

ti_merge <- full_join(ti, ti_update, by = c("Country" = "Country / Territory", "year", "ti_cpi")) %>% 
  group_by(Country, year) %>% 
  distinct()

#Append ids
ti_merge <- append_ids(ti_merge, breaks = F) %>% 
  group_by(gwno, year) %>% 
  distinct() %>% 
  filter(!(country == "Macedonia (Former Yugoslav Republic of)" & countryname_raw == "The FYR of Macedonia")) %>% 
  filter(!(country == "Serbia" & countryname_raw == "Yugoslavia")) %>% 
  filter(!(country == "Yugoslavia" & is.na(ti_cpi) & year == 1998 | year == 1999 | year == 2000 | year == 2004 | year == 2005 | year == 2006)) %>% 
  filter(!(country == "Cape Verde" & countryname_raw == "Cape Verde")) %>% 
  filter(!(country == "Congo, Democratic Republic of (Zaire)" & countryname_raw == "The Democratic Republic of Congo")) %>% 
  filter(!(country == "Congo" & countryname_raw == "Congo Republic")) %>% 
  filter(!(country == "Czech Republic" & year >= 2012 & year < 2017 & countryname_raw == "Czech Republic")) %>% 
  filter(!(country == "São Tomé and Principe" & is.na(ti_cpi) & year == 2014 | year == 2015)) %>% 
  select(-countryname_raw) %>% 
  group_by(gwno, year) %>% 
  distinct()

#Check for Duplicates
n_occur <- data.frame(table(ti_merge$country, ti_merge$year))
print(n_occur[n_occur$Freq > 1,])

# # --- Drop the duplicates
# # Serbia Duplicates
# ti = ti[-which(ti$countryname_raw == "Yugoslavia" & ti$year >= 2010),]
# ti = ti[-which(ti$countryname_raw == "Serbia" & ti$year >= 1995 & ti$year < 2010),]

## Append Suffix
ti_merge <- append_suffix(ti_merge, "TI")

#Label
library(Hmisc)
label(ti_merge$ti_cpi_TI) <- "Corruption perceptions index [TI]" 

#check number of countries
length(unique(ti_merge$gwno)) #187

#check range of dataset 
range(ti_merge$year) #1995 - 2021

#save prepped data
saveRDS(ti_merge,file=paste(preppeddata,"PREPPED_TI_GM_060222.RDS"))
