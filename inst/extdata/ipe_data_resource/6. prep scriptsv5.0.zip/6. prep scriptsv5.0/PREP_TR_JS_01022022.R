################################################################################
# Data: The trilemma indexes
# Dataset: Aizenman, Chinn, and Ito
# Data source url: http://web.pdx.edu/~ito/trilemma_indexes.htm
# Codebook url: http://web.pdx.edu/~ito/ReadMe_trilemma_indexes2014.pdf
# Time: 1960-2020
# Prepared by: Affan Rahman
# Updated: 01/19/2022
# Last edited by: Jiaming Shi
# Suffix: TR
# 
# Citation:
# Aizenman, Joshua, Menzie D. Chinn, and Hiro Ito (2010). "The Emerging Global Financial 
# Architecture: Tracing and Evaluating the New Patterns of the Trilemma's Configurations", 
# Journal of International Money and Finance, Vol. 29, No. 4, p. 615–641.
# 
# Aizenman, Joshua, Menzie D. Chinn, and Hiro Ito (2013). "The 'Impossible Trinity' Hypothesis 
# in an Era of Global Imbalances: Measurement and Testing," Review of International Economics, 21(3), 447–458(August 2013).
#
# Variables:
# Exchange Rate Stability Index, Monetary Independence Index, Financial Openness Index
#
################################################################################

setwd("/Volumes/GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/")
# paths
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/preppeddatav5.0/"
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/" 
source(paste(ids_path,"append_ids.R",sep=""))

library(Hmisc)
library(readxl)
library(dplyr)

tr = read_excel(paste(rawdata, "RAWDATA_TR_2021.xlsx", sep=""))

#Keep all variables
#Rename some variables
names(tr)[names(tr)=="Country Name"] = "country"

#Number of unique countries and observations.
length(unique(tr$country)) #199
length(tr$country) #12077

#Applying append_ids function. 
tr <- append_ids(tr, breaks = F)

#Small countries not given GWNO numbers. 

#Czech Republic yielded repeated results in 2015, 2016, and 2017. 

#Deleting duplicate results. The selected values were for "Czechoslovakia" but 
#only contained NAs for every variable. 
tr <- tr[!(tr$countryname_raw == "Czechoslovakia" & tr$year >= 2015), ]

#Checking for duplicates.
n_occur <- data.frame(table(tr$country, tr$year))
print(n_occur[n_occur$Freq > 1,])

#Number of countries and observations after cleaning.
length(unique(tr$country)) #189
length(tr$country) #11372

#Renaming variables and removing "IMF-World Bank Country Code" since we have it from append-ids.
tr <- tr %>% 
  select(country:gwabbrev,
         exchange_rate_stable = 'Exchange Rate Stability Index', 
         monetary_indep = 'Monetary Independence Index',
         fin_openness = 'Financial Openness Index',
         countryname_raw) 

#Add variable labels.
label(tr$exchange_rate_stable) <- "Exchange Rate Stability Index [TR]"
label(tr$monetary_indep) <- "Monetary Independence Index [TR]"
label(tr$fin_openness) <- "Financial Openness Index [TR]"

#Append suffix TR to variables.
tr = append_suffix(tr,"TR")

saveRDS(tr,file=paste(preppeddata,"PREPPED_TR_JS_01192022.RDS",sep=""))