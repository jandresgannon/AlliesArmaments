# /**************************
# Data: World Bank's World Development Indicators 
# Dataset: 
# Data source url: http://databank.worldbank.org/data/download/archive/WDIandGDF_excel_2010_12.zip
# Codebook url: 
# Time: 1960-2009
# Updated: 2018.02.19
# By: Emily on 2018.02.19
# Edited MB 5/5/2020
# Suffix: WB
# 
# Citation:
#   The World Bank. World Development Indicators 2010. http://data.worldbank.org/data-
# catalog/world-development- indicators/wdi-2010. Accessed on July 15, 2015.
# 
# #****************************/

library(foreign)
library(reshape2)
library(Hmisc)
library(readxl)

wb = read_excel(paste(rawdata, "RAWDATA_WB_2018.xlsx", sep=""), sheet = "WDI_GDF_Data")

# Extract the variable that we need
# The dataset has the column "Series Name" which lists multiple series. 
# We only need Daily Newspapers (per 1,000 people)
wb = wb[wb$`Series Name` == "Daily newspapers (per 1,000 people)",]

# Keep the variables we need
# We no longer need to keep the Series Name variable
# The only variables we have left in the dataset are for Daily Newspapers
wb = wb[, c("Country Name", "1960":"2009")]

# Rename Country
names(wb)[names(wb)=="Country Name"] = "country"

# Reshape the dataset
wb = melt(wb, id=c("country"))

wb$value = as.numeric(wb$value) 
wb = aggregate(value~country+variable,data=wb,FUN=sum,na.rm=T)

# Rename variables
names(wb)[names(wb)=="value"] = "news"
names(wb)[names(wb) == "variable"] <- "year"
wb$year <- as.numeric(as.character(wb$year))

# Append Ids
wb = append_ids(wb)

# Label Variables
label(wb$news) <- "Daily newspapers (per 1,000 people) [WB]"

# Number of unique countries
length(unique(wb$country)) #126

# Range of years
range(wb$year) # 1997 - 2005

# Append Suffix
wb = append_suffix(wb, "WB")

save(wb,file=paste(preppeddata,"PREPPED_WB_EH_02192018.RDATA",sep=""))
