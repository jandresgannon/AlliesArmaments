# World Bank Worldwide Governance Indicators [WDI_WGI]
# Accessed: 02/03/2022
# Year Range: 1996-2020
# Prepared by: Jiaming Shi
# Suffix: WGI
# 
# Variables:
# What we kept: estimates of voice and accountability, political stability and absence of violence/terrorism,
#   government effectiveness, regulatory quality, rule of law, control of corruption
# What we dropped: standard error, number of sources, overall percentile rank, lower/upper bounds of percentile rank
#
#
# setwd("/Volumes/GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/")


# paths
rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/preppeddatav5.0/"
ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste(ids_path,"append_ids.R",sep=""))

# load packages required and data
library(haven)
library(Hmisc)
wgi <- read_dta(paste0(rawdata, "RAWDATA_WGI_2022.dta"))
wgi <- wgi[c("countryname", "year", "vae", "pve", "gee", "rqe", "rle", "cce")]

# applying the append_ids function
# It drops a list of micro-states not included in the Gleditsch & Ward system
wgi <- append_ids(wgi, breaks = F)

# check for duplicates
n_occur <- data.frame(table(wgi$country, wgi$year))
print(n_occur[n_occur$Freq > 1,])

# add labels
label(wgi$vae) = "Voice and Accountability Estimate [WDI_WGI]"
label(wgi$pve) = "Political Stability and Absence of Violence/Terrorism Estimate [WDI_WGI]"
label(wgi$gee) = "Government Effectiveness Estimate [WDI_WGI]"
label(wgi$rqe) = "Regulatory Quality Estimate[WDI_WGI]"
label(wgi$rle) = "Rule of Law Estimate[WDI_WGI]"
label(wgi$cce) = "Control of Corruption Estimate [WDI_WGI]"
 
# append suffix
wgi <- append_suffix(wgi, "WGI")

# how many unique countries/observations?
length(unique(wgi$country)) # 198
length(wgi$country) # 4322
range(wgi$year) # 1996-2020

saveRDS(wgi, file = paste0(preppeddata, "PREPPED_WGI_JS_02032022.RDS"))



