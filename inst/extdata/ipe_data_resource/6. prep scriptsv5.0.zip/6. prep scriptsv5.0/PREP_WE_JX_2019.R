# /************************* 
# Source: The World Bank 
# Accessed: May 17, 2017
# URL: http://tcdata360.worldbank.org/indicators/govt.tpcy?country=USA&indicator=687&viz=line_chart&years=2007,2016#
# Query specifications: all countries, all years, variables: tgpm_WE
# Time: 2007-2017
# By: Jessica Xu
# Suffix: WE
# Variables: tgpm_WE：Transparency in government policy making [WEF]
# *************************/
library(Hmisc)
library(readxl)
library(dplyr)
library(tidyr)
library(stringr)
library(reshape2)
#import
WE <- read.csv(paste(rawdata, "RAWDATA_WE.csv", sep=""))
#remove the first column
WE$Country.ISO3<- NULL

#keep specific rows
WE = WE[!grepl('Rank', WE$Subindicator.Type),]
WE = WE[grepl('^Transparency', WE$Indicator),]

#renaming variables
names(WE)[names(WE)=="Country.Name"]="Country"
names(WE)[names(WE)=="X2007.2008"] = "2007"
names(WE)[names(WE)=="X2008.2009"] = "2008"
names(WE)[names(WE)=="X2009.2010"] = "2009"
names(WE)[names(WE)=="X2010.2011"] = "2010"
names(WE)[names(WE)=="X2011.2012"] = "2011"
names(WE)[names(WE)=="X2012.2013"] = "2012"
names(WE)[names(WE)=="X2013.2014"] = "2013"
names(WE)[names(WE)=="X2014.2015"] = "2014"
names(WE)[names(WE)=="X2015.2016"] = "2015"
names(WE)[names(WE)=="X2016.2017"] = "2016"

WE = gather(WE, "Year", "tgpm", 4:ncol(WE))
#Keep only the variables we need
WE = WE[, c("Country",
              "Year",
              "tgpm")]
#label
label(WE$tgpm) <- "Transparency in government policy making [WEF]"

#appending gwnos
WE = append_ids(WE)

length(unique(WE$country))
       

#append suffix
WE = append_suffix(WE, "WE")

save(WE,file=paste(preppeddata,"PREPPED_WE_JX_220517.RDATA",sep=""))


