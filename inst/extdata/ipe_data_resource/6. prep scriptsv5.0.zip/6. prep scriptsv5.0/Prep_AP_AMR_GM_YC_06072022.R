################################################################################
# AP Data Update
# Updated by Affan Rahman, Gaea Morales, Yeiyoung Choo
# This data counts the number of islands each country possesses. The following
# greyed out section is a copy of the most recent edit to this data.
################################################################################

# /************************* 
# Change Figi to Fiji
# Archipelagos Data [AP]
# *************************/

#library(foreign)
#library(Hmisc)
#library(readstata13)


# Read the dta file from prepped data folder
#AP <-read.dta13(paste(rawdata,"archipelagos.dta", sep=""))

# Change Figi -> Fiji
#AP$country[AP$country == "Figi"] <- "Fiji"

# Drop gwno>1000
#AP <- AP[!AP$gwno >= 1100, ]

#renaming variables
#names(AP)[names(AP)=="lnislands"]="lnislands_AP"

# Add variable labels
#label(AP$lnislands_AP) = "Number of islands (ppl > 100000) logged [Archipelagos]"
#label(AP$archipelago_AP) = "At least two islands"
#label(AP$comments_AP) = "List of the islands in each country"
#label(AP$numislands_AP) = "Number of Islands (ppl > 100000)"

#length(unique(AP$gwno)) #223
#range(AP$year) #1800-2015

#check that there are no over time changes
#test <- AP %>% group_by(gwno) %>% 
#  summarise(change = length(unique(numislands_AP))) %>%
#  filter(change > 1)
#test

# cross-sectional format
#AP <- select(AP, -year) %>%
#  filter(!duplicated(gwno))
#arc <- arc[!duplicated(arc),]
#arc <- arc[!duplicated(arc$gwno),]

#save(AP,file=paste(preppeddata,"PREPPED_AP_MB_20052020.RDATA",sep=""))

################################################################################

library(foreign)
library(Hmisc)
library(dplyr)
library(tidyr)
library(tidyverse)
rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/FALL 2021/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/FALL 2021/prepped/"
ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"

#Loading in the rdata file. 
load(paste(rawdata,"PREPPED_AP_MB_20052020.rdata", sep=""))


# Following additions based on Affan's excel update (AP_Update_AMR_0526)

#Updating outdated data. 

# Argentina 
AP$comments_AP[AP$country == 'Argentina'] <- "Isla Grande de Tierra del Fuego"
AP$numislands_AP[AP$country == 'Argentina'] <- 1
AP$archipelago_AP[AP$country == 'Argentina'] <- 0
AP$lnislands_AP[AP$country == 'Argentina'] <- log(1)

# Netherlands 
AP$comments_AP[AP$country == 'Netherlands'] <- "Aruba, Curacao, IJsselmonde, Flevopolder, Voorne-Putten, Dordrecht"
AP$numislands_AP[AP$country == 'Netherlands'] <- 6
AP$archipelago_AP[AP$country == 'Netherlands'] <- 1
AP$lnislands_AP[AP$country == 'Netherlands'] <- log(6)

#Bangladesh # Added 3   
AP$comments_AP[AP$country == 'Bangladesh'] <- "Bhola Island, Sandwip, Maheshkhali, Chengār, Kutubdia"
AP$numislands_AP[AP$country == 'Bangladesh'] <- 5
AP$lnislands_AP[AP$country == 'Bangladesh'] <- log(5)

# Brunei 
AP$comments_AP[AP$country == 'Brunei'] <- "Borneo"
AP$numislands_AP[AP$country == 'Brunei'] <- 1
AP$lnislands_AP[AP$country == 'Bangladesh'] <- log(1)

# China 
AP$comments_AP[AP$country =='China'] <- "Xiamen Island, Hainan, Haizhu Island, Haitan, Chongming, Zhoushan, Cangshan, Dongchong, Jinshazhou, Nansha, Daishan"
AP$numislands_AP[AP$country == 'China'] <- 11
AP$lnislands_AP[AP$country == 'China'] <- log(11)

# Dominican Republic
AP$comments_AP[AP$country =='Dominican Rep'] <- "Hispaniola (shared with Haiti)"
AP$numislands_AP[AP$country == 'Dominican Rep'] <- 1
AP$lnislands_AP[AP$country == 'Dominican Rep'] <- log(1)

# France #Added New Caledonia and Réunion 
AP$comments_AP[AP$country == 'France'] <- "Guadeloupe, Mayotte, Corsica, Martinique, French Polynesia (overseas collectivity of France including Tahiti), New Caledonia, Réunion"
AP$numislands_AP[AP$country == 'France'] <- 7 
AP$lnislands_AP[AP$country == 'France'] <- log(7)

# Hong Kong 
AP$comments_AP[AP$country == 'Hong Kong'] <- "Hong Kong Island, Lantau Island, Tsing Yi"
AP$numislands_AP[AP$country == 'Hong Kong'] <- 3
AP$archipelago_AP[AP$country == 'Hong Kong'] <- 1
AP$lnislands_AP[AP$country == 'Hong Kong'] <- log(3)

# Hungary
AP$comments_AP[AP$country == 'Hungary'] <- "Csepel Island"
AP$numislands_AP[AP$country == 'Hungary'] <- 1
AP$lnislands_AP[AP$country == 'Hungary'] <- log(1)

#Iceland #corrected from 2 to 1 
AP$numislands_AP[AP$country == 'Iceland'] <- 1
AP$archipelago_AP[AP$country == 'Iceland'] <- 0
AP$lnislands_AP[AP$country == 'Iceland'] <- log(1)

#India 
AP$comments_AP[AP$country == 'India'] <- "South Andaman Island, Salsette, Raghopur, Majuli, Srirangam"
AP$numislands_AP[AP$country == 'India'] <- 5
AP$lnislands_AP[AP$country == 'India'] <- log(5)

#Indonesia 
AP$comments_AP[AP$country == 'Indonesia'] <- "Java, Sumatra, Sulawesi, Bali, Madura, Lombok, Flores, Sumbawa, 
Batam, Nias, Bangka, Buton, Sumba, Ambon, Muna, Seram (Archipelago), Borneo, New Guinea, 
Timor, Halmahera, Bintan, Belitung, Tarakan, Ternate, Pulau Petak, Buru, Alor, Rote, 
Lembata, Biak, Peleng, Bengkalis"
AP$numislands_AP[AP$country == 'Indonesia'] <- 31
AP$lnislands_AP[AP$country == 'Indonesia'] <- log(31)

#Iran 
AP$comments_AP[AP$country == 'Iran, Islamic Republic of'] <- "Qeshm, Abadan Island"
AP$numislands_AP[AP$country == 'Iran, Islamic Republic of'] <- 2
AP$archipelago_AP[AP$country == 'Iran, Islamic Republic of'] <- 1
AP$lnislands_AP[AP$country == 'Iran, Islamic Republic of'] <- log(2)

#Ireland 
AP$comments_AP[AP$country == 'Ireland'] <- "Ireland (main island)"
AP$numislands_AP[AP$country == 'Ireland'] <- 1
AP$lnislands_AP[AP$country == 'Ireland'] <- log(1)

#Japan 
AP$comments_AP[AP$country == 'Japan'] <- "Honshu, Kyushu, Hokkaido, Shikoku, Okinawa, Awaji"
AP$numislands_AP[AP$country == 'Japan'] <- 6
AP$lnislands_AP[AP$country == 'Japan'] <- log(6)

#Republic of Korea
AP$comments_AP[AP$country == 'Korea, Republic of'] <- "Jejudo, Geojedo, Yeongdo, Yeongjongdo, Songdo"
AP$numislands_AP[AP$country == 'Korea, Republic of'] <- 5
AP$lnislands_AP[AP$country == 'Korea, Republic of'] <- log(5)

#Liberia 
AP$comments_AP[AP$country == 'Liberia'] <- "Bushrod Island"
AP$numislands_AP[AP$country == 'Liberia'] <- 1
AP$lnislands_AP[AP$country == 'Liberia'] <- log(1)

#Macao SAR China  
AP$comments_AP[AP$country == 'Macao SAR, China'] <- "Zhongshan Island"
AP$numislands_AP[AP$country == 'Macao SAR, China'] <- 1
AP$lnislands_AP[AP$country == 'Macao SAR, China'] <- log(1)

#Malaysia
AP$comments_AP[AP$country == 'Malaysia'] <- "Penang Island"
AP$numislands_AP[AP$country == 'Malaysia'] <- 1
AP$lnislands_AP[AP$country == 'Malaysia'] <- log(1)

#Maldives
AP$comments_AP[AP$country == 'Maldives'] <- "Malé"
AP$numislands_AP[AP$country == 'Maldives'] <- 1
AP$lnislands_AP[AP$country == 'Maldives'] <- log(1)

#Nigeria
AP$comments_AP[AP$country == 'Nigeria'] <- "Lagos Island"
AP$numislands_AP[AP$country == 'Nigeria'] <- 1
AP$lnislands_AP[AP$country == 'Nigeria'] <- log(1)

#Papua New Guinea 
AP$comments_AP[AP$country == 'Papua New Guinea'] <- "New Britain, New Ireland, New Guinea, Bougainville"
AP$numislands_AP[AP$country == 'Papua New Guinea'] <- 4
AP$lnislands_AP[AP$country == 'Papua New Guinea'] <- log(4)

#Portugal
AP$comments_AP[AP$country == 'Portugal'] <- "Madeira, São Miguel Island"
AP$numislands_AP[AP$country == 'Portugal'] <- 2
AP$lnislands_AP[AP$country == 'Portugal'] <- log(2)

#Sao Tome and Principe
AP$comments_AP[AP$country == 'Sao Tome and Principe'] <- "Sao Tome Island"
AP$numislands_AP[AP$country == 'Sao Tome and Principe'] <- 1
AP$lnislands_AP[AP$country == 'Sao Tome and Principe'] <- log(1)

#Solomon Islands
AP$comments_AP[AP$country == 'Solomon Islands'] <- "Malaita, Guadalcanal"
AP$numislands_AP[AP$country == 'Solomon Islands'] <- 2
AP$archipelago_AP[AP$country == 'Solomon Islands'] <- 1
AP$lnislands_AP[AP$country == 'Solomon Islands'] <- log(2)

#Spain
AP$comments_AP[AP$country == 'Spain'] <- "Majorca, Ibiza, Tenerife, Gran Canaria, Lanzarote, Fuerteventura"
AP$numislands_AP[AP$country == 'Spain'] <- 6
AP$lnislands_AP[AP$country == 'Spain'] <- log(6)

#St Lucia
AP$comments_AP[AP$country == 'St Lucia'] <- "Saint Lucia"
AP$numislands_AP[AP$country == 'St Lucia'] <- 1
AP$lnislands_AP[AP$country == 'St Lucia'] <- log(1)

#Sweden 
AP$comments_AP[AP$country == 'Sweden'] <- "Hisingen, Södertörn"
AP$numislands_AP[AP$country == 'Sweden'] <- 2
AP$archipelago_AP[AP$country == 'Sweden'] <- 1
AP$lnislands_AP[AP$country == 'Sweden'] <- log(2)

#Taiwan 
AP$comments_AP[AP$country == 'Taiwan'] <- "Taiwan"
AP$numislands_AP[AP$country == 'Taiwan'] <- 1
AP$lnislands_AP[AP$country == 'Taiwan'] <- log(1)

#United Kingdom
AP$comments_AP[AP$country == 'United Kingdom'] <- "Great Britain, Portsea Island, Isle of Wight, Northern Ireland, Jersey Island"
AP$numislands_AP[AP$country == 'United Kingdom'] <- 5
AP$lnislands_AP[AP$country == 'United Kingdom'] <- log(5)

#United States
AP$comments_AP[AP$country == 'United States'] <- "Manhattan Island, Staten Island, Long Island, Cape Cod, Guam, Oahu, Hawaii, Maui, Puerto Rico"
AP$numislands_AP[AP$country == 'United States'] <- 7
AP$lnislands_AP[AP$country == 'United States'] <- log(7)

#Vietnam
AP$comments_AP[AP$country == 'Vietnam'] <- "Phu Quoc"
AP$numislands_AP[AP$country == 'Vietnam'] <- 1
AP$lnislands_AP[AP$country == 'Vietnam'] <- log(1)

#Zanzibar
AP$comments_AP[AP$country == 'Zanzibar'] <-"Unguja (Zanzibar Island)"
AP$numislands_AP[AP$country == 'Zanzibar'] <- 1
AP$lnislands_AP[AP$country == 'Zanzibar'] <- log(1)


#double check for archipelago # at least 2 islands 
ap <- AP %>%
  mutate(archipelago_AP = ifelse(numislands_AP >= 2, 1, 0))





  mutate(WTOwhen_MEM = ifelse(country == "Denmark", 1995, WTOwhen_MEM)) %>%
  mutate(WTOwhen_MEM = ifelse(country == "Kazakhstan", 2015, WTOwhen_MEM)) %>%
  mutate(WTOwhen_MEM = ifelse(country == "Seychelles", 2015, WTOwhen_MEM)) %>%
  mutate(WTOwhen_MEM = ifelse(country == "Yemen", 2014, WTOwhen_MEM)) %>%
  mutate(WTOmem_MEM = ifelse(is.na(WTOwhen_MEM), 0, as.numeric(year >= WTOwhen_MEM))) #Updating the value of the binary variable.




