################################
# Boix, Miller, and Rosato Democracy Data (Boix, Miller, and Rosato, 2022) [BX]
# V 1.0 
#
# Countries: 209
# Time Period: 1800-2020
#
# 06/21/2022, Yeiyoung Choo
################################

library(tidyverse)
library(haven)
library(Hmisc)

rawdata <- "~/Google Drive/.shortcut-targets-by-id/0B2iwvlsRgy8tQXlVNll5WWhLcGs/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "~/Google Drive/.shortcut-targets-by-id/0B2iwvlsRgy8tQXlVNll5WWhLcGs/Master IPE Data/SPRING 2022/prepped/"

ids_path <- "/Volumes/GoogleDrive/.shortcut-targets-by-id/1JpiIrqOeS1K9UlbREPhw_iziB-QxPH91/append_ids/"
source(paste0(ids_path, "append_ids.R"))

bx <- read_dta(paste(rawdata, "RAWDATA_BX_2022.dta", sep=""))

bx <- bx[c("country","year","democracy","democracy_trans","democracy_breakdowns","democracy_duration",
           "democracy_omitteddata","democracy_femalesuffrage")]


# Append IDs
bx <-  append_ids(bx, breaks = FALSE)

# gwno codes not given for 
 # ETHIOPIA (INCL. ERIT)
 # PAKISTAN (INCL. BANGLAD.)

# Check for duplicates
n_occur <- data.frame(table(bx$country, bx$year))
n_occur[n_occur$Freq>1,]

# Resolve duplicates 

# German Federal Republic and Germany duplicates 1990 
 # where German Democratic Republic also exists until 1990 
# Keep German Federal Republic and drop unified Germany 
bx <- bx[!(bx$countryname_raw == "GERMANY" & bx$year == 1990),]

# Yugoslavia and Federal Republic of Yugoslavia duplicates 1991 
 # Yugoslavia dissolved as Socialist Federal Republic in 1992 
 # Yugoslavia installed as Federal Republic in 1992 
# Hence drop Federal Republic of Yugoslavia for 1991 
bx <- bx[!(bx$countryname_raw == "YUGOSLAVIA, FED. REP." & bx$year == 1991),]

# Yugoslavia & Serbia duplicates 2006
 # Serbia became independent country in June 2006 
bx <- bx[!(bx$countryname_raw == "SERBIA" & bx$year == 2006),]

# How many countries? What time period?
length(unique(BX$gwno)) #209 
range(BX$year) #1800-2020 

# Label variables
label(bx$democracy) <- "Democracy [Boix]"
label(bx$democracy_trans) <- "Democratic Transition [Boix]"
label(bx$democracy_breakdowns) <- "Democratic Breakdowns [Boix]"
label(bx$democracy_duration) <- "Democratic Duration [Boix]"
label(bx$democracy_omitteddata) <- "Democracy Omitted Data [Boix]"
label(bx$democracy_femalesuffrage) <- "Democracy Female Suffrage [Boix]"

# Add suffix
bx <- append_suffix(bx, "BX")

# Save
saveRDS(bx, file = paste(preppeddata,"Prepped_BX_YC_06212022.RDS", sep=""))
