# /*************************
# CEPII GeoDist dataset
# 
# Mayer, T. & Zignago, S. (2011) Notes on CEPII’s distances measures : the GeoDist Database CEPII Working Paper 2011-25
# 
# URL: http://www.cepii.fr/CEPII/en/bdd_modele/presentation.asp?id=6
# 
# Variables:
# comlang_off: common official language 
# comlang_ethno: common spoken language 
# colony: past or present colonial relationship 
# comcol: common colonizer 
# dist: distance between largest cities 
# distcap: distance between capital cities 
# distw: population weighted distance 
# distwces: population weighted distance (typical gravity model) 
# *************************/

library(readxl)
library(countrycode)
library(Hmisc)

library(tidyverse)
library(readxl)

ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste0(ids_path, "append_ids.R"))

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/"

# load data
dist <- read_excel(paste(rawdata,"RAWDATA_CE_GEO_GM_2011.xls", sep=""))

dist$country1 <- countrycode(dist$iso_o, 'iso3c', 'country.name')
dist$country1[dist$iso_o == 'ROM'] <- 'Romania'
dist$country1[dist$iso_o == 'TMP'] <- 'East Timor'
dist$country1[dist$iso_o == 'YUG'] <- 'Yugoslavia'
dist$country1[dist$iso_o == 'TMP'] <- 'East Timor'
dist$country1[dist$iso_o == 'ZAR'] <- 'Democratic Republic of Congo'
dist$country2 <- countrycode(dist$iso_d, 'iso3c', 'country.name')
dist$country2[dist$iso_d == 'ROM'] <- 'Romania'
dist$country2[dist$iso_d == 'TMP'] <- 'East Timor'
dist$country2[dist$iso_d == 'YUG'] <- 'Yugoslavia'
dist$country2[dist$iso_d == 'TMP'] <- 'East Timor'
dist$country2[dist$iso_d == 'ZAR'] <- 'Democratic Republic of Congo'

#dist$country1[dist$iso_o == 'COG'] <- 'COG'
#dist$country2[dist$iso_d == 'COG'] <- 'COG'
#dist$country1[dist$iso_o == 'CZE'] <- 'CZE'
#dist$country2[dist$iso_d == 'CZE'] <- 'CZE'

#Delete some columns
dist <- dist[,c("country1","country2", "contig", "comlang_off", "comlang_ethno", "colony", "comcol","dist","distcap","distw","distwces")]

#year for append ids
dist$year <- 2004

#Append country IDs
dist <- append_ids(dist, dyad = T, breaks = F)

#Append suffixes
dist <- append_suffix(dist,"CEPII", dyad = T)

#Remove any duplicates
dist <-  dist[!duplicated(dist), ]

#Add variable labels
label(dist$comlang_off_CEPII) <- "common official language [CEPII]"
label(dist$comlang_ethno_CEPII) <- "common spoken language [CEPII]"
label(dist$colony_CEPII) <- "past or present colonial relationship [CEPII]"
label(dist$comcol_CEPII) <- "common colonizer [CEPII]"
label(dist$dist_CEPII) <- "distance between largest cities [CEPII]"
label(dist$distcap_CEPII) <- "distance between capital cities [CEPII]"
label(dist$distw_CEPII) <- "population weighted distance [CEPII]"
label(dist$distwces_CEPII) <- "population weighted distance (typical gravity model) [CEPII]"

# for country-year, create gwno from repgwno and remove gwno 
dist_cy <- mutate(dist, "gwno" = repgwno) %>% 
  select(-repgwno)

#Check for Duplicates
n_occur <- data.frame(table(dist_cy$gwno, dist_cy$year))
print(n_occur[n_occur$Freq > 1,])

#save prepped data
save(dist,file=paste(preppeddata,"PREPPED_CEPII_MB_121018.RDATA",sep=""))
