# /***************************
# UN International Migrant Stocks
# 2020 Update
# 
# URL: https://www.un.org/en/development/desa/population/migration/data/estimates2/estimates19.asp
# 
# Countries: 197
# Time Period: 1990-2019
#
# Jiaming Shi, prepped 04/18/2022
# ****************************/

library(readxl)
library(tidyr)
library(tidyverse)

#rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/preppeddatav5.0/"

#import
ems <- read_excel(paste(rawdata, "RAWDATA_EMS_2020.xlsx", sep=""), sheet = 2)
source(paste0(ids_path, "append_ids.R"))

# clean headers, keep only observations for total stock (col 6-12)
names(ems) <- ems[9,]
names(ems)[2] <- "country"
ems <- ems[-c(1:11), c(2, 6:12)]

# reshape
ems <- pivot_longer(ems, -country, names_to = "year", values_to = "EmigrantStock")

#numeric variable types
ems$year <- as.numeric(ems$year)
ems$EmigrantStock <- as.numeric(ems$EmigrantStock)

# append IDs
ems <-  append_ids(ems, breaks = FALSE) %>%
  group_by(gwno, year) %>% 
  distinct()
#ems <- ems %>% select(-c("ifs","gwno"))

# check for duplicates! Don't worry about them, cuz there are sub headers titled "Australia and New Zealand"
n_occur <- data.frame(table(ems$gwno, ems$year))
n_occur[n_occur$Freq>1,]

# remove regional micronesia observations
ems <- ems[!(ems$countryname_raw == "Micronesia"),]

# how many countries? what time period?
length(unique(ems$gwno)) # 197
range(ems$year) # 1990-2019

# label variables
library(Hmisc)
label(ems$EmigrantStock) =	"Total emigrant stock from [UN]"

#suffix
ems <- append_suffix(ems, "EMS")


# Save
save(ems, file = paste(preppeddata,"PREPPED_EMS_JS_04182022.RDATA", sep=""))
