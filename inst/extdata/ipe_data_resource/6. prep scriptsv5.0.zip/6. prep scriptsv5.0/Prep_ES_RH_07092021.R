# /************************* 
# World Bank education statistics
# Source: WB
# Accessed: July 9, 2021
# URL: http://databank.worldbank.org/data/reports.aspx?source=Education%20Statistics&preview=off
# 
# By: Robert Huang
# Suffix: ES

# Variables: 
# gen_ps_F: Gross enrolment ratio, primary and secondary, female (%)
# gen_ps: Gross enrolment ratio, primary and secondary, both sexes (%)
# gen_sec: Gross enrolment ratio, secondary, both sexes (%)
# gen_sec_F: Gross enrolment ratio, secondary, female (%)
# nen_pri_F: Total net enrolment rate, primary, female (%)
# nen_pri: Total net enrolment rate, primary, both sexes (%)
# nen_usec: Total net enrolment rate, upper secondary, both sexes (%)
# nen_usec_F: Total net enrolment rate, upper secondary, female (%)
# nen_lsec: Total net enrolment rate, lower secondary, both sexes (%)
# nen_lsec_F: Total net enrolment rate, lower secondary, female (%)
# yr_pri_F_1519_BL: Barro-Lee: Average years of primary schooling, age 15-19, female
# yr_pri_1519_BL: Barro-Lee: Average years of primary schooling, age 15-19, total
# yr_sec_F_1519_BL: Barro-Lee: Average years of secondary schooling, age 15-19, female
# yr_sec_1519_BL: Barro-Lee: Average years of secondary schooling, age 15-19, total
# psec_c_F_1519_BL: Barro-Lee: Percentage of female population age 15-19 with secondary schooling. Completed Secondary
# psec_t_F_1519_BL: Barro-Lee: Percentage of female population age 15-19 with secondary schooling. Total (Incomplete and Completed Secondary)
# psec_c_1519_BL: Barro-Lee: Percentage of population age 15-19 with secondary schooling. Completed Secondary
# psec_t_1519_BL: Barro-Lee: Percentage of population age 15-19 with secondary schooling. Total (Incomplete and Completed Secondary)
# edu_gexp: Expenditure on education as % of total government expenditure (%)
# sec_gdp: Government expenditure on secondary education as % of GDP (%)
# edu_gdp: Government expenditure on education as % of GDP (%)
# read_PISA: PISA: Mean performance on the reading scale
# read_F_PISA: PISA: Mean performance on the reading scale. Female
# math_PISA: PISA: Mean performance on the mathematics scale
# math_F_PISA: PISA: Mean performance on the mathematics scale. Female
# sci_F_PISA: PISA: Mean performance on the science scale. Female
# sci_PISA: PISA: Mean performance on the science scale
# read_g4_F_PIRLS: PIRLS: Mean performance on the reading scale for fourth grade students. Female
# read_g4_PIRLS: PIRLS: Mean performance on the reading scale for fourth grade students. Total
# *************************/

# clear everything
rm(list= ls())

# load tidyverse
library(tidyverse)

# set filepaths 
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SUMMER 2021/rawdata/" 
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SUMMER 2021/prepped/"
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/"

# read data file
es <- read.csv(paste(rawdata,"RAWDATA_ES_2020.csv", sep=""))

# change column names
names(es) <- c("country","code","variable","var_code","1970":"2020")

# deselect the variable column, only keep their codes
# keep the rows whose var_code is not empty
es <- es %>%
  select(-variable) %>%
  filter(var_code!="")

# reshape the dataset using pivot_longer and pivot_wider
es2 <- es %>%
  pivot_longer(cols="1970":"2020",names_to="year") %>% # gather years
  pivot_wider(names_from="var_code",values_from="value")

# rename columns
names(es2)[4:ncol(es2)] <- c("gen_ps_F","gen_ps","gen_sec","gen_sec_F","nen_pri_F","nen_pri",
                             "nen_usec","nen_usec_F","nen_lsec","nen_lsec_F","yr_pri_F_1519_BL",
                             "yr_pri_1519_BL","yr_sec_F_1519_BL","yr_sec_1519_BL","psec_c_F_1519_BL",
                             "psec_t_F_1519_BL","psec_c_1519_BL","psec_t_1519_BL","edu_gexp","sec_gdp",
                             "edu_gdp","read_PISA","read_F_PISA","math_PISA","math_F_PISA","sci_F_PISA",
                             "sci_PISA","read_g4_F_PIRLS","read_g4_PIRLS")

# convert character columns to numeric
es2[3:ncol(es2)] <- es2[3:ncol(es2)] %>%
  mutate_if(is.character,as.numeric)

# append ids
source(paste0(ids_path, "append_ids.R"))
es3 <- append_ids(es2, dyad = F, breaks = F)

# Note: North Korea is incorrectly dropped

# check duplicates
sum(duplicated(es3)) # no duplicate

# add labels
library(Hmisc)
label(es3$gen_ps_F) <- "Gross enrolment ratio, primary and secondary, female (%)"
label(es3$gen_ps) <- "Gross enrolment ratio, primary and secondary, both sexes (%)"
label(es3$gen_sec) <- "Gross enrolment ratio, secondary, both sexes (%)"
label(es3$gen_sec_F) <- "Gross enrolment ratio, secondary, female (%)"
label(es3$nen_pri_F) <- "Total net enrolment rate, primary, female (%)"
label(es3$nen_pri) <- "Total net enrolment rate, primary, both sexes (%)"
label(es3$nen_usec) <- "Total net enrolment rate, upper secondary, both sexes (%)"
label(es3$nen_usec_F) <- "Total net enrolment rate, upper secondary, female (%)"
label(es3$nen_lsec) <- "Total net enrolment rate, lower secondary, both sexes (%)"
label(es3$nen_lsec_F) <- "Total net enrolment rate, lower secondary, female (%)"
label(es3$yr_pri_F_1519_BL) <- "Barro-Lee: Average years of primary schooling, age 15-19, female"
label(es3$yr_pri_1519_BL) <- "Barro-Lee: Average years of primary schooling, age 15-19, total"
label(es3$yr_sec_F_1519_BL) <- "Barro-Lee: Average years of secondary schooling, age 15-19, female"
label(es3$yr_sec_1519_BL) <- "Barro-Lee: Average years of secondary schooling, age 15-19, total"
label(es3$psec_c_F_1519_BL) <- "Barro-Lee: Percentage of female population age 15-19 with secondary schooling. Completed Secondary"
label(es3$psec_t_F_1519_BL) <- "Barro-Lee: Percentage of female population age 15-19 with secondary schooling. Total (Incomplete and Completed Secondary)"
label(es3$psec_c_1519_BL) <- "Barro-Lee: Percentage of population age 15-19 with secondary schooling. Completed Secondary"
label(es3$psec_t_1519_BL) <- "Barro-Lee: Percentage of population age 15-19 with secondary schooling. Total (Incomplete and Completed Secondary)"
label(es3$edu_gexp) <- "Expenditure on education as % of total government expenditure (%)"
label(es3$sec_gdp) <- "Government expenditure on secondary education as % of GDP (%)"
label(es3$edu_gdp) <- "Government expenditure on education as % of GDP (%)"
label(es3$read_PISA) <- "PISA: Mean performance on the reading scale"
label(es3$read_F_PISA) <- "PISA: Mean performance on the reading scale. Female"
label(es3$math_PISA) <- "PISA: Mean performance on the mathematics scale"
label(es3$math_F_PISA) <- "PISA: Mean performance on the mathematics scale. Female"
label(es3$sci_F_PISA) <- "PISA: Mean performance on the science scale. Female"
label(es3$sci_PISA) <- "PISA: Mean performance on the science scale"
label(es3$read_g4_F_PIRLS) <- "PIRLS: Mean performance on the reading scale for fourth grade students. Female"
label(es3$read_g4_PIRLS) <- "PIRLS: Mean performance on the reading scale for fourth grade students. Total"

# append suffix
es3 <- append_suffix(es3,"ES")

# save data
save(es3,file=paste(preppeddata,"PREPPED_ES_RH_07132021.rds",sep=""))