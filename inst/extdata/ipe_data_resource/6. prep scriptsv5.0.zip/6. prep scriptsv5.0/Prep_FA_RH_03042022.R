# /******************/
# Data: Fariss Latent Human Rights Protection
# Dataset: HumanRightsProtectionScores
# Datasource URL: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/RQ85GK
# Time: 1946 - 2020
# Updated by: Robert Huang
# By: Emily Heuring
# Last Updated On: Mar 4, 2022
# Suffix: FA
#
# Citations:
# Fariss, Christopher J. 2014. “Respect for human rights has improved over time: Modeling the
# changing standard of accountability.” American Political Science Review 108(2): 297–318.
#
# Schnakenberg, Keith E., and Christopher J. Fariss. 2014. “Dynamic Patterns of Human Rights
# Practices.” Political Science Research and Methods 2(1): 1–31.
#
# Fariss, Christopher; Michael Kenwick; Kevin Reuning, 2020, "Latent Human Rights Protection
# Scores Version 4", 
# https://doi.org/10.7910/DVN/RQ85GK, Harvard Dataverse, V2, UNF:6:QPg88sybNJyuljPYph2OXQ== [fileUNF]
# 
# Variables:
# See line 87-105
# /******************/

# clear everything
rm(list=ls())

# load packages
library(Hmisc)
library(tidyverse)

# set filepaths 
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/prepped/"
prepscripts <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/scripts/"
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/"

# import the dataset
fa <- read.csv(paste(rawdata,"RAWDATA_FA_2020.csv", sep=""))

# rename and select variables
fa2 <- fa %>%
  dplyr::select(country=country_name, year=YEAR, everything()) %>%
  dplyr::select(-c(CIRI,COW,killing_low,killing_best,killing_high,COW_YEAR,id))

names(fa2)


# append IDs
source(paste0(ids_path, "append_ids.R"))
fa3 <- append_ids(fa2, ids_path, dyad = F, breaks = F)

# Note: German Federal Republic and Yemen (Arab Republic of Yemen) duplicates in 1990

# drop duplicates 
fa3 <- fa3 %>%
  filter(!(year==1990 & countryname_raw=="German Federal Republic")) %>%
  filter(!(year==1990 & countryname_raw=="Yemen")) 

# check duplicates
n_occur <- data.frame(table(fa3$country,fa3$year))
print(n_occur[n_occur$Freq > 1,])
# no duplicates now


# label variables
names(fa3)
label(fa3$DISAP) <- "3 category ordered variable for disappearances from the CIRI dataset [FA]"
label(fa3$KILL) <- "3 category ordered variable from extra-judicial killing the CIRI dataset [FA]"
label(fa3$POLPRIS) <- "3 category ordered variable for political imprisonment from the CIRI  dataset [FA]"
label(fa3$TORT) <- "3 category ordered variable for torture from the CIRI dataset [FA]"
label(fa3$Amnesty) <- "5 category [FA]"
label(fa3$State) <- "5 category [FA]"
label(fa3$HRW) <- "5 category ordinal variable from the Political Terror Scale [FA]"
label(fa3$hathaway) <- "5 category ordered variable for torture from the Hathaway (2002) article [FA]"
label(fa3$ITT) <- "6 category ordered varible for torture from the ITT dataset [FA]"
label(fa3$genocide) <- "a binary variable for genocide from Harff's 2003 APSR article [FA]"
label(fa3$rummel) <- "a binary variable for politicide/genocide based on data from Rummel [FA]"
label(fa3$massive_repression) <- "a binary variable for massive repressive events taken from Harff and Gurr's 1980 ISQ article [FA]"
label(fa3$executions) <- "a binary variable taken from the World Handbook of political indicators [FA]"
label(fa3$negative_sanctions) <- "a binary variable taken from the World Handbook of Political Indicators [FA]"
label(fa3$killing_present) <- "binary version based on the UCDP one sided violence count data [FA]"
label(fa3$theta_mean) <- "the posterior mean of the latent variable (i.e. human rights protection) [FA]"
label(fa3$theta_sd) <- "the standard deviation of the posterior estimates for human rights protection [FA]"
label(fa3$killing_estimate_mean) <- "poseterior mean of the new latent one-sided killing variable [FA]"
label(fa3$killing_estimate_median) <- "poseterior median of the new latent one-sided killing variable [FA]"


# number of unique countries
length(unique(fa3$gwno)) #199

# range of dataset
range(fa3$year) #1946 - 2019

# append suffix
fa3 <- append_suffix(fa3, "FA")

n_occur <- data.frame(table(fa3$gwno, fa3$year))
print(n_occur[n_occur$Freq > 1,])

# save data
saveRDS(fa3,file=paste(preppeddata,"PREPPED_FA_RH_03062022.RDS", sep=""))

        