###############################
# Freedom House
# Version: 2017
# Accessed: April 14, 2017
# Year Range: 1972-2016
# Suffix: FH
# Last update: 04/14/2017
#
# Data: https://freedomhouse.org/report-types/freedom-world#.VZV8p_lVikp
# 
# Citation: Freedom House. 2017. Individual country ratings and status, FIW 1973-2017. 
# Freedom in the World. https://freedomhouse.org/report-types/freedom-world#.VZV8p_lVikp. 
# Accessed on April 14th, 2017.
# 
# Variables: RL: Rule of Law Index, CL: Gastil index of civil liberties, 
# PL: Gastil index of political liberties
# 
# Edited by Stephen Campbell, 2018
###############################

#used for rl
library(readxl)
library(Hmisc)
#used for cl and pr
library(dplyr)
library(tidyr)
library(stringr)

#change from .xls to .xlsx requires setting as data frame
FHrl = data.frame("Country", "Year", "rulelaw")

#manually set column names
colnames(FHrl) = c("Country", "Year", "rulelaw")
FHrl[,1:3] = as.numeric(FHrl[,1:3])

#importing for rule of law variable from separate spreadsheets
#only goes from 2006 to 2017, because the 2003-2005 data does not include RL variable, only CL and PR which I will grab from the other dataset
sheet_year = 2006
for(sheet_year in c(2006:2017)){
  ##2019 because I need to offset the sheets by 2
  fh = read_excel(paste(rawdata, "FreedomoftheWorld/FH_RL_2013_2018.xlsx",sep=""), sheet = 2019-sheet_year)
  #renaming variables
  names(fh)[names(fh)=="F Aggr"] = "rulelaw"
  names(fh)[names(fh)=="Country/Territory"] = "Country"
  
  #adding a new column that specifies year
  fh$Year = sheet_year
  #Keep only the variables we need
  fh = fh[, c("Country",
              "Year",
              "rulelaw")]
  
  #taking out territories get a vector of all territories
  territory_vector = grep("\\*",fh$Country)
  #take them out
  fh = fh[-c(territory_vector),]
  
  FHrl = rbind(FHrl, fh)
}

FHrl = FHrl[-c(1),]

#appending gwnos
FHrl = append_ids(FHrl, breaks = F)
FHrl = append_suffix(FHrl, "FH")

#Add variable labels
label(FHrl$rulelaw_FH) = "Rule of Law Index [FH]"

remove(fh)

save(FHrl, file = paste(preppeddata,"prepped_FHrl.RDATA",sep=""))

##### part 2 #####

#importing CL and PR variables from the large dataset
fh = read_excel(paste(rawdata, "FreedomoftheWorld/FH_PR_CL_1972_2017.xlsx",sep=""), sheet = 2)

#adding labels and headers
fh[2,1] = "Country"
colnames(fh) = fh[2,]

#deleting all of the 'Status' variable to keep what we need
fh = fh[, -which(names(fh) %in% c("Status"))]

#they started formatting their paper differently during 1989 and thus 
#there is no data for that year because it overlaps with the 1988 and 1990 data

#create the headers
columnnames = c()
for(x in 1:45){
  pryears = paste(c(1972:2016), "_pl", sep = "")
  clyears = paste(c(1972:2016), "_cl", sep = "")
  if(x != 18){
    columnnames = append(columnnames, values = pryears[x], after = length(columnnames))
    columnnames = append(columnnames, clyears[x], after = length(columnnames))
  }
  remove(pryears)
  remove(clyears)
}

#renaming columns
colnames(fh) = c("Country", columnnames)

#cutting out headers, including empty rows of "NA" at the bottom
fh = fh[3:207,]

#correct problem from .xlsx file format change
fh = as.data.frame(fh)

#reshape from all years after a country to country, yr_indicator, value
fh = gather(fh, "year", "value", 2:ncol(fh))

#remove extraneous column
fh = fh[,-2]

#split yr_indicator
year_ind = str_split_fixed(fh$year, "_", 2)

fh$year = year_ind[,1]
fh$indicator = year_ind[,2]

fh = as.data.frame(fh)
#separate into two datasets by indicator
prdata = filter(fh, indicator == "pl")
names(prdata)[names(prdata) == 'value'] <- 'pl'
cldata = filter(fh, indicator == "cl")
names(cldata)[names(cldata) == 'value'] <- 'cl'

#drop the indicator variable because the column has been renamed to the indicator
prdata = subset(prdata, select=-c(indicator))
cldata = subset(cldata, select=-c(indicator))

#merge by country and year
FHprcl <- merge(prdata,cldata,by=c("Country", "year"))

#cleanup
remove(fh)
remove(year_ind)
remove(columnnames)
remove(prdata)
remove(cldata)

#converting data to numerics
FHprcl$pl = as.numeric(FHprcl$pl)
FHprcl$cl = as.numeric(FHprcl$cl)

#append ids
FHprcl = append_ids(FHprcl, breaks = F)
FHprcl = append_suffix(FHprcl, "FH")

FH <- FHprcl

# Check Duplicates
n_occur <- data.frame(table(FH$country, FH$year))
print(n_occur[n_occur$Freq > 1,])

# --- Drop the duplicates
# Vietnam Duplicates
FH = FH[-which(FH$countryname_raw_FH == "Vietnam" & FH$year >= 1972 & FH$year <= 1975),]
FH = FH[-which(FH$countryname_raw_FH == "Vietnam, N." & FH$year >= 1976),]

# Czechoslovakia Duplicates
FH = FH[-which(FH$countryname_raw_FH == "Czechoslovakia" & FH$year >= 1993),]
FH = FH[-which(FH$countryname_raw_FH == "Czech Republic" & FH$year < 1993),]

# Germany Duplicates
FH = FH[-which(FH$countryname_raw_FH == "Germany" & FH$year >= 1972 & FH$year <= 1988),]
FH = FH[-which(FH$countryname_raw_FH == "Germany, W." & FH$year >= 1990),]

# Russia Duplicates
FH = FH[-which(FH$countryname_raw_FH == "Russia" & FH$year >= 1972 & FH$year <= 1990),]
FH = FH[-which(FH$countryname_raw_FH == "USSR" & FH$year >= 1991),]

# Yugoslavia and Serbia Duplicates
FH = FH[-which(FH$countryname_raw_FH == "Serbia" & FH$year >= 1972 & FH$year <= 2005),]
FH = FH[-which(FH$countryname_raw_FH == "Yugoslavia" & FH$year >= 1992),]
FH = FH[-which(FH$countryname_raw_FH == "Yugoslavia (Serbia & Montenegro)" &FH$year >= 2006),]
FH = FH[-which(FH$countryname_raw_FH == "Yugoslavia (Serbia & Montenegro)" &FH$year <= 1991),]

# Yemen Duplicates
FH = FH[-which(FH$countryname_raw_FH == "Yemen" & FH$year <= 1988),]
FH = FH[-which(FH$countryname_raw_FH == "Yemen, N." & FH$year >= 1990),]
FH = FH[-which(FH$countryname_raw_FH == "Yemen, S." & FH$year >= 1990),]


#Add variable labels
label(FH$pl_FH) = "Gastil index of political liberties [FH]"
label(FH$cl_FH) = "Gastil index of civil liberties [FH]"

#clanup
remove(n_occur)
remove(FHprcl)

#saving prepped data
save(FH,file=paste(preppeddata,"prepped_FHprcl.RDATA",sep=""))

