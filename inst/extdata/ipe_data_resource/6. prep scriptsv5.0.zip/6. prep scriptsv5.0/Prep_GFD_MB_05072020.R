#/**************************
#  Dataset: Global Financial Development Indicators 
# Data source url: https://databank.worldbank.org/reports.aspx?source=global-financial-development#
#  Codebook url: 
#  Time: 1960-2011
# Updated: 05/08/2020
# By: Miriam Barnum
# Suffix: GFD
# Notes:
#  ****************************/

library(tidyr)
library(dplyr)

gfd <- read.csv(paste(rawdata,"RAWDATA_GFD_2017.csv", sep=""), stringsAsFactors = F, blank.lines.skip = T)

gfd <- gfd %>% select(-Country.Code, -Series.Code) %>% 
  filter(Series.Name != "" ) %>%
  pivot_longer(cols = -c(Country.Name, Series.Name), names_to = "year") %>%
  pivot_wider(names_from = "Series.Name", values_from = "value") %>%
  mutate(year = substr(year, 2, 5)) %>%
  mutate_at(vars(-Country.Name), as.numeric)

names(gfd)[1] <- "country"
labels <- names(gfd)[3:ncol(gfd)]
names(gfd)[3:ncol(gfd)] <- c("frmlacct_ffi","bk_acct","bk_branch","bkcrisis","bkconc","depos_gdp",
                             "finconst","firms_bf","firms_bw","firms_loc","firms_chksv","forbnkast",
                             "forbnk","fd_gdp","wc_bfin","loancollat","dc_priv","h_stat","nr_loan",
                             "gpd_liab","gpe_liab","fb_cons","marketcap","stockvol","compratio")


label(gfd$frmlacct_ffi) <- "Account at a formal financial institution (% age 15+) [GFD]"
label(gfd$bk_acct) <- "Bank accounts per 1,000 adults [GFD]"
label(gfd$bk_branch) <- "Bank branches per 100,000 adults [GFD]"
label(gfd$finconst) <- "Firms identifying access to finance as a major constraint (%) [GFD]"
label(gfd$firms_bf) <- "Firms using banks to finance investments (%) [GFD]"
label(gfd$firms_bw) <- "Firms using banks to finance working capital (%) [GFD]"
label(gfd$firms_loc) <- "Firms with a bank loan or line of credit (%) [GFD]"
label(gfd$firms_chksv) <- "Firms with a checking or savings account (%) [GFD]"
label(gfd$loancollat) <- "Value of collateral needed for a loan (% of the loan amount) [GFD]"
label(gfd$wc_bfin) <- "Working capital financed by banks (%) [GFD]"
label(gfd$fd_gdp) <- "Financial system deposits to GDP (%) [GFD]"
label(gfd$dc_priv) <- "Domestic credit to private sector (% of GDP) [GFD]"
label(gfd$bkconc) <- "Bank concentration (%) [GFD]"
label(gfd$bkcrisis) <- "Banking crisis dummy (1=banking crisis, 0=none) [GFD]"
label(gfd$depos_gdp) <- "Bank deposits to GDP (%) [GFD]"
label(gfd$forbnkast) <- "Foreign bank assets among total bank assets (%) [GFD]"
label(gfd$forbnk) <- "Foreign banks among total banks (%) [GFD]"
label(gfd$h_stat) <- "H-statistic [GFD]"
label(gfd$nr_loan) <- "Loans from nonresident banks (amounts outstanding) to GDP (%) [GFD]"
label(gfd$fb_cons) <- "Consolidated foreign claims of BIS reporting banks to GDP (%) [GFD]"
label(gfd$gpd_liab) <- "Gross portfolio debt liabilities to GDP (%) [GFD]"
label(gfd$gpe_liab) <- "Gross portfolio equity liabilities to GDP (%) [GFD]"
label(gfd$marketcap) <- "Stock market capitalization to GDP (%) [GFD]"
label(gfd$compratio) <- "Number of listed companies per 1,000,000 people [GFD]"
label(gfd$stockvol) <- "Stock price volatility [GFD]"

gfd <- append_ids(gfd, breaks = F)
gfd <- append_suffix(gfd, "GFD")

save(gfd, file=paste(preppeddata,"PREPPED_GFD_MB_05072020.RDATA",sep=""))
