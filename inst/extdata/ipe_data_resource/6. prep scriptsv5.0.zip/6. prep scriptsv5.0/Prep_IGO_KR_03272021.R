# Kwaku Rogers 
# Inter-governmental Organizations Data Prep 
# March 27th 2021

# load library 
library(dplyr)

# clear everythimg
rm(list=ls())


# set file paths 
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2021/rawdata/" 
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2021/prepped/" 
prepscripts <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2021/scripts/"


# load in data 
cowigo<-read.csv(paste(rawdata,"RAWDATA_IGO_2019.csv",sep=""))  # 2019 data 

 # Check variable names 
names(cowigo)  

# Check if years are numeric; they are in integer form 
str(cowigo$year) 

# Convert from integer to numeric 
cowigo$year <- as.numeric(cowigo$year) 

# Check to see if numeric 
str(cowigo$year)  

# Check for duplicates, no duplicates found 
n_occur <- data.frame(table(cowigo$state, cowigo$year))
print(n_occur[n_occur$Freq > 1,])

#Rename state variable to country 
cowigo<-cowigo %>%     
  rename(country = state) 

states<-cowigo$country
# Counts number of countries 217 
length(unique(states)) 



# Load  Append IDs function 
source(paste(prepscripts,"append_ids.R",sep="")) 

# Use Append IDs function   # NA is not given gwno code 
cowigo <- append_ids(cowigo, breaks = F)  






# Check for new variables added in after Append IDs function 
names(cowigo) 


# Move countryname_raw to beginning of dataset for reference 
cowigo<- cowigo %>%
  select(country,
         gwno,
         year,
         ccode,
         ifs,
         ifscode,
         gwabbrev,
         ccode_raw,
         countryname_raw,everything())  




# No duplicates after append ids 
n_occur2 <- data.frame(table(cowigo$country, cowigo$year))
print(n_occur2[n_occur$Freq > 1,])  

# open label library 
library(Hmisc)

# added labels
# IGO label stands for Inter-governmental Organizations Data
cowigo <- append_suffix(cowigo,"IGO")

# label correlates of war code 
label(cowigo$ccode_raw_IGO) <- "Correlates of War code"
label(cowigo$AAAID_IGO)<-"IGO Variables containing information on state membership status"

# save prepped  data 
save(cowigo, file=paste(preppeddata,"PREPPED_IGO_KR_03272021.RDATA",sep="")) 












