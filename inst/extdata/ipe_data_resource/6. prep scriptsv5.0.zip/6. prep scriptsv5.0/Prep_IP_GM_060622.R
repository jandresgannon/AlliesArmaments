###################3
# Patent Protection Index (Park 2008, updated 2015) [IP]
# 06/06/2022, Gaea Morales

library(tidyverse)
library(readxl)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"

ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste0(ids_path, "append_ids.R"))

#add_name("Saudi Ar.", "saudi arabia")

ip <- read_excel(paste0(rawdata, "RAWDATA_IP_GM_2015.xlsx")) %>% 
  pivot_longer(names_to = "year", values_to = "ipp_index_IP", c(2:13)) %>% 
  append_ids(breaks = F) %>% 
  arrange(gwno, year) %>% 
  select(-countryname_raw)

#Check for Duplicates
n_occur <- data.frame(table(ip$country, ip$year))
print(n_occur[n_occur$Freq > 1,])

saveRDS(ip, paste(preppeddata, "PREPPED_IP_GM_06062022.RDS"))
