#/**************************
# Data: Ilzetski, Reinhardt and Rogoff Exchange Rate Regime data
# Data source url: https://www.ilzetzki.com/irr-data
# Time: 1950-2021
#
# Date: Dec 7, 2021
# By: Robert Huang
# Suffix: IRK
# 
# Citations:
#  Ethan Ilzetzki, Carmen Reinhart and Ken Rogoff, Exchange Arrangements Entering the 21st 
#  Century: Which Anchor Will Hold? , Quarterly Journal of Economics, 134:2, 599–646, 2019.
#
#  Ethan Ilzetzki, Carmen Reinhart and Ken Rogoff, Rethinking Exchange Rate Regimes (with 
#  Carmen Reinhart and Ken Rogoff). Handbook of International Economics, vol 5, Gita 
#  Gopinath, Elhanan Helpman and Kenneth Rogoff, eds, 2021.
# #****************************/

# clear everything
rm(list=ls())

# load packages
library(Hmisc)
library(tidyverse)
library(readxl)

# set filepaths 
rawdata <- "GoogleDrive/My Drive/Master IPE Data/FALL 2021/scripts/"
preppeddata <- "GoogleDrive/My Drive/Master IPE Data/FALL 2021/prepped/"
prepscripts <- "GoogleDrive/My Drive/Master IPE Data/FALL 2021/rawdata/"
ids_path <- "GoogleDrive/My Drive/append_ids/"

# load anchor currency data
anchor <- read_xlsx(paste(rawdata,"RAWDATA_IRK_Anchor_2019.xlsx",sep=""),sheet = 2,skip = 6)
anchor <- anchor[-c(1,2,3),]

# filter years and create year variable
anchor2 <- anchor %>%
  filter(grepl("M1",Country,fixed = T) & !grepl("M10",Country,fixed = T) & 
           !grepl("M11",Country,fixed = T) & !grepl("M12",Country,fixed = T)) %>%
  select(year=Country,everything()) %>%
  mutate(year=1946:2019)

# reshape the data
anchor3 <- anchor2 %>%
  pivot_longer(Afghanistan:Yugoslavia,names_to="country") %>%
  select(anchor=value,everything()) %>%
  mutate(anchor=ifelse(anchor=="n.a.",NA,anchor))

# append IDs
source(paste0(ids_path, "append_ids.R"))
anchor4 <- append_ids(anchor3, ids_path, dyad = F, breaks = F)

# duplicates: Czech Republic, Russia, Serbia
anchor5 <- anchor4 %>%
  filter(!(gwno==316&is.na(anchor)) & !(gwno==315&countryname_raw=="Czech Republic")) %>%
  filter(!(gwno==340&is.na(anchor)) & !(gwno==345&year<=1997&countryname_raw=="Serbia") 
         & !(gwno==345&year>1997&countryname_raw=="Yugoslavia")) %>%
  filter(!(gwno==365&countryname_raw=="USSR"))

# check for duplicates
n_occur <- data.frame(table(anchor5$gwno, anchor5$year))
print(n_occur[n_occur$Freq > 1,])
# no duplicate

# select vars
anchor5 <- select(anchor5,country:gwabbrev,anchor)


# load classification data
cla <- read_xlsx(paste(rawdata,"RAWDATA_IRK_Classification_2019.xlsx",sep=""),sheet = 4,skip = 5)

# select rows and rename column
cla <- cla[2:nrow(cla),]
names(cla)[1] <- "year"

cla <- cla %>%
  rename("Democratic Republic of the Congo"="Rep. of...42") %>%
  rename("Republic of the Congo"="Rep. of...43") %>%
  rename("Costa Rica"="Rica") %>%
  rename("Hong Kong"="Kong") %>%
  rename("Saudi Arabia"="Arabia") %>%
  rename("Sri Lanka"="Lanka") %>%
  rename("United Kingdom"="Kingdom") %>%
  rename("United States"="States") %>%
  rename("Serbia"="Rep. of...153") %>%
  rename("Slovak"="Republic...157")
  
names(cla) 

# filter years and create year variable
cla2 <- cla %>%
  filter(grepl("M1",year,fixed = T) & !grepl("M10",year,fixed = T) & 
           !grepl("M11",year,fixed = T) & !grepl("M12",year,fixed = T)) %>%
  mutate(year=1946:2019)

# reshape the data
cla3 <- cla2 %>%
  mutate_all(funs(as.numeric(as.character(.)))) %>%
  pivot_longer(Afghanistan:Zimbabwe,names_to="country") %>%
  select(class=value,everything()) 

# append IDs
cla4 <- append_ids(cla3, ids_path, dyad = F, breaks = F)

# check for duplicates
n_occur <- data.frame(table(cla4$gwno, cla4$year))
print(n_occur[n_occur$Freq > 1,])
# no duplicate

# select vars
cla4 <- select(cla4,country:gwabbrev,class)


# load unified market data
um <- read_xlsx(paste(rawdata,"RAWDATA_IRK_Unified_2021.xlsx",sep=""),sheet = 2,skip = 6)
um <- um[-c(1,2,3),]

# filter years and create year variable
um2 <- um %>%
  filter(!grepl("M2",Country,fixed = T) & !grepl("M3",Country,fixed = T) & 
           !grepl("M4",Country,fixed = T) & !grepl("M5",Country,fixed = T) & 
           !grepl("M6",Country,fixed = T) & !grepl("M7",Country,fixed = T) & 
           !grepl("M8",Country,fixed = T) & !grepl("M9",Country,fixed = T) &
           !grepl("M10",Country,fixed = T) & !grepl("M11",Country,fixed = T) & 
           !grepl("M12",Country,fixed = T)) %>%
  select(year=Country,everything()) %>%
  mutate(year=1946:2021)

um2 <- um2[,-(197:200)]

# reshape the data
um3 <- um2 %>%
  mutate_all(funs(as.numeric(as.character(.)))) %>%
  pivot_longer(Afghanistan:USSR,names_to="country") %>%
  select(unified=value,everything()) 

# append IDs
um4 <- append_ids(um3, ids_path, dyad = F, breaks = F)

# duplicate: Russia
um5 <- um4 %>%
  filter(!(gwno==365&countryname_raw=="USSR"))

# check for duplicates
n_occur <- data.frame(table(um5$gwno, um5$year))
print(n_occur[n_occur$Freq > 1,])
# no duplicate

# select vars
um5 <- select(um5,country:gwabbrev, unified)



# merge all three datasets
irk <- cla4 %>%
  full_join(anchor5,by=c("country","year")) %>%
  full_join(um5,by=c("country","year")) %>%
  select(country,year,class,anchor,unified)

# append IDs
irk2 <- append_ids(irk, ids_path, dyad = F, breaks = F)

# check for duplicates
n_occur <- data.frame(table(irk2$gwno, irk2$year))
print(n_occur[n_occur$Freq > 1,])
# no duplicate

# append suffix
irk2 <- append_suffix(irk2,"IRK")

# add labels
label(irk2$class_IRK) <- "Exchange Rate Arrangement Classification (1=peg, 2=crawling peg,
3=managed floating, 4=freely floating, 5=freely falling, 6=dual market)"
label(irk2$anchor_IRK) <- "Anchor Currency"
label(irk2$unified_IRK) <- "Unifed Market (1=unified, 0=not unified)"

# save data
save(irk2,file=paste(preppeddata,"prepped_IRK_RH_12082021.RDATA",sep=""))



