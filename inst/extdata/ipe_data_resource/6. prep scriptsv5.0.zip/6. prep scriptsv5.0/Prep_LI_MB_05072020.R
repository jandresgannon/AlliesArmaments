# /************************* 
# Append Year to Tax Incentive Data
# 53 countries; cross sectional data from 2006
# *************************/

library(Hmisc)
library(readstata13)


# Read the dta file from prepped data folder
LI <- read.dta13(paste(rawdata,"RAWDATA_LI.dta", sep=""))

# data cross-sectional from 2006
LI$year <- 2006

# Drop ccode raw column
LI$ccode_raw <- NULL

# Add variable labels
label(LI$taxincentsum_LI) <- "Sum of six types of tax incentives [LI]"

length(unique(LI$gwno)) #53

save(LI,file=paste(preppeddata,"PREPPED_LI_MB_052020.RDATA",sep=""))
