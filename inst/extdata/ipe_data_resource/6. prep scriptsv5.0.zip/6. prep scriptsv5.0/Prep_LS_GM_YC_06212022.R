#################################################
# Linzner and Staton Latent Measure of Judicial Independence (Linzer and Staton 2015) [LS]
#
# Countries: 201 
# Time Period: 1900-2015
#
# 06/06/2022, Gaea Morales
# 06/21/2022, edited by Yeiyoung Choo
################################################

library(tidyverse)
library(readxl)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"

ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste0(ids_path, "append_ids.R"))

ls <- read_csv(paste0(rawdata, "RAWDATA_LS_GM_2015.csv"))

# Rename variables and append IDs 
ls <- ls %>% 
  rename(lji_LS = LJI,
         lji_sd_LS = post.sd) %>% 
  append_ids(breaks = F) 

# Check for duplicates
n_occur <- data.frame(table(ls$country, ls$year))
n_occur[n_occur$Freq>1,]

# Resolve duplicates 

# Yemen & Yemen Arab Republic duplicates 1948-1990
# Note these Yemen entries  
 # Yemen: 1918-2015
 # Yemen Arab Republic: 1948-1990 (but only existed from 1962-1990)
 # Yemen People's Republic: 1900-1990 (but only existed from 1967-1990)
# Keep Yemen Arab Republic for 1962-1990 and drop it for other years 
# Keep Yemen People's Republic for 1967-1990 and drop it for other years 
# Keep united Yemen for 1918-1966 and 1991onward # drop for 1967-1990 where divided 
ls <- ls[!(ls$countryname_raw == "Yemen Arab Republic" & ls$year >= 1948 & ls$year <= 1961),]
ls <- ls[!(ls$countryname_raw == "Yemen People's Republic" & ls$year >= 1900 & ls$year <= 1966),]
ls <- ls[!(ls$countryname_raw == "Yemen" & ls$year >= 1967 & ls$year <= 1990),]

# Further resolve for Yemen & Yemen Arab Republic 1962-1966
 # where Arab Republic formed in north in 1962 and rest of Yemen was still in war 
 # until People's Republic formed in south in 1967
# Keep Yemen Arab Republic and drop Yemen for this period 
ls <- ls[!(ls$countryname_raw == "Yemen" & ls$year >= 1962 & ls$year <= 1966),]

# Note: 
# Yemen (Arab Republic of Yemen) # gwno 678 
  # country raw name is Yemen 1918-1961 and 1991 onward
                      # Yemen Arab Republic 1962-1990 
# People's Republic of Yemen # gwno 680 
  # country raw name is Yemen People's Republic 1967-1990 

# Czechoslovakia & Czech Republic duplicates 1948-1992 
# Drop Czech Republic, since Czechoslovakia existed until 1992 #gwno 315
# Note: Czech Republic has single entries starting 1993 #gwno 316
ls <- ls[!(ls$countryname_raw == "Czech Republic" & ls$year >= 1948 & ls$year <= 1992),]

# Germany & German Federal Republic duplicates 1950-1990 
  # where German Democratic Republic entries also exist until 1990 
# Drop Germany and keep German Federal Republic, since Germany was divided in this period 
ls <- ls[!(ls$countryname_raw == "Germany" & ls$year >= 1950 & ls$year <= 1990),]

# Russia & Soviet Union duplicates 1948-1991 
# Drop Russia and keep Soviet Union, since Soviet Union was in place until 1991 
ls <- ls[!(ls$countryname_raw == "Russia" & ls$year >= 1948 & ls$year <= 1991),]

# Yugoslavia & Serbia duplicates 2006 
# Serbia became independent country in 2006
# Drop Serbia and keep Yugoslavia #gwno 345
ls <- ls[!(ls$countryname_raw == "Serbia" & ls$year == 2006),]

# Yugoslavia & Serbia duplicates 2007-2015 
# Serbia became independent country in 2006
# Drop Yugoslavia and keep Serbia #gwno 340 
ls <- ls[!(ls$countryname_raw == "Yugoslavia" & ls$year >= 2007),]

# How many countries? What time period?
length(unique(ls$gwno)) #201
range(ls$year) #1900-2015

# Label variables 
label(ls$lji_LS) <- "Latent Judicial Independence Measure [LS]"

# Save
saveRDS(ls, file = paste(preppeddata,"Prepped_LS_GM_YC_06212022.RDS", sep=""))
