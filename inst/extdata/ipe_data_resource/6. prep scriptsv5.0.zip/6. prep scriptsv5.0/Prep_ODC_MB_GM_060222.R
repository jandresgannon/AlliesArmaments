##################################
#  UNODC Crime Data (ODC)
# Suffix: ODC
# Data: data.unodc.org
# Codebook: https://www.unodc.org/unodc/en/data-and-analysis/statistics/crime.html 
# Years 1990-2020
# Citation:
#  United Nations Office on Drugs and Crime. 2022 Crime and criminal 
#justice statistics. data.unodc.org. Accessed on July 8, 2016.


# Updated November 24, 2018
# Edited by Anna Lipscomb
# Edited MB 05/07/2020 - 2000 - 2015
# Edited Gaea Morales 06/02/2022  - 2000
###################################

library(Hmisc)
library(readxl)
library(dplyr)
library(tidyr)
library(tidyverse)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"

ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste0(ids_path, "append_ids.R"))

###############
# Economic crimes (2003-2020)

# only want burglary, theft, theft: of a motorized vehicle

econ <- read_excel(paste0(rawdata,"RAWDATA_ODC_ECON_GM_2020.xlsx"),skip=2)  %>% 
  select(Year, Country, Category, `Unit of measurement`, VALUE) %>% 
  filter(Category %in% c("Theft", "Theft: of a motorized vehicle", "Burglary")) %>% 
  unite(var, Category:"Unit of measurement") %>% 
  select(Year, Country, var, VALUE) %>% 
  pivot_wider(names_from = var, values_from = VALUE) %>% 
  select(Country, Year,
         "theft_count" = Theft_Counts,
         "mvtheft_count" = `Theft: of a motorized vehicle_Counts`,
         "burg_count" = `Burglary_Counts`,
         "theft_rate" = `Theft_Rate per 100,000 population`,
         "mvtheft_rate" = `Theft: of a motorized vehicle_Rate per 100,000 population`,
         "burg_rate" = `Burglary_Rate per 100,000 population`) %>% 
  relocate(Country, Year, theft_count, theft_rate, mvtheft_count, mvtheft_rate,
           burg_count, burg_rate) 
  

###############
# Violent crimes (2003-2020)

# only want robbery 

viol <- read_excel(paste0(rawdata,"RAWDATA_ODC_VIOLENT_GM_2020.xlsx"),skip=2) %>% 
  select(Year, Country, Category, `Unit of measurement`, VALUE) %>% 
  filter(Category == "Robbery") %>% 
  unite(var, Category:"Unit of measurement") %>% 
  select(Year, Country, var, VALUE) %>% 
  pivot_wider(names_from = var, values_from = VALUE) %>% 
  select(Country, Year, "robbery_count" = Robbery_Counts,
         "robbery_rate" = `Robbery_Rate per 100,000 population`)

###############
# Homicide 

# total (1990-2021) - "Victims of intentional homicide_Counts"and "Victims of intentional homicide_Rate per 100,000 population
homtot <- read_excel(paste0(rawdata,"RAWDATA_ODC_HOMTOT_GM_2020.xlsx"),skip=2) %>% 
  select(Country, Year, Indicator, `Unit of measurement`, VALUE, Dimension, Category, Sex, Age) %>% 
  filter(Indicator %in% c("Victims of intentional homicide","Victims of intentional homicide") &
           Dimension == "Total", Category == "Total", Sex == "Total", Age == "Total")  %>% 
  select(-c(Dimension, Category, Sex, Age)) %>% 
  unite(var, Indicator:"Unit of measurement")  %>% 
  pivot_wider(names_from = "var", values_from = "VALUE") %>% 
  select(Country, Year,
         "homicide_count" = "Victims of intentional homicide_Counts", 
         "homicide_rate" = "Victims of intentional homicide_Rate per 100,000 population")

# getting list of most populated city from past data 
mpcs <- read_excel(paste0(rawdata,"RAWDATA_ODC_homicidempc_2012_MPCS.xlsx"),skip=3) %>% 
  select(City)

# in most populated city (2003-2017)
hom <- read_excel(paste0(rawdata,"RAWDATA_ODC_HOM_GM_2017.xls")) %>% 
  pivot_longer(names_to = "Year", values_to = "val", c(5:19)) %>% 
  pivot_wider(names_from = "Unit", values_from = "val") %>% 
  filter(City %in% mpcs$City) %>%  # using the city from previous data, so we only have one city for each country
  select(Country, Year,
         "mpcity" = City, "hommicidempc_count" = Count,
         "hommicidempc_rate" = Rate) %>% 
  mutate_at(2:4, as.numeric) %>% 
  group_by(Country, Year) %>% 
  distinct()


# merge all 
odc_update <- full_join(econ, viol, by = c("Country", "Year")) %>%  
  full_join(homtot,  by = c("Country", "Year"))  %>% 
  full_join(hom,  by = c("Country", "Year")) %>% 
  group_by(Country, Year) %>% 
  distinct() %>% 
  append_ids(breaks = F) %>% 
  filter(!(country == "Macedonia (Former Yugoslav Republic of)" & countryname_raw == "The former Yugoslav Republic of Macedonia")) %>% 
  filter(!(country == "Serbia" & is.na(theft_count))) %>% 
  filter(!(country == "Iraq" & year > 1994 & is.na(theft_count))) %>% 
   group_by(gwno, year) %>% 
  distinct() %>% 
  select(-countryname_raw)

odc_update <- append_suffix(odc_update, "ODC")

#Check for Duplicates
n_occur <- data.frame(table(odc_update$country, odc_update$year))
print(n_occur[n_occur$Freq > 1,])

saveRDS(odc_update,paste(preppeddata, "PREPPED_ODC_GM_060222.RDS"))



#### OLD CODE 


####################
#  Burglary Data
# Years: 2003-2015
###################

#Read raw data
burglary <-read_excel(path = (paste(rawdata, "RAWDATA_ODC_burglary_2015.xlsx", sep="")), skip = 0) 

# Get rid of lines
names(burglary) <- burglary[15,]
burglary <- burglary[c(16:142), ]

# Burg Count
burg_count <- burglary[ , c(1:16)]
burg_count <- gather(burg_count, "Year", "burg_count", 4:16)

# Burg Rate
burg_rate <- burglary[ ,c(18:30)]
burg_rate <- gather(burg_rate, "Year", "burg_rate", 1:13)
burg_rate <- burg_rate[("burg_rate")]

# Merge
ODC_burglary <- cbind(burg_count, burg_rate)

# Get rid of unnecessary columns
ODC_burglary <- subset(ODC_burglary, select = -c(Region, `Sub Region` ) )

# Label
label(ODC_burglary$burg_count) <- "Burglary, number of police recorded offences [ODC]"
label(ODC_burglary$burg_rate) <- "Burglary, police recorded offences per 10,000 of population [ODC]"

ODC_burglary$burg_count <- as.numeric(ODC_burglary$burg_count)
ODC_burglary$burg_rate <- as.numeric(ODC_burglary$burg_rate)

UK <- ODC_burglary[grep("United Kingdom", ODC_burglary$Country),] %>%
  dplyr::select(-Country) %>% group_by(Year) %>% 
  dplyr::summarise(burg_count = sum(burg_count), burg_rate = mean(burg_rate, na.rm = T)) %>%
  mutate(Country = "UK")
ODC_burglary <- bind_rows(ODC_burglary, UK)

# Append ids
ODC_burglary <- append_ids(ODC_burglary, breaks = F)

# Save a temporaray file
# save(ODC_burglary,file=paste(preppeddata,"ODC_burglary.RDATA",sep=""))

##################
#  Domestic Burglary (Housebreak)
# Years: 2003-2015
##################
housebrk <-read_excel(path = (paste(rawdata, "RAWDATA_ODC_housebrk_2015.xlsx", sep="")), skip = 0)

# Get rid of lines
# Rename 
names(housebrk) <- housebrk [15,]
housebrk <- housebrk[c(16:126),]

# House break Count
housebrk_count <- housebrk[ , c(1:16)]
housebrk_count <- gather(housebrk_count, "Year", "housebrk_count", 4:16)

# House break Rate
housebrk_rate <- housebrk[ ,c(18:30)]
housebrk_rate <- gather(housebrk_rate, "Year", "housebrk_rate", 1:13)
housebrk_rate <- housebrk_rate[("housebrk_rate")]

# Merge
ODC_housebrk <- cbind(housebrk_count, housebrk_rate)

# Get rid of unnecessary columns
ODC_housebrk <- subset(ODC_housebrk, select = -c(Region, `Sub Region` ))

ODC_housebrk$housebrk_count <- as.numeric(ODC_housebrk$housebrk_count)
ODC_housebrk$housebrk_rate <- as.numeric(ODC_housebrk$housebrk_rate)

# combine UK data
UK <- ODC_housebrk[grep("United Kingdom", ODC_housebrk$Country),] %>%
  dplyr::select(-Country) %>% group_by(Year) %>% 
  dplyr::summarise(housebrk_count = sum(housebrk_count), housebrk_rate = mean(housebrk_rate, na.rm = T)) %>%
  mutate(Country = "UK")
ODC_housebrk <- bind_rows(ODC_housebrk, UK)

# Label
label(ODC_housebrk$housebrk_count) <- "Housebreaking, number of police recorded offences [ODC]"
label(ODC_housebrk$housebrk_rate) <- "Housebreaking, police recorded offences per 10,000 of population [ODC]"

#Append ids
ODC_housebrk <- append_ids(ODC_housebrk, breaks = F)

##################
#  Motor Vehicle Theft
# Years: 2003-2015
#TODO: Handle UK
##################

mvtheft <-read_excel(path = (paste(rawdata, "RAWDATA_ODC_mvtheft_2015.xlsx", sep="")), skip = 0)

# Get rid of lines
# Rename 
names(mvtheft) <- mvtheft [15,]
mvtheft <- mvtheft[c(16:126),]

# House break Count
mvtheft_count <- mvtheft[ , c(1:16)]
mvtheft_count <- gather(mvtheft_count, "Year", "mvtheft_count", 4:16)

# House break Rate
mvtheft_rate <- mvtheft[ ,c(18:30)]
mvtheft_rate <- gather(mvtheft_rate, "Year", "mvtheft_rate", 1:13)
mvtheft_rate <- mvtheft_rate[("mvtheft_rate")]

# Merge
ODC_mvtheft <- cbind(mvtheft_count, mvtheft_rate)

# Get rid of unnecessary columns
ODC_mvtheft <- subset(ODC_mvtheft, select = -c(Region, `Sub Region` ))

ODC_mvtheft$mvtheft_count <- as.numeric(ODC_mvtheft$mvtheft_count)
ODC_mvtheft$mvtheft_rate <- as.numeric(ODC_mvtheft$mvtheft_rate)

# combine UK data
UK <- ODC_mvtheft[grep("United Kingdom", ODC_mvtheft$Country),] %>%
  dplyr::select(-Country) %>% group_by(Year) %>% 
  dplyr::summarise(mvtheft_count = sum(mvtheft_count), mvtheft_rate = mean(mvtheft_rate, na.rm = T)) %>%
  mutate(Country = "UK")
ODC_mvtheft <- bind_rows(ODC_mvtheft, UK)

# Label
label(ODC_mvtheft$mvtheft_count) <- "Motor Vehicle Theft, number of police-recorded offences [ODC]"
label(ODC_mvtheft$mvtheft_rate) <- "Motor Vehicle Theft, police-recorded offences per 10,000 of population [ODC]"

#Append ids
ODC_mvtheft <- append_ids(ODC_mvtheft, breaks = F)

##################
#  Theft of Private Cars
# Years: 2003-2014
# Note, for some reason, the data set has the "Rape" description for the theft of personal vehicles data set - 
# I checked the other data sets and this is the correct one
##################

theftcars <-read_excel(path = (paste(rawdata, "RAWDATA_ODC_theftcars_2014.xlsx", sep="")), skip = 0)

# Get rid of lines
# Rename 
names(theftcars) <- theftcars[15,]
theftcars <- theftcars[c(16:168),]

# House break Count
theftcars_count <- theftcars[ , c(1:15)]
theftcars_count <- gather(theftcars_count, "Year", "theftcars_count", 4:15)

# House break Rate
theftcars_rate <- theftcars[ ,c(17:28)]
theftcars_rate <- gather(theftcars_rate, "Year", "theftcars_rate", 1:12)
theftcars_rate <- theftcars_rate[("theftcars_rate")]

# Merge
ODC_theftcars <- cbind(theftcars_count, theftcars_rate)

# Get rid of unnecessary columns
ODC_theftcars <- subset(ODC_theftcars, select = -c(Region, `Sub Region` ))

ODC_theftcars$theftcars_count <- as.numeric(ODC_theftcars$theftcars_count)
ODC_theftcars$theftcars_rate <- as.numeric(ODC_theftcars$theftcars_rate)

#Append ids
ODC_theftcars <- append_ids(ODC_theftcars, breaks = F)

# Label
label(ODC_theftcars$theftcars_count) <- "Theft of Private Cars, number of police recorded offences [ODC]"
label(ODC_theftcars$theftcars_rate) <- "Theft of Private Cars, police recorded offences per 10,000 of population [ODC]"

ODC_theftcars <- ODC_theftcars %>% 
  group_by(country) %>%
  slice(seq(2, n(), by =2))

##################
#  Theft
# Years: 2003-2015
# TODO: Handle UK
##################
theft <-read_excel(path = (paste(rawdata, "RAWDATA_ODC_theft_2015.xlsx", sep="")), skip = 0)

# Get rid of lines
names(theft) <- theft[15,]
theft <- theft[c(16:156), c(3:30)]

# Theft Count
theft_count <- theft[ , c(1:14)]
theft_count <- gather(theft_count, "Year", "theft_count", 2:14)

# Theft Rate
theft_rate <- theft[ ,c(16:28)]
theft_rate <- gather(theft_rate, "Year", "theft_rate", 1:13)
theft_rate <- theft_rate[("theft_rate")]

# Merge
ODC_theft <- cbind(theft_count, theft_rate)

ODC_theft$theft_count <- as.numeric(ODC_theft$theft_count)
ODC_theft$theft_rate <- as.numeric(ODC_theft$theft_rate)

# combine UK data
UK <- ODC_theft[grep("United Kingdom", ODC_theft$Country),] %>%
  dplyr::select(-Country) %>% group_by(Year) %>% 
  dplyr::summarise(theft_count = sum(theft_count), theft_rate = mean(theft_rate, na.rm = T)) %>%
  mutate(Country = "UK")
ODC_theft <- bind_rows(ODC_theft, UK)

# Label
label(ODC_theft$theft_count) <- "Theft, number of police-recorded offences [ODC]"
label(ODC_theft$theft_rate) <- "Theft, police-recorded offences per 10,000 of population [ODC]"

#Append ids
ODC_theft <- append_ids(ODC_theft, breaks = F)

##################
#  Robbery
# Years: 2003-2015
# TODO: Handle UK
##################
robbery <-read_excel(path = (paste(rawdata, "RAWDATA_ODC_robbery_2015.xlsx", sep="")), skip = 0)

# Get rid of lines
names(robbery) <- robbery[15,]
robbery <- robbery[c(16:157), c(3:30)]

# Robbery Count
robbery_count <- robbery[ , c(1:14)]
robbery_count <- gather(robbery_count, "Year", "robbery_count", 2:14)

# Robbery Rate
robbery_rate <- robbery[ ,c(16:28)]
robbery_rate <- gather(robbery_rate, "Year", "robbery_rate", 1:13)
robbery_rate <- robbery_rate[("robbery_rate")]

# Merge
ODC_robbery <- cbind(robbery_count, robbery_rate)

ODC_robbery$robbery_count <- as.numeric(ODC_robbery$robbery_count)
ODC_robbery$robbery_rate <- as.numeric(ODC_robbery$robbery_rate)

# combine UK data
UK <- ODC_robbery[grep("United Kingdom", ODC_robbery$Country),] %>%
  dplyr::select(-Country) %>% group_by(Year) %>% 
  dplyr::summarise(robbery_count = sum(robbery_count), robbery_rate = mean(robbery_rate, na.rm = T)) %>%
  mutate(Country = "UK")
ODC_robbery <- bind_rows(ODC_robbery, UK)

# Label
label(ODC_robbery$robbery_count) <-  "Robbery, number of police-recorded offences [ODC]"
label(ODC_robbery$robbery_rate) <- "Robbery, police-recorded offences per 10,000 of population [ODC]"

# Append ids
ODC_robbery <- append_ids(ODC_robbery, breaks = F)

##################
#  Homicide counts and rates
# Years: 
#################
homicide <-read_excel(path = (paste(rawdata, "RAWDATA_ODC_homicide_2015.xlsx", sep="")), skip = 0)

# Get rid of lines
names(homicide) <- homicide[16,]
homicide <- homicide[c(17:237), c(3:30)]

# Homicide Count
homicide_count <- homicide[ , c(1:14)]
homicide_count <- gather(homicide_count, "Year", "homicide_count", 2:14)

# Homicide Rate
homicide_rate <- homicide[ ,c(16:28)]
homicide_rate <- gather(homicide_rate, "Year", "homicide_rate", 1:13)
homicide_rate <- homicide_rate[("homicide_rate")]

# Merge
ODC_homicide <- cbind(homicide_count, homicide_rate)
ODC_homicide$homicide_count <- as.numeric(ODC_homicide$homicide_count)
ODC_homicide$homicide_rate <- as.numeric(ODC_homicide$homicide_rate)

# Label
label(ODC_homicide$homicide_count) <-  "Intentional homicides [ODC]"
label(ODC_homicide$homicide_rate) <- "Intentional homicides per 10,000 of population [ODC]"

#Append ids
ODC_homicide <- append_ids(ODC_homicide, breaks = F)

# fix Iraq
ODC_homicide <-  ODC_homicide %>% group_by(country, gwno, year, ccode, ifs, ifscode, gwabbrev) %>% 
  summarise_at(vars(homicide_count, homicide_rate), max, na.rm = T)
ODC_homicide[ODC_homicide == -Inf] <- NA 

##################
#  Homicide in most populated city
# Years: 2005-2012
##################
homicidempc <-read_excel(path = (paste(rawdata, "RAWDATA_ODC_homicidempc_2012.xlsx", sep="")), skip = 0)

#figure out what is going on with the cities

# Get rid of lines
names(homicidempc) <- homicidempc[3,]
homicidempc <- homicidempc[c(4:257), c(3:14)]
names(homicidempc)[1] <- "Country"
homicidempc$Source <- NULL

# reshape
ODC_homicidempc <- pivot_longer(homicidempc, cols = 4:11, names_to = "Year") %>%
  pivot_wider(names_from = Indicator, values_from = value)

names(ODC_homicidempc)[2] <- "mpcity"
names(ODC_homicidempc)[4] <- "homicidempc_count"
names(ODC_homicidempc)[5] <- "homicidempc_rate"

# Reorder columns
ODC_homicidempc <- ODC_homicidempc[c("Country", "Year", "mpcity","homicidempc_count","homicidempc_rate")]

# London is most populous in the UK, so we'll just use that
ODC_homicidempc$Country[ODC_homicidempc$Country == "United Kingdom (England and Wales)"] <- "United Kingdom"

# Label
label(ODC_homicidempc$homicidempc_count) <-  "Intentional homicide count in most populated city [ODC]"
label(ODC_homicidempc$homicidempc_rate) <- "Intentional homicide rate per 10,000 of population in most populated city [ODC]"
label(ODC_homicidempc$mpcity) <- "The most populated city in each country [ODC]"

#Append ids
ODC_homicidempc <- append_ids(ODC_homicidempc, breaks = F)

##################
# Merge
##################
ODC <- merge(ODC_burglary, ODC_homicide, by =c("country","gwno","year","ccode","ifs","ifscode","gwabbrev"), all = TRUE)
ODC <- merge(ODC, ODC_homicidempc, by=c("country","gwno","year","ccode","ifs","ifscode","gwabbrev"), all = TRUE)
ODC <- merge(ODC, ODC_housebrk, by=c("country","gwno","year","ccode","ifs","ifscode","gwabbrev"), all = TRUE)
ODC <- merge(ODC, ODC_mvtheft, by=c("country","gwno","year","ccode","ifs","ifscode","gwabbrev"), all = TRUE)
ODC <- merge(ODC, ODC_robbery, by=c("country","gwno","year","ccode","ifs","ifscode","gwabbrev"), all = TRUE)
ODC <- merge(ODC, ODC_theft, by=c("country","gwno","year","ccode","ifs","ifscode","gwabbrev"), all = TRUE)
ODC <- merge(ODC, ODC_theftcars, by=c("country","gwno","year","ccode","ifs","ifscode","gwabbrev"), all = TRUE)

# combine raw country names into one variable
rawnames <- ODC[, grep("countryname_raw", names(ODC))] # extract rawname vars
names(rawnames) <- as.character(1:ncol(rawnames)) # change names so there are no duplicate names

ODC[, grep("countryname_raw", names(ODC))] <- NULL # remove old countryname_raw variables
ODC$countryname_raw <- coalesce(!!! rawnames) # create new variables

# Append suffix ODC to variables
ODC = append_suffix(ODC,"ODC")

##################
# Save the Data
##################
save(ODC,file=paste(preppeddata,"PREPPED_ODC_AL_2015.RDATA",sep=""))
