###############################
# Political Terror Scale [PTS]
# Suffix: PTS
#
# Version: Octobert 2021
# Accessed: March 26, 2022
#
# Last updated by: Robert Huang
# Updated by: Anna Lipscomb
# Prepped By: Rohit Madan
# Last update: March 26, 2022
#
# Data: http://www.politicalterrorscale.org/Data/Download.html
# 
# Year Range: 1976-2020
#
# Variables: 
# politterr_a: Political Terror Scale based on Amnesty International
# politterr_HRW: Political Terror Scale based on HRW
# politterr_s: Political Terror Scale based on the US State Department
###############################

# clear everything
rm(list=ls())

# load packages
library(Hmisc)
library(tidyverse)

# set filepaths 
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/prepped/"
prepscripts <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/scripts/"
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/"


# Read raw data 
pts <- read.csv(paste(rawdata, "RAWDATA_PTS_2020.csv", sep=""), skip = 0)

# Keep and rename needed variables
pts2 <- pts %>%
  select("Country", "Year", "politterr_a"="PTS_A", 
         "politterr_HRW"="PTS_H", "politterr_s"="PTS_S")

# append IDs
source(paste0(ids_path, "append_ids.R"))
pts3 <- append_ids(pts2, ids_path, dyad = F, breaks = F)

# duplicates: Czechoslovakia/Czech Republic, German Federal Republic, 
# Russia (Soviet Union), Yemen (Arab Republic of Yemen), Yugoslavia/Serbia

# drop duplicated rows based on the number of NAs
# We keep the rows with fewer NAs
pts4 <- pts3 %>%
  filter(!(year<1993 & countryname_raw=="Czech Republic")) %>%
  filter(!(year>=1993 & countryname_raw=="Czechoslovakia")) %>%
  filter(!(countryname_raw=="Yugoslavia, Federal Republic of" & country=="Serbia")) %>%
  filter(!(countryname_raw=="Serbia" & country=="Yugoslavia")) %>%
  filter(!(year<1990 & countryname_raw=="Germany")) %>%
  filter(!(year>=1990 & countryname_raw=="German Federal Republic")) %>%
  filter(!(year<1992 & countryname_raw=="Russian Federation")) %>%
  filter(!(year>=1992 & countryname_raw=="Soviet Union")) %>%
  filter(!(year<1990 & countryname_raw=="Yemen")) %>%
  filter(!(year>=1990 & countryname_raw=="Yemen Arab Republic"))
  
  
# Check Duplicates
n_occur <- data.frame(table(pts4$country, pts4$year))
print(n_occur[n_occur$Freq > 1,])
# no duplicates now

# append suffix
pts4 <- append_suffix(pts4, "PTS")


# Add label
label(pts4$politterr_a_PTS) <- "Political Terror Scale based on Amnesty International [PTS]" 
label(pts4$politterr_HRW_PTS) <- "Political Terror Scale based on HRW [PTS]" 
label(pts4$politterr_s_PTS) <- "Political Terror Scale based on the US State Department [PTS]" 

# save prepped data
saveRDS(pts4,file=paste(preppeddata,"PREPPED_PTS_RH_03262022.RDS",sep=""))
