#/**************************
# Data: Penn World Table version 10.0
# Dataset: Penn World Table version 10.0
# Data source url: http://www.rug.nl/ggdc/productivity/pwt/
# Time: 1950-2019
# Updated: MAY 2020 by MB
# Last updated: Dec 3, 2021 by Robert Huang
# Suffix: PW  
# 
# Citation:
#  Feenstra, Robert C., Robert Inklaar, and Marcel P. Timmer. 2015. 
#  “The Next Generation of the Penn World Table.” American Economic Review 105(10): 3150–3182. 
#  Available for download at www.ggdc.net/pwt.
# #****************************/

# clear everything
rm(list=ls())

# load packages
library(Hmisc)
library(tidyverse)
library(readxl)

# set filepaths 
rawdata <- "GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/"
preppeddata <- "GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/preppeddatav5.0/"
prepscripts <- "GoogleDrive/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/prep scripts v5.0/"
ids_path <- "GoogleDrive/My Drive/append_ids/"

# load dataset
pw <- read_xlsx(paste(rawdata,"RAWDATA_PW_2019.xlsx",sep=""),sheet = 3)

# Keep variables we are interestd 
pw <- pw %>%
  select(country, currency_unit, year, rgdpe, rgdpo, pop, emp,
         hc, cgdpe, cgdpo, ck, ctfp, rgdpna, rkna, 
         rtfpna,rwtfpna, labsh, xr, statcap)


# Number of unique countries and observations
length(unique(pw$country)) #183
length(pw$country) #12810


# Append country IDs
source(paste0(ids_path, "append_ids.R"))
pw2 <- append_ids(pw, ids_path, dyad = F, breaks = F)

# Number of countries and observations after cleaning
length(unique(pw2$country)) #176
length(pw2$country) #12069

# Add variable labels
label(pw2$currency_unit) <- "Currency Unit [PW]"
label(pw2$rgdpe) <- "Expenditure-side real GDP at chained PPPs (in mil. 2017US$) [PW]"
label(pw2$rgdpo) <- "Output-side real GDP at chained PPPs (in mil. 2017US$) [PW]"
label(pw2$pop) <- "Population (in millions) [PW]"
label(pw2$emp) <- "Number of persons engaged (in millions) [PW]"
label(pw2$hc) <- "Average annual hours worked by persons engaged [PW]"
label(pw2$cgdpe) <- "Expenditure-side real GDP at current PPPs (in mil. 2017US$) [PW]"
label(pw2$cgdpo) <- "Output-side real GDP at current PPPs (in mil. 2017US$) [PW]"
label(pw2$ck) <- "Capital stock at current PPPs (in mil. 2017US$) [PW]"
label(pw2$ctfp) <- "TFP level at current PPPs (USA=1) [PW]"
label(pw2$rgdpna) <- "Real GDP at constant 2017 national prices (in mil. 2017US$) [PW]"
label(pw2$rkna) <- "Capital stock at constant 2017 national prices (in mil. 2017US$) [PW]"
label(pw2$rtfpna) <- "TFP at constant national prices (2017=1) [PW]"
label(pw2$rwtfpna) <- "Welfare-relevant TFP at constant national prices (2017=1) [PW]"
label(pw2$labsh) <- "Share of labor compensation in GDP at current national prices [PW]"
label(pw2$xr) <- "Exchange rate, national currency/USD (market+estimated) [PW]"
label(pw2$statcap) <- "Statistical capacity indicator (source: World Bank, developing countries only) [PW]"

# Append suffix
pw2 <- append_suffix(pw2,"PW")

# save data
save(pw2,file=paste(preppeddata,"PREPPED_PW_RH_12032021.RDATA",sep=""))
