###############################
# SGI Quality of Governance Indicators
# Version: 2020
# Accessed: March 12, 2022
# Year Range: 2014-2020
# Last updated by: Robert Huang
# Updated by: BZ
# Prepped By: Sarah Lu
# Suffix: SGI
# Last update: Mar 12, 2022
#
# Data: http://www.sgi-network.org/2016/Downloads
# Codebook: https://www.sgi-network.org/docs/2020/basics/SGI2020_Codebook.pdf
#   
# Citation: Bertelsmann Stiftung. 2016. Sustainable Governance Indicators 
# 2016. http://www.sgi-network.org/2016/Downloads. Accessed on April 04, 2017.
#
# Variables: 
# corrupprev_SGI: Rule of Law: Corruption Prevention [SGI]
###############################

# clear everything
rm(list=ls())

# load packages
library(Hmisc)
library(tidyverse)
library(readxl)

# set filepaths 
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/prepped/"
prepscripts <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/scripts/"
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/"


# read previous prepped data from 2014 to 2018
load(paste(rawdata,"PREPPED_SGI_BZ_03022019.RDATA", sep=""))

# Read raw data 2019
sgi19 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2020.xlsx", sep="")), sheet = "SGI 2019 Scores", skip = 0)
# Read raw data 2020
sgi20 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2020.xlsx", sep="")), sheet = "SGI 2020 Scores", skip = 0)


# rename columns and keep the corruption prevention variable
# add year variable
# rename corruption variable
colnames(sgi19)[1] <- "country"
colnames(sgi20)[1] <- "country"

sgi19_2 <- sgi19 %>%
  select("country","corrupprev"="Corruption Prevention") %>%
  mutate(year=2019)

sgi20_2 <- sgi20 %>%
  select("country","corrupprev"="Corruption Prevention") %>%
  mutate(year=2020)


# Merge 2019 and 2020 data
sgi2 <- rbind(sgi19_2, sgi20_2)


# append IDs
source(paste0(ids_path, "append_ids.R"))
sgi3 <- append_ids(sgi2, ids_path, dyad = F, breaks = F)

# Append Suffix
sgi3 <- append_suffix(sgi3, "SGI")

# merge with previous data from 2014 to 2018
sgi4 <- rbind(sgi,sgi3)

# rearrange the new dataset
sgi4 <- arrange(sgi4,ccode,year)


#save prepped data
saveRDS(sgi4,file=paste(preppeddata,"PREPPED_SGI_RH_03122022.RDS",sep=""))

