###############################
# UCDP Battle Deaths Dataset [UBD]
# Version: 2017
# Accessed: September 2018
# Year Range: 1989-2017
# Prepped By: Alicia Kuang
# Suffix: UBD
# Last update: 09/21/2018
# Edited: MB 05/06/2020
# Edited: GM 06/06/2022
#
# Data: http://ucdp.uu.se/downloads/brd/ucdp-brd-conf-181.xlsx
# Codebook: http://ucdp.uu.se/downloads/brd/ucdp-brd-181.pdf
# 
#
# Variables: BdLow_UBD, BdHigh_UBD, BdBest_UBD, Label: "Low estimate of annual battle fatalities [UBD]"
# "High estimate of annual batttle fatalities [UBD]", "Best estimate of annual battle fatalities [UBD]"
#
#
###############################

library(Hmisc)
library(dplyr)
library(readxl)
library(countrycode)

#check to make sure the dataset does not match the old datasets in raw-data v4

#ubd <-  read.csv(paste(rawdata,"RAWDATA_UBD_2018.csv", sep = ""), stringsAsFactors = F)
ubd <- read_csv(paste0(rawdata, "RAWDATA_UBD_GM_2020.csv"))

#keeping only variables we need and renaming variables
names(ubd)[names(ubd)=="battle_location"] <- "Country"
ubd <-ubd[,c("Country", "year","bd_low", "bd_high", "bd_best", "dyad_id")]

# don't want to overcount deaths, so pick which country to attribute death numbers to
# rawdata_ubd_splits.RDATA" contains info on attribution from previous versions
# if prepping an updated version, there may be new conflicts needing attribution
#load(paste(rawdata, "rawdata_ubd_splits.RDATA", sep=""))

# updated splits june 2020
ubd_splits2 <- read_excel(paste(rawdata,"UBD_check_conflicts_AR_6.18.2020.xlsx", sep = "")) %>%
  select(Country, Year = year, BattleLocation = Location, new_id = dyad_id) %>%
  bind_rows(ubd_splits)

#ubd_splits$approx <- ubd_splits$BdBest %/% 100
#ubd$approx <- ubd$bdbest %/% 100



ubd <- left_join(ubd, ubd_splits2, by = c("year" = "Year", "dyad_id" = "new_id")) #%>%
  #filter((BdBest >= bdlow & BdBest <= bdhigh) | is.na(BdBest))
#test$keep <- (test$BdBest >= test$bdlow & test$BdBest <= test$bdhigh) | is.na(test$BdBest)
############
#ubd$Country <- ifelse(is.na(ubd$BattleLocation), ubd$Country.x, 
                      # ifelse(ubd$Country.x != ubd$BattleLocation, ubd$BattleLocation, ubd$Country.x))
ubd$Country <- ifelse(is.na(ubd$BattleLocation), ubd$Country.x, ubd$BattleLocation)
#ubd$BattleLocation <- NULL

# # ubd$year[ubd$Country == "The following countries were not given gwno codes: "
# View(ubd[ubd$Country == "Afghanistan, France, Iraq, Pakistan, Syria, Yemen (North Yemen)",])
# View(ubd[ubd$Country == "Afghanistan, India",])
# View(ubd[ubd$Country == "Afghanistan, Pakistan",]) ###
# View(ubd[ubd$Country == "Afghanistan, Pakistan, Syria",])
# View(ubd[ubd$Country == "Armenia, Azerbaijan",])
# View(ubd[ubd$Country == "Belgium, Iraq, Libya, Syria",])
# View(ubd[ubd$Country == "Cameroon, Nigeria",])
# View(ubd[ubd$Country == "Ethiopia, Kenya",])
# View(ubd[ubd$Country == "France, Iraq, Libya, Syria",])
# View(ubd[ubd$Country == "Georgia, Russia (Soviet Union)",])
# View(ubd[ubd$Country == "India, Pakistan",])
# View(ubd[ubd$Country == "Iran, Iraq",])
# View(ubd[ubd$Country == "Iraq, Syria, Turkey",])
# View(ubd[ubd$Country == "Iraq, Turkey",])
# View(ubd[ubd$Country == "Jordan, Syria",])
# View(ubd[ubd$Country == "Kenya, Somalia",])
# View(ubd[ubd$Country == "Lebanon, Syria",])
# View(ubd[ubd$Country == "Macedonia, FYR, Serbia (Yugoslavia)",])
# View(ubd[ubd$Country == "Malaysia, Philippines",])
# View(ubd[ubd$Country == "Saudi Arabia, Yemen (North Yemen)",])
# View(ubd[ubd$Country == "South Sudan, Uganda",])
# View(ubd[ubd$Country == "Syria, Turkey",])
# 
# ubd$year[ubd$Country == "Afghanistan, France, Iraq, Pakistan, Syria, Yemen (North Yemen)"]
# ubd$year[ubd$Country == "Afghanistan, India"]
# ubd$year[ubd$Country == "Afghanistan, Pakistan"]
# ubd$year[ubd$Country == "Afghanistan, Pakistan, Syria"]
# ubd$year[ubd$Country == "Afghanistan, Pakistan, Turkey"]
# ubd$year[ubd$Country == "Armenia, Azerbaijan"]
# ubd$year[ubd$Country == "Australia, Belgium, France, Iraq, Syria"]
# ubd$year[ubd$Country == "Belgium, Iraq, Libya"]
# ubd$year[ubd$Country == "Bosnia-Herzegovina, Croatia"]
# ubd$year[ubd$Country == "Bosnia-Herzegovina, Croatia, Serbia (Yugoslavia)"]
# ubd$year[ubd$Country == "Burundi, DR Congo (Zaire)"]
# ubd$year[ubd$Country == "Cambodia (Kampuchea), Thailand"]
# ubd$year[ubd$Country == "Cameroon, Nigeria"]
# ubd$year[ubd$Country == "Central African Republic, DR Congo (Zaire)"]
# ubd$year[ubd$Country == "Central African Republic, DR Congo (Zaire), South Sudan, Sudan"]
# ubd$year[ubd$Country == "Central African Republic, DR Congo (Zaire), Sudan"]
# ubd$year[ubd$Country == "Chad, Sudan"]
# ubd$year[ubd$Country == "Colombia, Ecuador"]
# ubd$year[ubd$Country == "Congo, DR Congo (Zaire)"]
# ubd$year[ubd$Country == "Djibouti, Somalia"]
# ubd$year[ubd$Country == "DR Congo (Zaire), Rwanda"]
# ubd$year[ubd$Country == "DR Congo (Zaire), Uganda"]
# ubd$year[ubd$Country == "Ethiopia, Kenya"]
# ubd$year[ubd$Country == "Ethiopia, Somalia"]
# ubd$year[ubd$Country == "Ethiopia, Sudan"]
# ubd$year[ubd$Country == "France, Iraq, Libya, Syria"]
# ubd$year[ubd$Country == "Georgia, Russia (Soviet Union)"]
# ubd$year[ubd$Country == "India, Pakistan"]
# ubd$year[ubd$Country == "Iran, Iraq"]
# ubd$year[ubd$Country == "Iran, Iraq, Turkey"]
# ubd$year[ubd$Country == "Iran, Pakistan"]
# ubd$year[ubd$Country == "Iraq, Syria, Turkey"]
# ubd$year[ubd$Country == "Iraq, Turkey"]
# ubd$year[ubd$Country == "Israel, Lebanon"]
# ubd$year[ubd$Country == "Israel, Syria"]
# ubd$year[ubd$Country == "Ivory Coast, Liberia"]
# ubd$year[ubd$Country == "Jordan, Syria"]
# ubd$year[ubd$Country == "Kenya, Somalia"]
# ubd$year[ubd$Country == "Lebanon, Syria"]
# ubd$year[ubd$Country == "Macedonia, FYR, Serbia (Yugoslavia)"]
# ubd$year[ubd$Country == "Malaysia, Philippines"]
# ubd$year[ubd$Country == "Mali, Niger"]
# ubd$year[ubd$Country == "Myanmar (Burma), Thailand"]
# ubd$year[ubd$Country == "Saudi Arabia, Yemen (North Yemen)"]
# ubd$year[ubd$Country == "South Sudan, Sudan"]
# ubd$year[ubd$Country == "South Sudan, Uganda"]
# ubd$year[ubd$Country == "Sudan, Uganda"]
# ubd$year[ubd$Country == "Syria, Turkey"]

# check <- ubd[grep(",",ubd$Country),c(13,2:6)]
# write.csv(check, file = "UBD_check_conflicts.csv")

# summing countries that had multiple conflict deaths in the same year to get a total for the country that year
ubd <- ubd[,c("Country", "year", "bd_low", "bd_high", "bd_best")]
ubd <- ubd %>% group_by(Country, year) %>% summarise_all(sum)

#labels
label(ubd$bd_low) = "Low estimate of annual battle fatalities [UBD]"
label(ubd$bd_high) = "High estimate of annual battle fatalities [UBD]"
label(ubd$bd_best) = "Best estimate of annual battle fatalities [UBD]"

# merge with panel, fill in zeros
raw <- countrycode::codelist_panel %>%
  dplyr::select(country.name.en, year, gwn) %>%
  filter(!is.na(gwn)) %>%
  filter(year > 1988 & year < 2021)
  
ubd <-  append_ids(ubd, breaks = F) %>%
  dplyr::select(gwno, year, bd_low, bd_best, bd_high) %>%
  full_join(raw, by = c("gwno" = "gwn", "year")) %>%
  mutate(bd_best = replace(bd_best, is.na(bd_best), 0),
         bd_low = replace(bd_low, is.na(bd_low), 0),
         bd_high = replace(bd_high, is.na(bd_high), 0)) %>%
  arrange(gwno, year)

#append IDs and suffixes
names(ubd)[names(ubd) == "country.name.en"] <- "country"
ubd <-  append_ids(ubd, breaks = F)
ubd = append_suffix(ubd, "UBD")

# duplicates
ubd <- filter(ubd, 
              !(countryname_raw_UBD == "Serbia" & year < 2007) &
                !(countryname_raw_UBD == "Yugoslavia" & year > 2006))

#save
saveRDS(ubd, file = paste(preppeddata, "PREPPED_UBD_2022_MB_GM.RDS"))
