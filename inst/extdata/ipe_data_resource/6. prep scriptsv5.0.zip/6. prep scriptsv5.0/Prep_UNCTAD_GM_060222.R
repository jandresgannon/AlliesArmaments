###############################
#   UNCTAD FDI Data
# Accessed: June 2022
# URL: http://unctadstat.unctad.org/
# Years: 1970-2017
#   Citation:
#   United Nations Conference on Trade and Development. 2022 Foreign direct investment: Inward and outward flowas and stock, annual, 1980-2016. http://unctadstat.unctad.org/. Accessed on February 28, 2017.
# Gaea Morales 
###############################

library(tidyverse)

rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/SPRING 2022/prepped/"

ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste0(ids_path, "append_ids.R"))

names(unctad)

unctad <- read_csv(paste0(rawdata, "RAWDATA_UNCTAD_GM_2021.csv")) %>% 
  filter(`Direction Label` == "Inward") %>% 
  select("year" = Year, "country" = "Economy Label", "Mode Label", "US dollars at current prices in millions") %>% 
  pivot_wider(names_from = `Mode Label`, values_from = "US dollars at current prices in millions") %>% 
  select(year, country, "fdiflows_UNCTAD" = "Flow",
         "fdistocks_UNCTAD" = "Stock") %>% 
  group_by(country, year) %>% 
  distinct() %>% 
  append_ids(breaks = F)

#Check for Duplicates
n_occur <- data.frame(table(unctad$country, unctad$year))
print(n_occur[n_occur$Freq > 1,])


saveRDS(unctad, paste0(preppeddata, "PREPPED_UNCTAD_GM_060222.RDS"))
