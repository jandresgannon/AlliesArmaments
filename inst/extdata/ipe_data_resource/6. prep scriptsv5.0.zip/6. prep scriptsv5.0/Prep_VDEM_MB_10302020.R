# /***************************
# Varieties of Democracy
# Version 10 (March 2020)
# 
# URL: https://www.v-dem.net/en/data/data/v-dem-dataset/
# 
# Citations:
# Coppedge, Michael, John Gerring, Carl Henrik Knutsen, Staffan I. Lindberg, Jan Teorell, David Altman, Michael Bernhard, 
# M. Steven Fish, Adam Glynn, Allen Hicken, Anna Luhrmann, Kyle L. Marquardt, Kelly McMann, Pamela Paxton, Daniel Pemstein, 
# Brigitte Seim, Rachel Sigman, Svend-Erik Skaaning, Jeffrey Staton, Steven Wilson, Agnes Cornell, Nazifa Alizada, 
# Lisa Gastaldi, Haakon Gjerløw, Garry Hindle, Nina Ilchenko, Laura Maxwell, Valeriya Mechkova, Juraj Medzihorsky, 
# Johannes von Römer, Aksel Sundström, Eitan Tzelgov, Yi-ting Wang, Tore Wig, and Daniel Ziblatt. 2020. 
# "V-Dem [Country–Year/Country–Date] Dataset v10”. Varieties of Democracy (V-Dem) Project. https://doi.org/10.23696/vdemds20.
# and:
# Pemstein, Daniel, Kyle L. Marquardt, Eitan Tzelgov, Yi-ting Wang, Juraj Medzihorsky, Joshua Krusell, Farhad Miri, 
# and Johannes von Römer. 2020. “The V-Dem Measurement Model: Latent Variable Analysis for Cross-National and 
# Cross-Temporal Expert-Coded Data”. V-Dem Working Paper No. 21. 5th edition. University of Gothenburg: Varieties of Democracy Institute.
# 
# Time Period: 1789-2019
# Coded by: Grace Xu
# Revised by: Suzie Mulesky (5/7/2018)
# Revised by: Anna Lipscomb (Feb 2019)
# Revised by: John Kang (Nov 2019)
# Revised by: Miriam Barnum (Oct 2020)
# ****************************/

#library(devtools)
#install_github("vdeminstitute/vdemdata")
library(vdemdata)

variables = c( "country_name","year","v2x_polyarchy", 
               "v2x_api", 
               "v2x_mpi",
               "v2x_EDcomp_thick",
               "v2x_libdem",
               "v2x_liberal",
               "v2x_partipdem",
               "v2x_partip",
               "v2x_delibdem",
               "v2xdl_delib",
               "v2x_egaldem",
               "v2x_egal",
               "v2x_frassoc_thick",
               "v2x_freexp",
               "v2x_freexp_altinf",
               "v2xme_altinf",
               "v2x_suffr",
               "v2xel_frefair",
               "v2x_elecoff",
               "v2xcl_rol",
               "v2x_jucon",
               "v2xlg_legcon",
               "v2x_cspart",
               "v2xdd_dd",
               "v2xel_locelec",
               "v2xel_regelec",
               "v2xeg_eqprotec",
               "v2xeg_eqdr",
               "v2xcs_ccsi",
               "v2xps_party",
               "v2x_gender",
               "v2x_gencl",
               "v2x_gencs",
               "v2x_genpp",
               "v2x_elecreg",
               "v2xex_elecreg",
               "v2xlg_elecreg",
               "v2xel_elecparl",
               "v2xlg_leginter",
               "v2xel_elecpres",
               "v2x_hosinter",
               "v2x_corr",
               "v2x_pubcorr",
               "v2x_execorr",
               "v2x_divparctrl",
               "v2x_feduni",
               "v2x_civlib",
               "v2x_clphy",
               "v2x_clpol",
               "v2x_clpriv",
               "v2elsrgel",
               "v2elreggov",
               "v2cltrnslw",
               "v2juhcind",
               "v2juhccomp",
               "v2jureview",
               "v2excrptps",
               "v2jucorrdc",
               "v2exbribe",
               "v2lgcrrpt"
               
)

vDem = vdem[variables]

library(plyr)
vDem = plyr::rename(vDem, c("country_name" = "country"))

# check for duplicates
n_occur <- data.frame(table(vDem$country, vDem$year))
n_occur[n_occur$Freq>1,]

# append IDs
vDem = append_ids(vDem, breaks = FALSE)
vDem = append_suffix(vDem, "VDEM")

# check for duplicates
n_occur <- data.frame(table(vDem$gwno, vDem$year))
n_occur[n_occur$Freq>1,]

# how many countries? what time period?
length(unique(vDem$gwno)) # 195
range(vDem$year) # 1789-2019

# label variables
library(Hmisc)
label(vDem$v2x_polyarchy_VDEM) =	"Electoral democracy index [VDEM]"
label(vDem$v2x_api_VDEM)	= "Additive polyarchy index [VDEM]"
label(vDem$v2x_mpi_VDEM) = "Multiplicative polyarchy index [VDEM]"
label(vDem$v2x_EDcomp_thick_VDEM) =	"Electoral component index [VDEM]"
label(vDem$v2x_libdem_VDEM) =	"Liberal democracy index [VDEM]"
label(vDem$v2x_liberal_VDEM) =	"Liberal component index [VDEM]"
label(vDem$v2x_partipdem_VDEM) =	"Participatory democracy index [VDEM]"
label(vDem$v2x_partip_VDEM) =	"Participatory component index [VDEM]"
label(vDem$v2x_delibdem_VDEM) =	"Deliberative democracy index [VDEM]"
label(vDem$v2xdl_delib_VDEM) =	"Deliberative component index [VDEM]"
label(vDem$v2x_egaldem_VDEM) =	"Egalitarian democracy index [VDEM]"
label(vDem$v2x_egal_VDEM) =	"Egalitarian component index [VDEM]"
label(vDem$v2x_frassoc_thick_VDEM) =	"Freedom of association (thick) index [VDEM]"
label(vDem$v2x_freexp_altinf_VDEM) =	"Expanded freedom of expression index [VDEM]"
label(vDem$v2x_freexp_VDEM) =	"Freedom of expression index [VDEM]"
label(vDem$v2xme_altinf_VDEM)	= "Alternative sources of information index [VDEM]"
label(vDem$v2x_suffr_VDEM) =	"Share of population with suffrage [VDEM]"
label(vDem$v2xel_frefair_VDEM) =	"Clean elections index [VDEM]"
label(vDem$v2x_elecoff_VDEM) =	"Elected executive index [VDEM]"
label(vDem$v2xcl_rol_VDEM) =	"Equality before the law and individual liberty index [VDEM]"
label(vDem$v2x_jucon_VDEM) =	"Judicial constraints on the executive index [VDEM]"
label(vDem$v2xlg_legcon_VDEM) =	"Legislative constraints on the executive index [VDEM]"
label(vDem$v2x_cspart_VDEM) = "Civil society participation index [VDEM]"
label(vDem$v2xdd_dd_VDEM) =	"Direct popular vote index [VDEM]"
label(vDem$v2xel_locelec_VDEM) =	"Local government index [VDEM]"
label(vDem$v2xel_regelec_VDEM)	= "Regional government index [VDEM]"
label(vDem$v2xeg_eqprotec_VDEM) =	"Equal protection index [VDEM]"
label(vDem$v2xeg_eqdr_VDEM) = "Equal distribution of resources index [VDEM]"
label(vDem$v2xcs_ccsi_VDEM) =	"Core civil society index [VDEM]"
label(vDem$v2xps_party_VDEM) =	"Party system institutionalization index [VDEM]"
label(vDem$v2x_gender_VDEM) =	"Women political empowerment index [VDEM]"
label(vDem$v2x_gencl_VDEM) =	"Women civil liberties index [VDEM]"
label(vDem$v2x_gencs_VDEM) =	"Women civil society participation index [VDEM]"
label(vDem$v2x_genpp_VDEM) =	"Women political participation index [VDEM]"
label(vDem$v2x_elecreg_VDEM) =	"Electoral regime index [VDEM]"
label(vDem$v2xex_elecreg_VDEM)	= "Executive electoral regime index [VDEM]"
label(vDem$v2xlg_elecreg_VDEM) =	"Legislative electoral regime index [VDEM]"
label(vDem$v2xel_elecparl_VDEM) =	"Legislative or constituent assembly election [VDEM]"
label(vDem$v2xlg_leginter_VDEM) =	"Legislature closed down or aborted [VDEM]"
label(vDem$v2xel_elecpres_VDEM) =	"Presidential election [VDEM]"
label(vDem$v2x_hosinter_VDEM) = "Chief executive no longer elected [VDEM]"
label(vDem$v2x_corr_VDEM) = "Political corruption [VDEM]"
label(vDem$v2x_pubcorr_VDEM) = "Public sector corruption index [VDEM]"
label(vDem$v2x_execorr_VDEM) = "Executive corruption index [VDEM]"
label(vDem$v2x_divparctrl_VDEM) =	"Divided party control of legislature [VDEM]"
label(vDem$v2x_feduni_VDEM) =	"Division of power index [VDEM]"
label(vDem$v2x_civlib_VDEM) =	"Civil liberties index [VDEM]"
label(vDem$v2x_clphy_VDEM) =	"Physical violence index [VDEM]"
label(vDem$v2x_clpol_VDEM) =	"Political liberties index [VDEM]"
label(vDem$v2x_clpriv_VDEM) =	"Private liberties index [VDEM]"
label(vDem$v2elsrgel_VDEM) =	"Regional Government Elected [VDEM]"
label(vDem$v2elreggov_VDEM) =	"Regional Government Exists [VDEM]"
label(vDem$v2cltrnslw_VDEM) =	"Transparent laws with predictable enforcement [VDEM]"
label(vDem$v2juhcind_VDEM) =	"High court independence [VDEM]"
label(vDem$v2juhccomp_VDEM) =	"Government compliance with high court [VDEM]"
label(vDem$v2jureview_VDEM) =	"Judicial review [VDEM]"

# Save
save(vDem, file = paste(preppeddata,"prepped_VDEM_2020_MB.RDATA", sep=""))

