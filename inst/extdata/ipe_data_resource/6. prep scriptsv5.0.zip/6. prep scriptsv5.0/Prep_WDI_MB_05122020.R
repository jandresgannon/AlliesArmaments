# /*************************
#   World Development Indicators from the World Bank Data
# 
# Source: The World Bank. World Development Indicators 2015.
#
# URL: http://data.worldbank.org/data-catalog/world-development-indicators/wdi-2015. 
#
# Updated: MB, May 2020
# 
# Variables:
# - Surface area (sq. km)
# - Land area (sq. km)
# - Armed forces personnel
# - Battle-related deaths (number of people)
# - Central government debt (% of GDP)
# - Agricultural raw materials exports (% of merchandise exports)
# - Food exports (% of merchandise exports)
# - Fuel exports (% of merchandise exports)
# - Manufactures exports (% of merchandise exports)
# - Ores and metal exports (% of merchandise exports)
# - Exports of goods and services (% of GDP)
# - External debt stocks (% of GNI)   
# - Average interest on new external debt commitments (%) 
# - Average interest on new external debt commitments, official (%) 
# - Average interest on new external debt commitments, private (%)   
# - Interest payments on external debt (% of GNI)
# - Interest payments on external debt (% exports and primary income)
# - Present value of external debt (current US$)   
# - External debt stocks, total (DOD, current US$)    
# - Foreign direct investment, net inflows (BoP, current US$) 
# - Foreign direct investment, net inflows (% of GDP) 
# - Foreign direct investment, net outflows (% of GDP)   
# - GDP (constant 2005 US$)     
# - GDP growth (annual %)      
# - GDP per capita (constant 2005 US$)    
# - GINI index         
# - GNI (constant 2005 US$)      
# - GNI per capita (constant 2005 US$)     
# - Mortality rate, infant (per 1000 live births)   
# - Inflation, consumer prices (annual %)      
# - Insurance and financial services (% of commercial service exports)  
# - Fixed broadband Internet subscribers (per 100 people) 
# - Scientific and technical journal articles      
# - Strength of legal rights index (0=weak to 12=strong)  
# - Lending interest rate (%)    
# - Life expectancy at birth, total (years)    
# - Literacy rate, adult total (% of people ages 15 and above)
# - International migrant stock (% of population)    
# - International migrant stock, total      
# - Mobile cellular subscriptions (per 100 people)     
# - Patent applications, residents      
# - Population, total       
# - Population density (ppl per sq km of land area)  
# - Urban population (% of total)     
# - Population ages 15-64 (% of total)
# - Power outages in firms in a typical month (number) 
# - Portfolio equity, net inflows (BoP, current US$)    
# - Real effective exchange rate index (2010 = 100)  
# - Personal remittances, received (% of GDP)
# - Total reserves in months of imports  
# - Total reserves (includes gold, current US$)     
# - Real interest rate (%)     
# - Risk premium on lending (lending rate minus treasury bill rate, %)
# - Tax revenue (% of GDP)    
# - Technicians in R&D (per million people)    
# - Telephone lines (per 100 people)      
# - Trade (% of GDP)       
# - Trade in services (% of GDP)
# - Trademark applications, total       
# - Total natural resources rents (% of GDP)
# - General government final consumption expenditure (% of GDP) 
# - GNI per capita growth (annual %)
# - Gross fixed capital formation (% of GDP)
# - Gross capital formation (constant 2005 US$)
# - Government expenditure on education, total (% of GDP)
# - Government expenditure on education, total (% of government expenditure)
# - Net official development assistance received (current US$)
# - Population ages 0-14 (% of total)
# *************************/

library(tidyr)
library(dplyr)
library(Hmisc)

wdi = read.csv(paste(rawdata, "RAWDATA_WB_WDI_2019.csv", sep=""))

names(wdi)[1] <- "country"

# Keep only the variables we need
wdi = wdi[, c("country", "Indicator.Name", "X1960", "X1961", "X1962", "X1963", "X1964", "X1965", 
            "X1966", "X1967", "X1968", "X1969", "X1970", "X1971", "X1972", "X1973", "X1974", "X1975",
            "X1976", "X1977", "X1978", "X1979", "X1980", "X1981", "X1982", "X1983", "X1984", "X1985", 
            "X1986", "X1987", "X1988", "X1989", "X1990", "X1991", "X1992", "X1993", "X1994", "X1995",
            "X1996", "X1997", "X1998", "X1999", "X2000", "X2001", "X2002", "X2003", "X2004", "X2005", 
            "X2006", "X2007", "X2008", "X2009", "X2010", "X2011", "X2012", "X2013", "X2014", "X2015",
            "X2016", "X2017", "X2018", "X2019")]

indicator.description <- c("Literacy rate, adult total (% of people ages 15 and above)", "Population density (people per sq. km of land area)", 
                           "Urban population (% of total population)", "Total natural resources rents (% of GDP)", 
                           "General government final consumption expenditure (% of GDP)", "GNI per capita growth (annual %)",
                           "Gross fixed capital formation (% of GDP)", "Foreign direct investment, net inflows (BoP, current US$)", 
                           "Foreign direct investment, net inflows (% of GDP)", "Foreign direct investment, net outflows (% of GDP)",
                           "Portfolio equity, net inflows (BoP, current US$)", "Total reserves in months of imports",
                           "Total reserves (includes gold, current US$)", "Inflation, consumer prices (annual %)",
                           "Real interest rate (%)", "Real effective exchange rate index (2010 = 100)", 
                           "Risk premium on lending (lending rate minus treasury bill rate, %)", "External debt stocks (% of GNI)", 
                           "External debt stocks, total (DOD, current US$)", "Present value of external debt (current US$)", 
                           "Exports of goods and services (% of GDP)", "GDP (constant 2010 US$)", 
                           "GDP per capita (constant 2010 US$)", "GDP growth (annual %)", "GNI (constant 2010 US$)", 
                           "Trade (% of GDP)", "Trade in services (% of GDP)", "Life expectancy at birth, total (years)", 
                           "Mortality rate, infant (per 1,000 live births)", "Fixed broadband subscriptions (per 100 people)", 
                           "Patent applications, residents", "Mobile cellular subscriptions (per 100 people)", 
                           "Scientific and technical journal articles", "Fixed telephone subscriptions (per 100 people)",
                           "Technicians in R&D (per million people)", "Trademark applications, total", 
                           "International migrant stock (% of population)", "International migrant stock, total",
                           "GINI index (World Bank estimate)", "Agricultural raw materials exports (% of merchandise exports)",
                           "Ores and metals exports (% of merchandise exports)", "Power outages in firms in a typical month (number)",
                           "Strength of legal rights index (0=weak to 12=strong)", "Manufactures exports (% of merchandise exports)", 
                           "Food exports (% of merchandise exports)", "Insurance and financial services (% of commercial service exports)",
                           "Armed forces personnel, total", "Battle-related deaths (number of people)", 
                           "Central government debt, total (% of GDP)",
                           "Tax revenue (% of GDP)", "Population, total", "Surface area (sq. km)", 
                           "GNI per capita (constant 2010 US$)", "Land area (sq. km)", 
                           "Fuel exports (% of merchandise exports)", "Average interest on new external debt commitments (%)", 
                           "Average interest on new external debt commitments, official (%)", "Average interest on new external debt commitments, private (%)",
                           "Interest payments on external debt (% of GNI)", "Interest payments on external debt (% of exports of goods, services and primary income)", 
                           "Lending interest rate (%)", "Personal remittances, received (% of GDP)",
                           "Population ages 15-64 (% of total population)", "Gross capital formation (constant 2010 US$)",
                           "Government expenditure on education, total (% of GDP)", "Government expenditure on education, total (% of government expenditure)",
                           "Net official development assistance received (current US$)", "Population ages 0-14 (% of total population)")

# Reshape
wdi <- wdi %>% filter(wdi$Indicator.Name %in% indicator.description) %>%
  pivot_longer(-c("country", "Indicator.Name"), names_to = "year") %>%
  pivot_wider(names_from = Indicator.Name, values_from = "value")

wdi$year <- as.numeric(substr(wdi$year, 2,5))

#labelling variables
varLabels = colnames(wdi)

# Rename variables
names(wdi)[names(wdi) == 'Armed forces personnel, total'] <- "armed"
names(wdi)[names(wdi) == 'Land area (sq. km)'] <- "area_land"
names(wdi)[names(wdi) == 'Surface area (sq. km)'] <- "area"
names(wdi)[names(wdi) == 'Battle-related deaths (number of people)'] <- "deaths_bt"
names(wdi)[names(wdi) == 'Central government debt, total (% of GDP)'] <- "debt_cgov"
names(wdi)[names(wdi) == 'Agricultural raw materials exports (% of merchandise exports)'] <- "ex_agri"
names(wdi)[names(wdi) == 'Food exports (% of merchandise exports)'] <- "ex_food"
names(wdi)[names(wdi) == 'Fuel exports (% of merchandise exports)'] <- "ex_fuel"
names(wdi)[names(wdi) == 'Manufactures exports (% of merchandise exports)'] <- "ex_mfg"
names(wdi)[names(wdi) == 'Ores and metals exports (% of merchandise exports)'] <- "ex_oresmet"
names(wdi)[names(wdi) == 'Exports of goods and services (% of GDP)'] <- "exp"
names(wdi)[names(wdi) == 'External debt stocks (% of GNI)'] <- "extdebt"
names(wdi)[names(wdi) == 'Average interest on new external debt commitments (%)'] <- "extdebt_avgint"
names(wdi)[names(wdi) == 'Average interest on new external debt commitments, official (%)'] <- "extdebt_avgintoff"
names(wdi)[names(wdi) == 'Average interest on new external debt commitments, private (%)'] <- "extdebt_avgintpriv"
names(wdi)[names(wdi) == 'Interest payments on external debt (% of GNI)'] <- "extdebt_intpaygni"
names(wdi)[names(wdi) == 'Interest payments on external debt (% of exports of goods, services and primary income)'] <- "extdebt_intpayperex"
names(wdi)[names(wdi) == 'Present value of external debt (current US$)'] <- "extdebt_pv"
names(wdi)[names(wdi) == 'External debt stocks, total (DOD, current US$)'] <- "extdebt_tot"
names(wdi)[names(wdi) == 'Foreign direct investment, net inflows (BoP, current US$)'] <- "fdidollars"
names(wdi)[names(wdi) == 'Foreign direct investment, net inflows (% of GDP)'] <- "fdi_inper"
names(wdi)[names(wdi) == 'Foreign direct investment, net outflows (% of GDP)'] <- "fdi_outper"
names(wdi)[names(wdi) == 'GDP (constant 2010 US$)'] <- "gdp"
names(wdi)[names(wdi) == 'GDP growth (annual %)'] <- "growth"
names(wdi)[names(wdi) == 'GDP per capita (constant 2010 US$)'] <- "gdppc"
names(wdi)[names(wdi) == 'GINI index (World Bank estimate)'] <- "gini"
names(wdi)[names(wdi) == 'GNI (constant 2010 US$)'] <- "gni"
names(wdi)[names(wdi) == 'GNI per capita (constant 2010 US$)'] <- "gnipc"
names(wdi)[names(wdi) == 'Mortality rate, infant (per 1,000 live births)'] <- "inf_mort"
names(wdi)[names(wdi) == 'Inflation, consumer prices (annual %)'] <- "inflation"
names(wdi)[names(wdi) == 'Insurance and financial services (% of commercial service exports)'] <- "insfin_svc"
names(wdi)[names(wdi) == 'Fixed broadband subscriptions (per 100 people)'] <- "internet_br"
names(wdi)[names(wdi) == 'Scientific and technical journal articles'] <- "journal"
names(wdi)[names(wdi) == 'Strength of legal rights index (0=weak to 12=strong)'] <- "legal_rt"
names(wdi)[names(wdi) == 'Lending interest rate (%)'] <- "lending_intrate"
names(wdi)[names(wdi) == 'Life expectancy at birth, total (years)'] <- "life_exp"
names(wdi)[names(wdi) == 'Literacy rate, adult total (% of people ages 15 and above)'] <- "lit"
names(wdi)[names(wdi) == 'International migrant stock (% of population)'] <- "migrant_per"
names(wdi)[names(wdi) == 'International migrant stock, total'] <- "migrant_tot"
names(wdi)[names(wdi) == 'Mobile cellular subscriptions (per 100 people)'] <- "mobile"
names(wdi)[names(wdi) == 'Patent applications, residents'] <- "patapps"
names(wdi)[names(wdi) == 'Population, total'] <- "pop"
names(wdi)[names(wdi) == 'Population density (people per sq. km of land area)'] <- "pop_den"
names(wdi)[names(wdi) == 'Urban population (% of total population)'] <- "pop_urb"
names(wdi)[names(wdi) == 'Population ages 15-64 (% of total population)'] <- "workingpop"
names(wdi)[names(wdi) == 'Power outages in firms in a typical month (number)'] <- "power_out"
names(wdi)[names(wdi) == 'Portfolio equity, net inflows (BoP, current US$)'] <- "portfolio"
names(wdi)[names(wdi) == 'Real effective exchange rate index (2010 = 100)'] <- "reer"
names(wdi)[names(wdi) == 'Personal remittances, received (% of GDP)'] <- "remittances"
names(wdi)[names(wdi) == 'Total reserves in months of imports'] <- "reserves_im"
names(wdi)[names(wdi) == 'Total reserves (includes gold, current US$)'] <- "reserves_tot"
names(wdi)[names(wdi) == 'Real interest rate (%)'] <- "rir"
names(wdi)[names(wdi) == 'Risk premium on lending (lending rate minus treasury bill rate, %)'] <- "risk_prem"
names(wdi)[names(wdi) == 'Cash surplus/deficit (% of GDP)'] <- "surdef"
names(wdi)[names(wdi) == 'Tax revenue (% of GDP)'] <- "tax_rev"
names(wdi)[names(wdi) == 'Technicians in R&D (per million people)'] <- "tech_rnd"
names(wdi)[names(wdi) == 'Fixed telephone subscriptions (per 100 people)'] <- "tele"
names(wdi)[names(wdi) == 'Trade (% of GDP)'] <- "trade"
names(wdi)[names(wdi) == 'Trade in services (% of GDP)'] <- "trade_services"
names(wdi)[names(wdi) == 'Trademark applications, total'] <- "trdmk_apps"
names(wdi)[names(wdi) == 'Total natural resources rents (% of GDP)'] <- "natresource_rents"
names(wdi)[names(wdi) == 'General government final consumption expenditure (% of GDP)'] <- "govt_consump"
names(wdi)[names(wdi) == 'GNI per capita growth (annual %)'] <- "GNI_growth"
names(wdi)[names(wdi) == 'Gross fixed capital formation (% of GDP)'] <- "capform"
names(wdi)[names(wdi) == 'Gross capital formation (constant 2010 US$)'] <- "capformraw"
names(wdi)[names(wdi) == 'Government expenditure on education, total (% of GDP)'] <- "govexp_edu"
names(wdi)[names(wdi) == "Government expenditure on education, total (% of government expenditure)"] <- "govexp_edu_pexp"
names(wdi)[names(wdi) == 'Net official development assistance received (current US$)'] <- "netoda"
names(wdi)[names(wdi) == 'Population ages 0-14 (% of total population)'] <- "pop0_14"

label(wdi$area) = "Surface area (sq.km) [WDI]"
label(wdi$area_land) = "Land area (sq.km) [WDI]"
label(wdi$armed) = "armed forces personnel, total [WDI]"
label(wdi$deaths_bt) = "Battle-related deaths(number of people) [WDI]"
label(wdi$debt_cgov) = "Central government debt. Total (% of GDP) [WDI]"
label(wdi$ex_agri) = " Agricultural raw materials exports (% of merchandise exports) [WDI]"
label(wdi$ex_food) = " Food exports (% of merchandise exports) [WDI]"
label(wdi$ex_fuel) = " Fuel exports (% of merchandise exports) [WDI]"
label(wdi$ex_mfg) = "Manufactures exports (% of merchandise exports) [WDI]"
label(wdi$ex_oresmet) = "Ores and metal exports (% of merchandise exports) [WDI]"
label(wdi$exp) = "Exports of goods and services (% of GDP) [WDI]"
label(wdi$extdebt) = "External debt stocks (% of GNI) [WDI]"
label(wdi$extdebt_avgint) = "Average interest on new external debt commitments (%) [WDI]"
label(wdi$extdebt_avgintoff) = "Average interest on new external debt commitments, official (%) [WDI]"
label(wdi$extdebt_avgintpriv) = "Average interest on new external debt commitments, private (%) [WDI]"
label(wdi$extdebt_intpaygni) = "Interest payments on external debt (% of GNI) [WDI]"
label(wdi$extdebt_intpayperex) = "Interest payments on external debt (% exports and primary income) [WDI]"
label(wdi$extdebt_pv) = "Present value of external debt (current US$) [WDI]"
label(wdi$extdebt_tot) = "External debt stocks, total (DOD, current US$) [WDI]"
label(wdi$fdidollars) = "Foreign direct investment, net inflows (BoP, current US$) [WDI]"
label(wdi$fdi_inper) = "Foreign direct investment, net inflows (% of GDP) [WDI]"
label(wdi$fdi_outper) = "Foreign direct investment, net outflows (% of GDP) [WDI]"
label(wdi$gdp) = "GDP (constant 2005 US$) [WDI]"
label(wdi$growth) = "GDP growth (annual %) [WDI]"
label(wdi$gdppc) = "GDP per capita (constant 2005 US$) [WDI]"
label(wdi$gini) = "GINI index [WDI]"
label(wdi$gni) = "GNI (constant 2005 US$) [WDI]"
label(wdi$gnipc) = "GNI per capita (constant 2005 US$) [WDI]"
label(wdi$inf_mort) = "Mortality rate, infant (per 1000 live births) [WDI]"
label(wdi$inflation) = "Inflation, consumer prices (annual%) [WDI]"
label(wdi$insfin_svc) = "Insurance and financial services (% of commercial service exports) [WDI]"
label(wdi$internet_br) = "Fixed broadband Internet subscribers (per 100 people) [WDI]"
label(wdi$journal) = "Scientific and technical journal articles [WDI]"
label(wdi$legal_rt) = "Strength of legal rights index (0=weak to 12=strong) [WDI]"
label(wdi$lending_intrate) = "Lending interest rate (%) [WDI]"
label(wdi$life_exp) = "Life expectancy at birth, total (years) [WDI]"
label(wdi$lit) = "Literacy rate, adult total (% of people ages 15 and above) [WDI]"
label(wdi$migrant_per) = "International migrant stock (% of population) [WDI]"
label(wdi$migrant_tot) = "International migrant stock, total [WDI]"
label(wdi$mobile) = "Mobile cellular subscriptions (per 100 people) [WDI]"
label(wdi$patapps) = "Patent applications, residents [WDI]"
label(wdi$pop) = "Population, total [WDI]"
label(wdi$pop_den) = "Population density (ppl per sq km of land area) [WDI]"
label(wdi$pop_urb) = "Urban population (% of total population) [WDI]"
label(wdi$workingpop) = "Population ages 15-64 (% of total)[WDI]"
label(wdi$power_out) = "Power outages in firms in a typical month (number) [WDI]"
label(wdi$portfolio) = "Portfolio equity, net inflows (BoP, current US$) [WDI]"
label(wdi$reer) = "Real effective exchange rate index (2010 = 100) [WDI]"
label(wdi$remittances) = "Personal remittances, received (% of GDP) [WDI]"
label(wdi$reserves_im) = "Total reserves in months of imports [WDI]"
label(wdi$reserves_tot) = "Total reserves (includes gold, current US$) [WDI]"
label(wdi$rir) = "Real interest rate (%) [WDI]"
label(wdi$risk_prem) = "Risk premium on lending (lending rate minus treasury bill rate, %) [WDI]"
label(wdi$tax_rev) = "Tax revenue (% of GDP) [WDI]"
label(wdi$tech_rnd) = "Technicians in R&D (per million people) [WDI]"
label(wdi$tele) = "Telephone lines (per 100 people) [WDI]"
label(wdi$trade) = "Trade (% of GDP) [WDI]"
label(wdi$trade_services) = "Trade in services (% of GDP) [WDI]"
label(wdi$trdmk_apps)= "Trademark applications, total [WDI]"
label(wdi$natresource_rents) = "Total natural resources rents (% of GDP) [WDI]"
label(wdi$govt_consump)= "General government final consumption expenditure (% of GDP) [WDI]"
label(wdi$GNI_growth)="GNI per capita growth (annual %) [WDI]"
label(wdi$capform)= "Gross fixed capital formation (% of GDP) [WDI]"
label(wdi$capformraw) ="Gross capital formation (constant 2010 US$) [WDI]"
label(wdi$govexp_edu) = "Government expenditure on education, total (% of GDP) [WDI]"
label(wdi$govexp_edu_pexp) = "Expenditure on education as % of total government expenditure (%) [WDI]"
label(wdi$netoda)= "Net official development assistance received (current US$) [WDI]"
label(wdi$pop0_14) = "Population ages 0-14 (% of total) [WDI]"

# Reorder columns
wdi <- wdi[ ,c(names(wdi)[1:2], sort(names(wdi)[3:65]))]

# Check duplicates
wdi <- wdi[!duplicated(wdi),]

# Append country IDs

wdi$country <- as.character(wdi$country)

wdi = append_ids(wdi, breaks = F)
wdi = append_suffix(wdi,"WDI")

#save
save(wdi,file=paste(preppeddata,"prepped_WDI_MB_2019.RDATA",sep=""))
