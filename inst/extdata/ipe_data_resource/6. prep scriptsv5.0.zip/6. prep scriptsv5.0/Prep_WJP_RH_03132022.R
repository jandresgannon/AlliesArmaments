###############################
# Rule of Law Index [WJP]
# Version: 2021
# Accessed: March 12, 2022
# Year Range: 2013-2021
# Last updated by: Robert Huang
# Updated by: BZ
# Prepped By: Rohit Madan
# Suffix: WJP
# Last update: March 13, 2022
#
# Data: https://worldjusticeproject.org/our-work/research-and-data/wjp-rule-law-index-2021/current-historical-data
# Codebook: https://worldjusticeproject.org/our-work/publications/rule-law-index-reports/wjp-rule-law-index%C2%AE-2016-report
#   
# Citation: The World Justice Project. 2016. Rule of Law Index. 
# http://worldjusticeproject.org/rule-of-law-index. Accessed on: April 8, 2017.
#
# Variables: 
# civil_cf_WJP: Civil conflict is effectively limited 
# cj_crpt_WJP: Civil justice is free of corruption 
# cj_delay_WJP: Civil justice is not subject to unreasonable delays 
# adr_acces_WJP: ADRs are accessible, impartial, and effective 
# cj_disc_WJP: Civil justice is free of discrimination 
# cj_enfor_WJP: Civil justice is effectively enforced 
# crime_ctrl_WJP: Crime is effectively controlled 
# due_admin_WJP: Due process is respected in administrative proceedings  
# exec_crpt_WJP: Executive branch officials do not use public office for private gain  
# expr_comp_WJP: The Government does not expropriate without adequate compensation 
# gov_reg_WJP: Government regulations are applied and enforced without improper influence 
# judic_crpt_WJP: Judicial branch officials do not use public office for private gain 
# legis_crpt_WJP: Legislative branch officials do not use public office for private gain 
# milt_crpt_WJP: Police and Military officials do not use public office for private gain 
# ppl_cj_WJP: People have access to affordable civil justice
#
# Note: We don't have a balanced panel. Some countries only have data for some of the years.
###############################

# clear everything
rm(list=ls())

# load packages
library(Hmisc)
library(tidyverse)
library(readxl)


# set filepaths 
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/prepped/"
prepscripts <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/scripts/"
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/"

# read previous prepped data from 2013 to 2019
load(paste(rawdata,"PREPPED_WJP_BZ_04102019.RDATA", sep=""))


# Read raw data for 2020
rol20 = read_excel(path = (paste(rawdata, "RAWDATA_WJP_2021.xlsx", sep="")), sheet = "WJP ROL Index 2020 Scores")
# Read raw data for 2021
rol21 = read_excel(path = (paste(rawdata, "RAWDATA_WJP_2021.xlsx", sep="")), sheet = "WJP ROL Index 2021 Scores")

# select variables
varNums <- c("2.1", "2.2", "2.3", "2.4","5.1", "5.2", "6.2", "6.4", "6.5", "7.1", "7.2", "7.3", "7.5", "7.6", "7.7")

# 2020
contains20 <- integer(length = 0)
for (i in varNums){
  contains20 <- c(contains20, sum(grep(i, rol20$Country)))
}

rol20_2 <- rol20[contains20, ]

# 2021
# contains21 <- integer(length = 0)
# for (i in varNums){
#   contains21 <- c(contains21, sum(grep(i, rol21$Country)))
# }
# 
# rol21_2 <- rol21[contains21, ]

# above code was producing NAs for 2.2. judicial corruption for the 2021 data 
  # below is tidyverse alternative using str_detect 

rol21_2 <- rol21 %>% 
  dplyr::filter(str_detect(Country, paste(varNums, collapse="|"))) %>% 
  slice(1:n() -1) # removing unwanted variable 

# use pivot_longer to create country column
rol20_3 <- rol20_2 %>%
  rename(var=Country) %>%
  pivot_longer(Afghanistan:Zimbabwe,
               names_to = "country",
               values_to = "value")

rol21_3 <- rol21_2 %>%
  rename(var=Country) %>%
  pivot_longer(Afghanistan:Zimbabwe,
               names_to = "country",
               values_to = "value")


# use pivot_wider to get variable columns
rol20_4 <- rol20_3 %>%
  pivot_wider(names_from = "var",
              values_from = "value")

rol21_4 <- rol21_3 %>%
  pivot_wider(names_from = "var",
              values_from = "value")


# Rename variables we need
varNames <- c("Country", "exec_crpt", "judic_crpt", "milt_crpt", "legis_crpt", "crime_ctrl", "civil_cf", "gov_reg", "due_admin", "expr_comp", "ppl_cj", "cj_disc", "cj_crpt", "cj_delay", "cj_enfor", "adr_acces")

colnames(rol20_4) <- varNames
colnames(rol21_4) <- varNames

# add year variable
rol20_4$year <- 2020
rol21_4$year <- 2021

# combine 2020 and 2021 data 
rol2 <- rbind(rol20_4,rol21_4)


# append IDs
source(paste0(ids_path, "append_ids.R"))
rol3 <- append_ids(rol2, ids_path, dyad = F, breaks = F)

# Append Suffix
rol3 <- append_suffix(rol3, "WJP")

# Merge with previous data
# Rearrange merged dataset
rol4 <- rbind(rol,rol3) %>% 
  arrange(gwno, year)
#rol4 <- arrange(rol4,gwno,year)


# save prepped data
saveRDS(rol4,file=paste(preppeddata,"PREPPED_WJP_RH_03232022.RDS",sep=""))
