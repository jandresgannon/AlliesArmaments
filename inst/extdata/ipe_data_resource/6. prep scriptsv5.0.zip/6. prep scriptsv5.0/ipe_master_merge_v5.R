######################################
# IPE Data Resource Country-Year Master Merge
# Updated: 05/24/2022, Gaea Morales 

library(readstata13)
library(tidyverse)
library(countrycode)
library(labelled)

preppeddata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/preppeddatav5.0/"
rawdata <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/rawdatav5.0/"

ids_path <- "/Volumes/GoogleDrive-106129646335010644812/My Drive/append_ids/"
source(paste0(ids_path, "append_ids.R"))


####### .RDATA FILES 

# get all .rdata file names
fnames.rdata <- list.files(preppeddata, "*.rdata", ignore.case = T)

# identifiers that we don't want to merge on
extra_ids <- c("country", "ccode", "ifscode", "ifs", "gwabbrev")

# load the first file
ipe <- load(paste(preppeddata, fnames.rdata[1], sep = ""))
ipe <- get(ipe) %>% 
  dplyr::select(-one_of(extra_ids)) %>%
  mutate_at(vars(one_of(c("gwno","repgwno","year"))), as.numeric)

# load and merge the rest of the files
for(n in fnames.rdata[2:length(fnames.rdata)]){
  
  df <- load(paste(preppeddata, n, sep = "")) # load, store reference
  
  df <- get(df) %>% # get file from reference
    dplyr::select(-one_of(extra_ids)) %>% # remove extra ids
    mutate_at(vars(one_of(c("gwno","year"))), as.numeric) # make sure gwno and year are numeric
  
  print(n) # print name to ckeck progress
  ipe <- full_join(ipe, df) # merge
 
  # check for duplicates introduced 
  n_occur <- data.frame(table(ipe$gwno, ipe$year))
  if(sum(n_occur$Freq > 1) > 0){
    print(n_occur[n_occur$Freq > 1,])
    break
  }
  
  # clean up loaded objects from environment
  rm(list=setdiff(ls(), c("ipe", "preppeddata", "rawdata", "extra_ids", "append_ids")))
}

# check that everything joined by gwno and year, except AP, CEPII, and LANG which joined by gwno only
# if any new cross-sectional datasets have been added, those should also merge by gwno only



####### .RDS FILES 

# get all .rdata file names
fnames.rds <- list.files(preppeddata, "*.rds", ignore.case = T)

# identifiers that we don't want to merge on
extra_ids <- c("country", "ccode", "ifscode", "ifs", "gwabbrev", "countryname_raw")

# # load the first file
# ipe <- readRDS(paste0(preppeddata, fnames.rds[1]))
# ipe <- ipe %>% 
#   dplyr::select(-one_of(extra_ids)) %>%
#   mutate_at(vars(one_of(c("gwno"))), as.numeric)

# load and merge the rest of the files

for(n in fnames.rds[1:length(fnames.rds)]){
  
  df <- readRDS(paste0(preppeddata, n)) # load, store reference
  
  df <- df %>% # get file from reference
    dplyr::select(-one_of(extra_ids)) %>% # remove extra ids
    mutate_at(vars(one_of(c("gwno", "year"))), as.numeric) # make sure gwno and year are numeric
  
  print(n) # print name to check progress
  ipe <- full_join(ipe, df) # merge
  
  # check for duplicates introduced 
  n_occur <- data.frame(table(ipe$gwno, ipe$year))
  if(sum(n_occur$Freq > 1) > 0){
    print(n_occur[n_occur$Freq > 1,])
    break
  }
  
  # clean up loaded objects from environment
  rm(list=setdiff(ls(), c("ipe", "preppeddata", "rawdata", "extra_ids", "append_ids")))
}



####### .DTA FILES 

# do the same for .dta files
fnames.dta <- list.files(preppeddata, "*.dta")

for(n in fnames.dta){
  
  df <- read.dta13(paste0(preppeddata, n, sep = "")) %>%
    dplyr::select(-one_of(extra_ids)) %>%
    mutate_at(vars(one_of(c("gwno","year"))), as.numeric)
  
  print(n)
  ipe <- full_join(ipe, df)
  
  # check for duplicates introduced 
  n_occur <- data.frame(table(ipe$gwno, ipe$year))
  if(sum(n_occur$Freq > 1) > 0){
    print(n_occur[n_occur$Freq > 1,])
    break
  }
}

# check for duplicates
n_occur <- data.frame(table(ipe$gwno, ipe$year))
print(n_occur[n_occur$Freq > 1,])

#checking variables
names <- as.data.frame(names(ipe))

# # add country names back (from raw country names)
# countrynames_raw <- ipe %>%
#   select(starts_with('countryname_raw_')) %>%
#   select(-countryname_raw_PTO, -countryname_raw_BZ) %>% # exclude these bc they are labeled, so don't work with coalesce
#   mutate(countrynames = coalesce(!!!.))

# re-add in country names from gwno (use one of the datasets)
countrynames <- readRDS(paste0(preppeddata,"PREPPED_WDI_WGI_JS_02032022.RDS")) %>% 
  select(country, gwno) %>% 
  group_by(country, gwno) %>% 
  distinct()

ipe <- left_join(ipe, countrynames, by = "gwno") %>% 
  select(-contains("countryname_raw"))

# # get a few countrynames that coalesce misses
# ipe$country <- ifelse(is.na(ipe$country), ipe$countryname_raw_PTO, ipe$country)
# ipe$country <- ifelse(is.na(ipe$country), countrycode(ipe$gwno, 'gwn', 'country.name'), ipe$country)
# table(ipe$gwno[is.na(ipe$country)])
# ipe$country[ipe$gwno == 711] <- "Tibet"

# this actually isn't neccesarry because append_ids will catch these
#ipe_v4 <- ipe %>% filter_all(any_vars(!is.na(.))) 

# add IDs back and final clean up
ipe_v5 <- ipe %>% 
  #dplyr::rename(gwno_raw_BH = gwno_raw) %>%
  append_ids(breaks = F) %>% 
  group_by(gwno, year) %>% 
  distinct() %>% 
  filter(!(country == "Serbia" & gwno_raw == 345),
         !(country == "Yugoslavia" & gwno_raw == 340),
         !(is.na(country)),
         !(country == "")) %>% 
  select(-c(contains("_raw_"))) %>% # removing raw ccode columns
  arrange(gwno, year)

# Remove duplicates 
#for Yugoslavia from 1918-2006, Serbia from 2007-2014)

# check for duplicates
n_occur <- data.frame(table(ipe_v5$country, ipe_v5$year))
print(n_occur[n_occur$Freq > 1,])

######### CHECKS

# Cross-check codebook variables with ipe variables 

# extract varnames from ipe resource (07/26/2022)
var_ipe <- as.vector(names(ipe_v5))
#write.csv(ipe_v5_names, file = paste(preppeddata,"ipev5_check.csv"))
View(as.data.frame(var_ipe))

# read in var names from codebook (version 07/26/2022)
var_cb <- readxl::read_excel(paste0(preppeddata,"ipev5_check_072622.xlsx"), sheet = 2) %>% 
  select(var_cb) 
var_cb <- as.vector(unlist(var_cb))

# compare what is in the two objects 
miss_cb <- setdiff(var_ipe, var_cb) # what is in IPE but not codebook 
  # ~803 (now edited and checked)
miss_ipe <- setdiff(var_cb, var_ipe) # what is in codebook but not IPE 
  # ~120 (now edited and checked)

View(as.data.frame(miss_cb))
View(as.data.frame(miss_ipe))

# this row contains no data
#ipe_v5 <- ipe_v5[-which(ipe_v4$gwno_raw == 340 & ipe_v4$year == 2006),]

range(ipe_v5$year) #1500 2022
unique(ipe_v5$country) #199
ncol(ipe_v5) #1846, minus the 9 identifier columns = 1837 variables 

save(ipe_v5, file = paste(preppeddata,"../master_ipe_v5_072622.RDATA",sep=""))
saveRDS(ipe_v5, file = paste(preppeddata,"../master_ipe_v5_072622.RDS",sep=""))
write.table(ipe_v5, file = paste(preppeddata,"../master_ipe_v5_072622.tsv",sep=""))


## 
# Summary of v5

summ_v5 <- as.data.frame(var_ipe) %>% 
  mutate(dataset = str_extract(var_ipe, "[^_]+$"))

unique(summ_v5$dataset) # 97 datasets

test <- readRDS("/Volumes/GoogleDrive-106129646335010644812/My Drive/Master IPE Data/IPE Dataset_v.5.0/CountryYear updates_v.5.0/master_ipe_v5_072622.RDS")
