# /************************* 
# Data: Bilateral Investment Treaties
# Data source url: http://investmentpolicyhub.unctad.org/IIA/MostRecentTreaties#iiaInnerMenu
# Time:1959-2018	
# By: Jessica Xu 
# Edited by: Michael Jaksland
# Suffix: BIT
# Total: 2950
# Total in force: 2360
# Citation:
# *************************/

library(readxl)
library(Hmisc)
library(readstata13)
library(reshape2)
library(dplyr)

#import rawdata from dta format 
BIT_dta <- read.dta13(paste(rawdata, "RAWDATA_BITs 1959-2012 merged_JX.dta", sep = "")) %>%
  filter(year < 2013)

#import rawdata from excel 
BIT <- read_excel(paste(rawdata, "RAWDATA_BIT_JX.xlsx", sep=""))

#import 2018 rawdata from excel
BIT2018 <- read_excel(paste(rawdata, "RAWDATA_BIT_2018.xlsx", sep=""))

#Merge BIT2018 with BIT
BIT <- rbind(BIT, BIT2018)

#change BIT country wide to long
BIT = melt(BIT, id.var=c("signyear","sign"), variable.name = "country")

#remove column#3
BIT=BIT[-c(3)]

#rename the column#3
names(BIT)[names(BIT)=="value"]<- "country"
names(BIT)[names(BIT)=="signyear"]<- "year"

load(paste(rawdata, "Country_GWNO_Year_Simple.RDATA", sep = ""))
# tmp <- simpleCY[simpleCY$year == 2017,]
#  tmp$year <- 2018
#  simpleCY <- rbind(simpleCY, tmp)
#  save(simpleCY, file = paste(rawdata, "Country_GWNO_Year_Simple.RDATA", sep = ""))
tmp <- simpleCY[simpleCY$year > 2012,]

# process new data and add to old
BIT <- BIT %>% group_by(country, year) %>%
  dplyr::summarise(sign = sum(sign)) %>%
  append_ids(breaks = F) %>%
  # add country-years with no new BITs
  full_join(tmp) %>%
  mutate(sign = replace_na(sign, 0)) %>%
  # cumulative sums
  group_by(gwno) %>% arrange(year) %>%
  mutate(bits = cumsum(sign)) %>%
  # add to previous cumulative sums
  left_join(BIT_dta[BIT_dta$year == 2012,], by = "gwno") %>%
  mutate(bitstodate_BIT = bitstodate_BIT + bits) %>%
  select(gwno, country = country.x, year = year.x, bitstodate_BIT) %>%
  # bind to old data
  bind_rows(BIT_dta) %>%
  #fill in missing country names
  arrange(gwno, year) %>% fill(country) %>%
  # log BITs
  mutate(lnbitstodate_BIT = log(bitstodate_BIT + .1))

# append IDs
BIT <- append_ids(BIT, breaks = F) %>% #dropped names were present in years where they shouldn't have been in the .dta file
  select(-gwno_raw)

# may want to change this if serbia inherited yugoslavia's agreements
BIT <- BIT[!(BIT$countryname_raw == "Serbia" & BIT$year < 2007 & BIT$year > 1917),]
BIT <- BIT[!(BIT$countryname_raw == "Yugoslavia" & BIT$year > 2006),]
# there is never any data for "yemen" and it only exists in years where there is data for "republic of yemen
BIT <- BIT[!(BIT$countryname_raw == "Yemen"),] 


names(BIT)[names(BIT) == "countryname_raw"] <- "countryname_raw_BIT" 

length(unique(BIT$gwno)) # 223
range(BIT$year) # 1800-2018

# Add variable labels
label(BIT$bitstodate_BIT) = "BITs signed to date [BIT]"
label(BIT$lnbitstodate_BIT) = "BITs signed to date (logged) [BIT]"

save(BIT,file=paste(preppeddata,"PREPPED_BIT_MB_2018.RDATA",sep=""))
