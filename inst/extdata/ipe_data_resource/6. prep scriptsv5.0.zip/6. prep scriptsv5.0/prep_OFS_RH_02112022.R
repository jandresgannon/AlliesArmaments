###############################
# BEA US Outward FDI Stocks, Historical Cost Basis [OFS]
# Accessed: Feb 11, 2022
# Year Range: 1982-2020
# Updated by: Robert Huang
# Prepped By: Alicia Kuang
# Suffix: OFS
#
# Data Source: http://www.bea.gov/international/di1usdbal.htm
#
# Citation: U.S. Bureau of Economic Analysis. U.S. Direct Investment Abroad, U.S. Direct Investment Position Abroad on a Historical-Cost Basis. 
# http://www.bea.gov/international/di1usdbal.htm (accessed March, 2019).
#
# Variables: 
# ind_total_OFS: Outward FDI stocks from the US in USD (millions), all industries, BEA [OFS]
###############################

# clear everything
rm(list=ls())

# load packages
library(Hmisc)
library(tidyverse)
library(readxl)

# set filepaths 
rawdata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/rawdata/"
preppeddata <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/prepped/"
prepscripts <- "/Volumes/GoogleDrive/My Drive/Master IPE Data/SPRING 2022/scripts/"
ids_path <- "/Volumes/GoogleDrive/My Drive/append_ids/"


# importing sheets
ofs_2016 <- read_xlsx(paste(rawdata,"RAWDATA_OFS_2019.xlsx", sep=""), col_names = T, sheet=7, skip = 3)
ofs_2017 <- read_xlsx(paste(rawdata,"RAWDATA_OFS_2019.xlsx", sep=""), col_names = T, sheet=8, skip = 3)
ofs_2018 <- read_xlsx(paste(rawdata,"RAWDATA_OFS_2019.xlsx", sep=""), col_names = T, sheet=9, skip = 3)
ofs_2019 <- read_xlsx(paste(rawdata,"RAWDATA_OFS_2019.xlsx", sep=""), col_names = T, sheet=10, skip = 3)
ofs_2020 <- read_xlsx(paste(rawdata,"RAWDATA_OFS_2020.xlsx", sep=""), col_names = T, sheet=1, skip = 3)

# select columns
ofs_2016 <- ofs_2016[,c(1,2)]
ofs_2017 <- ofs_2017[,c(1,2)]
ofs_2018 <- ofs_2018[,c(1,2)]
ofs_2019 <- ofs_2019[,c(1,2)]
ofs_2020 <- ofs_2020[,c(1,2)]

# rename variables
names(ofs_2016) <- c("country","ind_total")
names(ofs_2017) <- c("country","ind_total")
names(ofs_2018) <- c("country","ind_total")
names(ofs_2019) <- c("country","ind_total")
names(ofs_2020) <- c("country","ind_total")

# add year
ofs_2016$year <- 2016
ofs_2017$year <- 2017
ofs_2018$year <- 2018
ofs_2019$year <- 2019
ofs_2020$year <- 2020

# filter rows
ofs_2016 <- ofs_2016 %>%
  filter(!is.na(country))

ofs_2017 <- ofs_2017 %>%
  filter(!is.na(country))

ofs_2018 <- ofs_2018 %>%
  filter(!is.na(country))

ofs_2019 <- ofs_2019 %>%
  filter(!is.na(country))

ofs_2020 <- ofs_2020 %>%
  filter(!is.na(country))

# combine data frames
ofs2 <- rbind(ofs_2016,ofs_2017,ofs_2018,ofs_2019,ofs_2020)

# append IDs
source(paste0(ids_path, "append_ids.R"))
ofs3 <- append_ids(ofs2, ids_path, dyad = F, breaks = F)

# Append suffixes
ofs3 <- append_suffix(ofs3,"OFS")


# load data before 2017
load(paste(rawdata,"PREPPED_OFS_AK_2017.RDATA",sep=""))

# keep only data before 2016
ofs <- ofs %>%
  filter(year<2016)


# combine old and new data frames
ofs4 <- rbind(ofs,ofs3)
ofs4 <- ofs4 %>%
  arrange(country,year)


# save data
saveRDS(ofs4,file=paste(preppeddata,"PREPPED_OFS_RH_02132022.RDS",sep=""))


