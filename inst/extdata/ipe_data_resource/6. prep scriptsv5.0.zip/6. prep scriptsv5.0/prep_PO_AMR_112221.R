# /************************* 
# Source: Uppsala Conflict Data Program 
# Accessed: May 16, 2017
# URL: https://www.prio.org/Data/Armed-Conflict/UCDP-PRIO/
# Query specifications: all countries, all years, variables: id_PO, sidea_PO, sidea2nd_PO, incomp_PO, terr_PO, intensity_PO, cumintensity_PO, type_PO, region_PO
# Time: 1946-2016
# By: Jessica Xu

# Accessed: October 3, 2018
# Edited/Updated by Anna Lipscomb (October 5, 2018)
# Query specifications: all countries, all years, variables: id_PO, sidea_PO, sidea2nd_PO, sideb_PO, sideb2nd_PO, incomp_PO, terr_PO, intensity_PO, cumintensity_PO, type_PO, region_PO
# Time: 1946-2017

# Accessed: March 4, 2020
# Edited/Updated by Emily Heuring (March 4, 2020)

# Edited Miriam Barnum (May 2020)

# Accessed: November 18. 2021
# Edited/Updated by Affan Rahman (November 18. 2021)

# Suffix: PO
# Variables: id, sidea, sidea2nd, sideb, sideb2nd, incomp, terr, intensity, cumintensity, type, region
# *************************/

library(readxl)
library(dplyr)
library(splitstackshape)
library(Hmisc)

#import
PO <- read_excel(paste(rawdata, "rawdata_PO_2020.xlsx", sep=""))

#renaming variables
names(PO)[names(PO)=="conflict_id"]="id"
names(PO)[names(PO)=="location"] = "country"
names(PO)[names(PO)=="year"] = "year"
names(PO)[names(PO)=="side_a"] = "sidea"
names(PO)[names(PO)=="side_a_2nd"]="sidea2nd"
names(PO)[names(PO)=="side_b"] = "sideb"
names(PO)[names(PO)=="side_b_2nd"]="sideb2nd"
names(PO)[names(PO)=="incompatibility"]="incomp"
names(PO)[names(PO)=="territory_name"]="terr"
names(PO)[names(PO)=="intensity_level"]="intensity"
names(PO)[names(PO)=="cumulative_intensity"]="cumintensity"
names(PO)[names(PO)=="type_of_conflict"]="type"
names(PO)[names(PO)=="region"]="region"

#cut out unnecessary variables
PO = PO[,c("country",
           "year", 
           "id",
           "sidea",
           "sidea2nd",
           "sideb",
           "sideb2nd",
           "incomp",
           "terr",
           "intensity",
           "cumintensity",
           "type",
           "region")]

#split the column that has more than one country to multiple rows      
PO <- cSplit(PO,"country", sep = ",", direction = "long")


#label
label(PO$id) <- "Conflict identifier [PO]"
label(PO$sidea) <- "Identifies the country of SideA. Always the government side in an internal conflict [PO]"
label(PO$sidea2nd) <- "Names of state(s) supporting side A with troops [PO]"
label(PO$sideb) <- "Country name or opposition actor [PO]"
label(PO$sideb2nd) <- "Names of state(s) supporting side B with troops [PO]"
label(PO$incomp) <- "Dyad incompatibility [PO]"
label(PO$terr) <- "Name of territory [PO]"
label(PO$intensity) <- "Intensity level (minor armed conflicts and wars) [PO]"
label(PO$cumintensity) <- "cumulative intensity [PO]"
label(PO$type) <- "Conflict type [PO]"
label(PO$region) <- "Region of location [PO]"

# create indicator variables
PO$internal <- ifelse(PO$type >= 3, 1, 0)
PO$interstate <- ifelse(PO$type == 2, 1, 0)
PO$extrasyst <- ifelse(PO$type == 1, 1, 0)

label(PO$internal) <- "internal conflict (binary) [PO]"
label(PO$interstate) <- "interstate conflict (binary)  [PO]"
label(PO$extrasyst) <- "extrasystemic conflict (binary)  [PO]"

# # identify duplicates
n_occur <- data.frame(table(PO$country, PO$year))
print(n_occur[n_occur$Freq > 1,])

PO <- PO %>% 
  group_by(country, year) %>%
  mutate_at(c("internal","interstate","extrasyst"), max) %>%
  filter(cumintensity == max(cumintensity, na.rm = T))  %>%
  filter(intensity == max(intensity, na.rm = T)) %>%
  slice(1) # when max(intensity) and max(cumintensity) both produce ties, arbitrarily pick the first row in the data

# double check that duplicates are gone
n_occur <- data.frame(table(PO$country, PO$year))
n_occur[n_occur$Freq > 1,]

#append ids
source(paste0(ids_path, "append_ids.R", sep = "")) # loading in append_ids
PO <- as.data.frame(PO)
PO = append_ids(PO, breaks = F) 

#check duplicates
n_occur <- data.frame(table(PO$country, PO$year))
n_occur[n_occur$Freq > 1,]

PO <- PO[PO$countryname_raw != "FYR",] # removing countryname_raw column that was accidentally introduced by splitting on commas

#append suffix
PO = append_suffix(PO, "PO")

save(PO,file=paste(preppeddata,"PREPPED_PO_AMR_112221.RDATA",sep=""))

